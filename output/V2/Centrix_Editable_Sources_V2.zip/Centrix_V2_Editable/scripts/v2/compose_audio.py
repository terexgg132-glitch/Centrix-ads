"""CENTRIX V2: original 108 BPM cinematic electronica and designed synthetic SFX.
Procedural oscillators, seeded noise and synthesized room IR; no external samples.
Original narration is decoded once, never retimed, cut or regenerated.
"""
from pathlib import Path
import json,subprocess
import numpy as np
from scipy.signal import butter,sosfilt,fftconvolve
from scipy.ndimage import uniform_filter1d
from scipy.io import wavfile
R=Path(__file__).resolve().parents[2]; OUT=R/'output/V2/audio'; OUT.mkdir(parents=True,exist_ok=True)
TMP=R/'work/v2/audio';TMP.mkdir(parents=True,exist_ok=True)
SR=48000;N=27*SR;rng=np.random.default_rng(210661)
score=np.zeros((N,2)); fx=np.zeros((N,2));cues=[]
def T(d):return np.arange(int(d*SR))/SR
def hz(m):return 440*2**((m-69)/12)
def filter(x,cut,kind='lowpass'):return sosfilt(butter(2,cut,fs=SR,btype=kind,output='sos'),x)
def env(t,attack=.005,decay=.25):return -np.expm1(-t/attack)*np.exp(-t/decay)
# Synthesized diffused room, not an imported impulse response.
ir_t=T(1.65);ir=filter(rng.normal(size=len(ir_t)),4800)*np.exp(-ir_t/0.33)
ir[:int(.042*SR)]=0; ir/=np.sqrt(np.sum(ir*ir))*6
def add(dst,x,start,level=1,pan=0,room=0):
 x=np.asarray(x);pos=round(start*SR)
 if x.ndim==1:
  if room:x=x+fftconvolve(x,ir)[:len(x)]*room
  x=np.stack([x*np.sqrt((1-pan)/2),x*np.sqrt((1+pan)/2)],1)
 if pos<0:x=x[-pos:];pos=0
 n=min(len(x),N-pos)
 if n>0:dst[pos:pos+n]+=x[:n]*level
def pad(notes,start,dur,lev):
 t=T(dur);a=np.minimum(t/0.85,1)*np.minimum((dur-t)/1.25,1);a=np.clip(a,0,1)
 x=np.zeros((len(t),2))
 for i,m in enumerate(notes):
  f=hz(m)
  for ch,detune in enumerate([-.0026,.0028]):
   ph=2*np.pi*f*(1+detune)*t+.16*np.sin(2*np.pi*.11*t+i)
   wave=np.sin(ph)+.24*np.sin(2*ph)+.09*np.sin(3*ph)+.04*np.sin(5*ph)
   x[:,ch]+=filter(wave,2100)*a/len(notes)
 add(score,x,start,lev)
def pluck(m,start,lev=.03,pan=0,dec=.34):
 t=T(1.5);f=hz(m);e=env(t,.003,dec)
 # FM transient and subtly detuned harmonics create a physical attack.
 x=(np.sin(2*np.pi*f*t+2.1*np.sin(2*np.pi*f*2*t)*np.exp(-t/.035))+.24*np.sin(2*np.pi*f*2.001*t)+.06*np.sin(2*np.pi*f*4*t))*e*np.clip((1.5-t)/.12,0,1)
 add(score,x,start,lev,pan,1.3)
 for d,l in [(.187,.24),(.374,.14)]:add(score,x,start+d,lev*l,-pan)
def bass(m,start,lev):
 t=T(.63);f=hz(m);ph=2*np.pi*f*t
 x=(np.sin(ph)+.34*np.sin(2*ph)+.16*np.sin(3*ph)+.06*np.sin(5*ph))*env(t,.005,.24)
 add(score,x,start,lev)
def kick(start,lev):
 t=T(.34);frequency=47+105*np.exp(-t/.018);ph=2*np.pi*np.cumsum(frequency)/SR
 x=np.sin(ph)*env(t,.0015,.085)+filter(rng.normal(size=len(t)),2000)*np.exp(-t/.009)*.10
 add(score,x,start,lev)
def snare(start,lev):
 t=T(.35);n=filter(rng.normal(size=len(t)),[1200,7300],'bandpass')*env(t,.001,.025)
 body=np.sin(2*np.pi*174*t)*env(t,.001,.062)
 add(score,n*.4+body*.22,start,lev,.10,.4)
def hat(start,lev,pan):
 t=T(.10);n=filter(rng.normal(size=len(t)),[5100,10800],'bandpass')*env(t,.0004,.013)
 add(score,n,start,lev,pan)
# Through-composed harmony, transition at system activation, a quieter AI bridge.
pad([50,57,60,64],0,6.2,.044);pad([46,53,57,62],5.8,3.9,.050)
pad([50,57,62,65],8.876,4.5,.064);pad([48,55,60,64],12.5,3.2,.054)
pad([46,53,57,62],15.0,3.8,.035);pad([45,52,57,62],18,4.1,.064)
pad([50,57,62,65,69],21.661,5.339,.100)
beat=60/108
for i,start in enumerate(np.arange(0,21.661,beat)):
 if start<5.8:
  if i%4==0:kick(start,.040);bass(38,start,.05)
  if i%4==3:pluck([74,69,77,76][i//4%4],start,.026,-.25,.9)
  continue
 quiet=.55 if 14.5<start<18 else 1
 buildup=1+max(0,start-18)/3.661*.23
 kick(start,.104*quiet*buildup)
 if i%4==2:snare(start,.082*quiet*buildup)
 hat(start+beat*.5,.015*quiet,(-1)**i*.45)
 if start>9 and i%4 in [1,3]:hat(start+beat*.75,.009*quiet,(-1)**i*-.5)
 if i%2==0:bass([38,34,36,33][i//8%4],start,.115*quiet)
 # Original syncopated motif, with rests; no stock or reused melody.
 if start>8.8 and i%8 not in [3,6]:
  pluck([74,81,77,76,72,79,76,69][i%8],start+beat*.25,.049*quiet,(-1)**i*.24,.29)
# Opening low bell and ending custom three-note audio identity.
pluck(50,.02,.040,0,1.6)
for m,start,lev in [(74,21.661,.125),(77,21.976,.110),(81,22.295,.10)]:pluck(m,start,lev,0,1.35)
def impact(start,f=66,lev=.08,name='Impact'):
 t=T(.8);phase=2*np.pi*(f*t+3.5*(1-np.exp(-t/.025)))
 n=filter(rng.normal(size=len(t)),[450,4800],'bandpass')
 x=np.sin(phase)*env(t,.0014,.15)+.14*n*env(t,.0005,.022)
 add(fx,x,start,lev,0,.65);cues.append({'time':start,'name':name})
def glass(start,f,lev=.04,name='Glass confirmation'):
 t=T(.8);x=np.zeros(len(t))
 for r,a,d in [(1,1,.19),(1.498,.32,.12),(2.006,.12,.065),(2.707,.055,.04)]:
  x+=np.sin(2*np.pi*f*r*t)*env(t,.0007,d)*a
 add(fx,x*np.clip((.8-t)/.04,0,1),start,lev,0,1.1);cues.append({'time':start,'name':name})
def sweep(start,dur=.5,lev=.04,name='Paper/data sweep'):
 t=T(dur);noise=filter(rng.normal(size=len(t)),[180,5200],'bandpass')
 moving=.6+.4*np.sin(2*np.pi*(15*t+27*t*t/dur))
 x=noise*np.sin(np.pi*t/dur)**2*moving
 stereo=np.stack([x*np.sqrt((1+.6*np.sin(np.pi*t/dur))/2),x*np.sqrt((1-.6*np.sin(np.pi*t/dur))/2)],1)
 add(fx,stereo,start,lev);cues.append({'time':start,'name':name})
impact(0,47,.22,'Opening dimensional heartbeat');glass(.306,1600,.035,'Student scan')
sweep(2.64,.47,.062,'Records split into layers');impact(4.596,83,.090,'Details punctuation')
impact(5.983,92,.100,'Attendance mechanical confirmation');glass(6.766,920,.052,'Receipt print/glass accent')
sweep(6.716,.25,.023,'Paper shape morph');impact(7.742,119,.10,'Report precise stamp')
sweep(8.63,.225,.029,'Mini vacuum');sweep(8.876,.76,.085,'Golden conductor activation')
impact(9.66,67,.065,'Aligned structure settles')
for start,f in [(10.005,1300),(10.525,1750),(11.03,1050)]:glass(start,f,.018,'Connected operation data reveal')
impact(12.715,74,.13,'One-system lock')
glass(14.685,460,.025,'AI question focus');sweep(16.17,.45,.022,'AI response')
glass(16.236,1840,.018,'Soft AI shimmer');glass(16.50,2300,.013,'AI answer arrives')
sweep(18.526,3.135,.045,'Connected-system crescendo');impact(21.661,48,.25,'Brand hero impact')
glass(22.513,2880,.012,'Tagline warm shimmer')
# The exact input is preserved; only non-destructive mixing is performed.
voice_file=TMP/'voice_decode.wav'
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(R/'assets/centrix_voice_original.mp3'),'-ar',str(SR),'-ac','2',str(voice_file)],check=True)
_,v=wavfile.read(voice_file);v=v.astype(float)/32768
voice=np.zeros((N,2));voice[:len(v)]=v
rms=np.sqrt(uniform_filter1d(np.mean(voice*voice,axis=1),size=2400))
t=np.arange(N)/SR
speech=1-.46*np.clip((rms-.01)/.065,0,1)
bridge=1-.30*np.clip((t-14.50)/.18,0,1)*np.clip((18.0-t)/.25,0,1)
vacuum=1-.88*np.clip((t-8.68)/.06,0,1)*np.clip((8.88-t)/.055,0,1)
end=np.clip((27-t)/.35,0,1)
score*=speech[:,None]*bridge[:,None]*vacuum[:,None]*end[:,None]
fx*=(1-.13*np.clip((rms-.01)/.065,0,1))[:,None]*end[:,None]
raw=voice+score+fx
def write(path,a):wavfile.write(path,SR,(np.clip(a,-1,1)*2147483000).astype(np.int32))
write(OUT/'Centrix_Music_Original.wav',score);write(OUT/'Centrix_SFX_Stem.wav',fx);write(TMP/'pre_master.wav',raw)
(OUT/'audio_cues.json').write_text(json.dumps(cues,indent=2))
print(json.dumps({'voice_duration':len(v)/SR,'pre_master_peak':float(abs(raw).max()),'music_rms':float(np.sqrt(np.mean(score**2))),'cues':len(cues)}))
