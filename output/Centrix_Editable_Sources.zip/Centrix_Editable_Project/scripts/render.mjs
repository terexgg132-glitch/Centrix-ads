import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill,renderMedia} from '@remotion/renderer';
import {mkdirSync,renameSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
const mode=process.argv[2]||'preflight';
const serveUrl=await bundle({entryPoint:resolve('src/index.ts'),outDir:resolve('work/remotion-bundle'),enableCaching:true});
const browserExecutable=process.env.CENTRIX_CHROME||'/usr/bin/chromium';
const browser=await openBrowser('chrome',{browserExecutable});
try {
 const composition=await selectComposition({serveUrl,id:mode==='style'?'Centrix-Style-Test':'Centrix-Final-27s',puppeteerInstance:browser});
 if(mode==='preflight'){
  mkdirSync('output/review/preflight',{recursive:true});
  const frames=[15,105,204,276,375,486,594,684,786];
  for(let i=0;i<frames.length;i+=2){
   await Promise.all(frames.slice(i,i+2).map(async frame=>{
    await renderStill({serveUrl,composition,frame,output:'output/review/preflight/f'+frame+'.png',imageFormat:'png',puppeteerInstance:browser,logLevel:'error'});
    console.log('Verified render frame '+frame);
   }));
  }
 } else {
  const outputLocation=mode==='style'?'output/Centrix_Cinematic_Style_Test.mp4':'output/Centrix_Cinematic_Final_27s.mp4';
  let last=-1;
  await renderMedia({serveUrl,composition,outputLocation,codec:'h264',crf:17,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'320k',audioSampleRate:48000,concurrency:2,puppeteerInstance:browser,logLevel:'error',onProgress:({progress})=>{
   const p=Math.floor(progress*10)*10;
   if(p!==last){last=p;console.log(mode+' render '+p+'%');}
  }});
  // Chromium JPEG frames carry full-range metadata. Finish in broadcast-safe
  // BT.709 limited range and enforce exact container duration with FFmpeg.
  const raw='work/'+(mode==='style'?'style':'final')+'-renderer-fullrange.mp4';
  mkdirSync('work',{recursive:true});renameSync(outputLocation,raw);
  const audioInput=mode==='style'?['-ss','6','-i','output/audio/Centrix_Final_Mix.wav']:['-i','output/audio/Centrix_Final_Mix.wav'];
  const finish=spawnSync('ffmpeg',['-y','-loglevel','error','-i',raw,...audioInput,'-map','0:v:0','-map','1:a:0',
    '-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p',
    '-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p',
    '-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
    '-c:a','aac','-b:a','320k','-ar','48000','-ac','2','-t',mode==='style'?'8':'27',
    '-movflags','+faststart',outputLocation],{stdio:'inherit'});
  if(finish.status!==0)throw new Error('FFmpeg delivery finishing failed');
  console.log('Rendered and finished '+outputLocation);
 }
}finally{await browser.close({silent:true});}
