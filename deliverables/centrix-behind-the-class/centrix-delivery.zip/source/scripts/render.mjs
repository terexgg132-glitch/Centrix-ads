import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill} from '@remotion/renderer';
import path from 'node:path';
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const root=process.cwd();const out=process.env.CENTRIX_OUTPUT||path.join(root,'renders');
const mode=process.argv[2]||'proof';fs.mkdirSync(out,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),outDir:path.join(root,'.bundle')});
const common={serveUrl,browserExecutable:process.env.CHROME_PATH||'/usr/bin/chromium',chromiumOptions:{enableMultiProcessOnLinux:true},logLevel:'error'};
const comp=await selectComposition({...common,id:mode==='proof'?'MotionProof':'Centrix'});
if(mode==='stills'){
 const frames=[0,42,60,70,79,90,94,160,186,211,247,279,333,392,508,526,586,780];
 for(const frame of frames){await renderStill({...common,composition:comp,output:path.join(root,'..',`frame-${frame}.png`),frame,imageFormat:'png'});console.log('Still',frame)}
}else{
 let last=0;
 await renderMedia({...common,composition:comp,codec:'h264',crf:mode==='proof'?19:17,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'320k',outputLocation:path.join(out,mode==='proof'?'centrix-8s-motion-proof.mp4':'centrix-behind-the-class-final.mp4'),concurrency:2,onProgress:({progress})=>{const pct=Math.floor(progress*100);if(pct>=last+10){last=pct;console.log('Rendered',pct+'%')}}});
 const target=path.join(out,mode==='proof'?'centrix-8s-motion-proof.mp4':'centrix-behind-the-class-final.mp4');
 const delivery=target.replace('.mp4','.limited.mp4');
 const result=spawnSync('ffmpeg',['-v','error','-y','-i',target,'-i',path.join(root,'public/assets/centrix-full-mix.wav'),'-map','0:v:0','-map','1:a:0','-af',`atrim=start=${mode==='proof'?5.5:0}:duration=${mode==='proof'?8:27},asetpts=PTS-STARTPTS`,'-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-preset','medium','-crf',mode==='proof'?'18':'17','-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-c:a','aac','-b:a','320k','-ar','48000','-ac','2','-t',mode==='proof'?'8':'27','-movflags','+faststart',delivery],{stdio:'inherit'});
 if(result.status!==0)throw new Error('FFmpeg delivery conversion failed');
 fs.renameSync(delivery,target);
 console.log('FINISHED',mode);
}
