# Centrix — from busy to simple

Concept preview • 30 seconds • 1080 × 1920 • 30 fps • Egyptian Arabic

## Visual system

One continuous composition with a shared circular motif. Cobalt #125AF6, cyan #5CE5EF, white #FFFFFF, and pale blue #EDF4FF. Dark blue is reserved for typography on white. Cairo 800–900 for headlines; Cairo 600–700 for labels. Typography is shaped by the browser in RTL, with complete words animated independently. Keep headlines in the central safe zone, 90px from the sides, and the CTA above the Reels controls.

Rounded vector icons and cards represent real administrative objects, not decorations. No dashboard screen recordings, dimensional effects, stock imagery, generic particles, or borrowed WhatsApp assets. Reference principles: Hueso's WhatsApp Brand Design Refresh and Nomographic's Business Summit motion work: communicate information through familiar objects, use scale and rhythm for personality, and connect changes through material continuity.

## Storyboard

| Time | Composition and copy | Transition and sound |
| --- | --- | --- |
| 0–5s | Cobalt stage. Huge «طلاب كتير...» then «وتفاصيل أكتر؟» appears word by word. Student, attendance, date, and note cards build in an intentional orbit around the type. | Dry rounded pops on arrivals; a little anticipation before the cards pull inward. |
| 5–9s | Cards become rounded capsules around one cyan circle. The circle contracts and reveals the Centrix emblem. «خليها أبسط مع Centrix». | Soft suction sweep, clean brand chord. The circle expands into the white attendance stage. |
| 9–16s | Three expressive student cards fan out from the circle and reorganize into a vertical attendance stack. Checkmarks draw on beat. «سجّل الحضور... وتابع بسهولة». The last check transforms into a parent notification. | Three soft confirmation taps; a two-note notification chime. |
| 16–24s | The notification stretches into an information card; the other cards split into a connected student network around the Centrix hub. Information reorganizes into a clean system. «كل شغلك... في مكان واحد». | Connection ticks and a light rhythmic synth motif. Cards fold toward the hub to seed the outro. |
| 24–30s | The hub grows into a large Centrix logo reveal over cobalt. «ركّز في الشرح، وسيب التنظيم علينا». Cyan CTA «جرّب Centrix» compresses and releases with controlled overshoot. | Resolved logo chord; CTA tap. Logo and CTA hold long enough to read. |

## Asset and claim notes

The supplied `centrix-logo.svg` contains PNG bytes, not vector markup. It is a black/gold Centrix emblem with a serif wordmark. Preserve the original file. The composition isolates the exact supplied emblem with an SVG viewport and color filter; its geometry is not replaced with an invented mark. The blue/cyan treatment is a concept adaptation of the requested palette. A true approved SVG can replace this source later.

The user confirmed attendance recording, parent notifications, and student management are shipped. No fee collection, payments, AI, results guarantees, messaging-provider integration, or unsupported functionality is claimed. Export remains marked «تصوّر إعلاني» as requested; there is no implication of WhatsApp endorsement.

Audio: original deterministic 120 BPM synth/percussion bed with authored pops, sweeps, and chimes. Optional Egyptian voiceover script is supplied separately; no unreviewed synthetic dialect performance is required for this export.
