import {registerRoot} from 'remotion';
import {RootV2} from './v2/RootV2';
registerRoot(RootV2);
