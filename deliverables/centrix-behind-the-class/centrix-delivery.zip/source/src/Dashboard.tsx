import React from 'react';
import {C,T,p,lerp,Line,Dot,Corners,visible} from './shared';
const Record=({y,title,detail,icon,active}:{y:number;title:string;detail:string;icon:'tick'|'receipt'|'report';active:number})=><g>
 <path d={`M420 ${y+96}H904`} stroke={C.line} strokeWidth="2"/>
 <T x={897} y={y-5} size={55} anchor="start" fill={C.ivory} weight={700}>{title}</T>
 <T x={897} y={y+64} size={34} anchor="start" fill="#A6A196">{detail}</T>
 <g transform={`translate(430 ${y-44})`}>
  <rect width="72" height="72" rx="16" fill={active>.05?'#29271F':C.panel} stroke={active>.05?C.gold:C.line} strokeWidth="2"/>
  {icon==='tick'?<Line d="M19 37L31 49L54 24" color={C.gold} width={3} progress={active}/>:icon==='receipt'?<g opacity={active}><path d="M22 16H50V57L44 53L37 57L30 53L22 57Z M28 28H43 M28 36H43 M28 44H37" stroke={C.gold} strokeWidth={2} fill="none"/></g>:<g opacity={active}><path d="M20 54V36 M35 54V20 M50 54V29 M16 56H56" stroke={C.gold} strokeWidth={3} fill="none"/></g>}
 </g>
</g>;
export const Dashboard=({t}:{t:number})=>{
 const arrive=p(t,8.99,10);const toAI=p(t,14.55,15.45);const back=p(t,18.15,19.75);const fold=p(t,20.73,21.68);
 const x=lerp(1110,114,arrive),y=lerp(450,498,arrive),width=lerp(40,852,arrive),height=lerp(1100,920,arrive);
 const op=arrive*(1-p(t,21.30,21.65));
 return <g opacity={op}>
  <g transform={`translate(540 ${960-230*fold}) scale(${1-.92*fold}) rotate(${45*fold}) translate(-540 -960)`}>
   <rect x={x} y={y} width={width} height={lerp(height,1110,back)} rx={lerp(2,18,arrive)} fill={C.panel} stroke={C.line} strokeWidth="2" opacity={1-toAI+back*toAI}/>
   <g opacity={(1-toAI)*(1-back)}>
    <text x="165" y="592" fontFamily="Cairo" fill={C.ivory} fontSize="40" fontWeight="600">Centrix</text>
    <T x={910} y={589} size={30} fill="#9D978B" anchor="start">واجهة توضيحية</T>
    <path d="M151 630H929" stroke={C.line} strokeWidth="2"/>
    <T x={321} y={1023} size={35} fill="#A6A196">الطالب</T>
    <path d="M329 1064V1195Q329 1262 398 1262H430 M329 1064V822H430 M329 1042H430" stroke="#70654B" strokeWidth="2" fill="none"/>
    <Dot x={329} y={1064} r={6}/>
    <Record y={820} title="الحضور" detail="تسجيل حضور الطالب" icon="tick" active={p(t,10.005,10.55)}/>
    <Record y={1038} title="الحسابات" detail="سجل التحصيل" icon="receipt" active={p(t,10.82,11.38)}/>
    <Record y={1256} title="التقارير" detail="مراجعة بيانات الحصة" icon="report" active={p(t,11.65,12.25)}/>
    <path d="M170 1345H895" stroke={C.gold} strokeWidth={2} pathLength={1} strokeDasharray={1} strokeDashoffset={1-p(t,12.715,13.35)}/>
   </g>
   <g opacity={back}>
    <path d="M540 704V1247 M258 750H824 M258 1072H824 M258 1392H824" stroke="#635D4A" strokeWidth="2" fill="none"/>
    <T x={817} y={627} size={43} fill={C.ivory} anchor="start">منظومة واحدة</T>
    <T x={817} y={676} size={28} fill="#A6A196" anchor="start">الطالب في قلب كل عملية</T>
    <AtlasCell x={164} y={800} title="الحضور" detail="كشف الحصة" kind="tick"/>
    <AtlasCell x={586} y={800} title="التحصيل" detail="سجل المدفوعات" kind="receipt"/>
    <AtlasCell x={164} y={1122} title="المتابعة" detail="مسار الطالب" kind="path"/>
    <AtlasCell x={586} y={1122} title="التقارير" detail="بيانات الحصة" kind="report"/>
    <rect x="412" y="715" width="256" height="64" rx="32" fill={C.panel} stroke={C.gold} strokeWidth="2"/>
    <T x={540} y={761} size={34} fill={C.ivory}>الطالب</T>
    <Dot x={540} y={1072} r={9}/>
    <T x={540} y={1545} size={42} fill={C.ivory}>مساعد Centrix الذكي</T>
    <path d="M540 1400V1481" stroke={C.gold} strokeWidth="2"/>
   </g>
  </g>
  <T x={540} y={357+lerp(35,0,p(t,12.715,13.07))} size={133} fill={C.ivory} weight={850} opacity={visible(t,12.715,14.65,.16)}>سستم واحد</T>
  <T x={905} y={372} size={64} fill={C.ivory} anchor="start" weight={500} opacity={visible(t,9.52,12.715,.3)}>كل تفاصيل الحصة</T>
  <T x={540} y={354} size={82} fill={C.ivory} weight={750} opacity={visible(t,18.526,21.5,.55)}>متوصلة ببعضها</T>
 </g>;
};
const AtlasCell=({x,y,title,detail,kind}:{x:number;y:number;title:string;detail:string;kind:string})=> <g transform={`translate(${x} ${y})`}>
 <path d="M0 0H322V212H0Z" fill={C.panel} stroke={C.line} strokeWidth={2}/>
 <T x={288} y={72} size={43} fill={C.ivory} anchor="start" weight={650}>{title}</T>
 <T x={288} y={121} size={29} fill="#A6A196" anchor="start">{detail}</T>
 {kind==='tick'?<path d="M33 166L46 179L72 150" stroke={C.gold} strokeWidth="3" fill="none"/>:kind==='receipt'?<path d="M34 147H66V190L58 185L50 190L42 185L34 190Z M42 158H58 M42 166H58" stroke={C.gold} strokeWidth="2" fill="none"/>:kind==='path'?<g><path d="M33 172H281" stroke={C.gold} strokeWidth="2"/>{[33,156,281].map(x=><circle key={x} cx={x} cy={172} r={5} fill={C.gold}/>)}</g>:<path d="M33 182H281 M33 160H203 M33 145H128" stroke="#8F8262" strokeWidth="3" fill="none"/>}
</g>;
