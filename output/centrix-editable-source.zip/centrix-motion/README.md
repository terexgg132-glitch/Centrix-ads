# Centrix — From busy to simple

A continuous 30-second 2D motion advertisement in Egyptian Arabic. React + TypeScript + Remotion 4.0.535. 1080 × 1920, 30 fps, 900 frames.

## Preview and export

```sh
npm ci
npm run dev
npm run lint
npm run render
```

The main composition is `Centrix-Reel`. Its five scene components also have separate Studio timelines. The final MP4 is H.264 / AAC / yuv420p, CRF 17. On Linux, the config uses the installed `/usr/bin/chromium`; on other systems Remotion uses its normal browser selection.

## Editing

- `src/CentrixAd.tsx`: authored overlapping scene timings, circular stage reveals, and audio.
- `src/scenes/`: problem, brand reveal, attendance, organization, and outro.
- `src/components.tsx`: complete-word RTL animation, logo treatment, editable vector icons, expressive avatars, and student cards.
- `src/design.ts`: brand palette, spring damping/stiffness/mass, font loading, and interpolation helpers. All animation is frame-based and deterministic.
- `public/fonts/`: locally bundled Cairo variable font and its OFL license. Rendering needs no font network requests.
- `public/brand/centrix-original.png`: the unchanged uploaded asset. Despite its uploaded `.svg` filename, the file contains a PNG. The logo component uses the supplied emblem with SVG masking and a flat blue/cyan concept treatment. The original geometric mark is retained. An approved true SVG can replace this source.
- `public/audio/centrix-soundtrack.wav`: original stereo 120 BPM music and authored motion cues.
- Composition props: `sound`, `concept`, `voiceoverFile`, and `parentNotifications`. Keep `concept: true` for this preview.

Place an optional aligned 30-second voiceover in `public/audio/voiceover.wav` and set `voiceoverFile: "audio/voiceover.wav"`. Music volume is reduced automatically. See `docs/voiceover.md` for the Egyptian script and cues.

## Creative and factual scope

See `docs/storyboard.md` for the visual system, timing, and object handoffs. Attendance recording, parent notifications, and student management were confirmed shipped by the user. No unsupported integrations or additional product capabilities are claimed. The frame label «تصوّر إعلاني» identifies this as a concept preview.

The motion reference is the general language of expressive typography, rounded shapes, and object continuity in official brand films. No WhatsApp artwork, logo, trademark, interface styling, or endorsement is included.

## Verification

TypeScript and Remotion lint checks; representative 1080 × 1920 frames; Arabic word bounds and font checks; transition sampling; MP4 metadata and full decode check. The exported preview includes music and sound design; it does not include a synthetic voiceover.

Remotion's licensing terms apply to use of Remotion. Cairo is included under the bundled SIL Open Font License.
