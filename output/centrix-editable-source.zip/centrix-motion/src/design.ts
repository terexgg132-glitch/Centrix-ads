import {
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

loadFont({
  family: "Cairo",
  url: staticFile("fonts/Cairo-variable.ttf"),
  weight: "100 1000",
});

export const C = {
  blue: "#125AF6",
  ink: "#123373",
  cyan: "#5CE5EF",
  white: "#FFFFFF",
  pale: "#EDF4FF",
  muted: "#B9CEF5",
};
export const MOTION = { damping: 16, stiffness: 150, mass: 0.8 };
export const clamp = (n: number) => Math.min(1, Math.max(0, n));
export const mix = (a: number, b: number, p: number) => a + (b - a) * p;
export const ease = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.65, 0, 0.18, 1),
  });
export const pop = (f: number, start: number, duration = 28) =>
  spring({
    fps: 30,
    frame: f - start,
    durationInFrames: duration,
    config: MOTION,
  });
/** Normalize authored frame cues to 30fps while retaining Remotion's actual clock. */
export const useMotion = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (f * 30) / fps;
};

export type SceneProps = { readonly standalone?: boolean };
export type AdProps = {
  readonly sound: boolean;
  readonly concept: boolean;
  readonly voiceoverFile: string;
  readonly parentNotifications: boolean;
};
