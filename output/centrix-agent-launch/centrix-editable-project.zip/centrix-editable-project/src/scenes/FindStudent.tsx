import React from "react";
import { useCurrentFrame } from "remotion";
import {
  SceneFrame,
  C,
  Micro,
  p,
  Header,
  TaskLabel,
  Icon,
  Check,
  Rail,
} from "../design";
export const FindStudent = () => {
  const f = useCurrentFrame();
  const result = p(f, 56, 90);
  return (
    <SceneFrame grid>
      <Header number="02" label="UNDERSTAND" />
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 175,
          left: 150,
          right: 150,
          textAlign: "center",
          fontSize: 76,
          fontWeight: 500,
          opacity: p(f, 0, 24),
          translate: `0 ${(1 - p(f, 0, 24)) * 40}px`,
        }}
      >
        «دوّر على الطالب عمر أحمد»
      </div>
      <div
        style={{
          position: "absolute",
          top: 360,
          left: 395,
          width: 1130,
          height: 395,
          background: "linear-gradient(130deg,#1c1d1c,#090b0e)",
          border: "1px solid #c7a56155",
          borderRadius: 26,
          boxShadow: "0 40px 110px #000a",
          transform: `perspective(1700px) rotateX(${(1 - result) * 10}deg) translateY(${(1 - p(f, 18, 48)) * 180}px)`,
          opacity: p(f, 18, 48),
        }}
      >
        <div
          dir="rtl"
          style={{
            position: "absolute",
            right: 52,
            top: 45,
            fontSize: 25,
            color: C.gold,
          }}
        >
          الطلاب <span style={{ color: "#686b6d" }}> / بحث بالاسم</span>
        </div>
        <div
          style={{
            position: "absolute",
            top: 115,
            left: 50,
            right: 50,
            height: 1,
            background: "#ffffff12",
          }}
        />
        <div
          style={{
            opacity: 1 - result,
            position: "absolute",
            top: 175,
            left: 95,
            right: 95,
            display: "flex",
            gap: 14,
          }}
        >
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              style={{
                height: 80,
                flex: 1,
                background: `linear-gradient(100deg,#262621,#${i % 2 ? "3b3425" : "292b28"})`,
                borderRadius: 8,
              }}
            />
          ))}
        </div>
        <div
          dir="rtl"
          style={{
            position: "absolute",
            inset: "150px 55px 35px",
            display: "flex",
            alignItems: "center",
            gap: 30,
            opacity: result,
            translate: `0 ${(1 - result) * 30}px`,
          }}
        >
          <div
            style={{
              width: 122,
              height: 122,
              background: "#e8ba5512",
              border: "1px solid #e8ba5533",
              borderRadius: 22,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Icon name="student" size={70} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 59, fontWeight: 500 }}>عمر أحمد</div>
            <div style={{ fontSize: 27, color: C.muted, marginTop: 5 }}>
              الصف الثالث الثانوي <span style={{ padding: "0 20px" }}>·</span>{" "}
              كود 1042
            </div>
          </div>
          <Check size={72} />
        </div>
      </div>
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 804,
          left: 0,
          right: 0,
          textAlign: "center",
          fontSize: 31,
          color: C.gold,
          opacity: p(f, 94, 115),
        }}
      >
        فهم الطلب. ووصل للطالب.
      </div>
      <Rail progress={p(f, 20, 110) * 0.25} />
      <TaskLabel />
    </SceneFrame>
  );
};
