import React from 'react';
import {C,T,p,lin,lerp,visible,Corners} from './shared';
// The same 45 vector modules have four destinations. Identity survives each morph.
const source:number[][]=[];
for(let row=0;row<9;row++)for(let col=0;col<9;col++){
 const finder=(col<3&&row<3)||(col>5&&row<3)||(col<3&&row>5);
 if(finder||((row*7+col*11+row*col)%5<2))source.push([col*20,row*20]);
}
const n=source.length;
export const Student=({t}:{t:number})=>{
 const att=p(t,5.983,6.37),pay=p(t,6.766,7.16),follow=p(t,7.742,8.25),align=p(t,8.99,10.0);
 const entry=p(t,4.93,5.62);const fill=t<9.08?'#FBF8F0':C.panel;const ink=t<9.08?C.ink:C.ivory;
 const shrink=lerp(1,.39,align);
 const x=lerp(710,245,entry)+lerp(0,-48,align),y=lerp(1200,837,entry)+lerp(0,-140,align);
 const pull=p(t,18.1,19.8),fold=p(t,20.65,21.68);
 const currentX=lerp(lerp(x,150,pull),540,fold),currentY=lerp(lerp(y,641,pull),730,fold),scale=lerp(shrink,.30,pull)*(1-.98*fold);
 const fade=entry*(1-p(t,14.6,15.25)) + visible(t,18.05,21.68,.65);
 return <g opacity={Math.min(fade,1)} transform={`translate(${currentX} ${currentY}) scale(${scale}) rotate(${lerp(7,0,entry)*(1-align)})`}>
  <path d={`M0 0H590V${lerp(410,530,pay)*(1-.34*follow)}${pay>.05?'L570 '+(lerp(410,530,pay)*(1-.34*follow)-16)+' L550 '+(lerp(410,530,pay)*(1-.34*follow))+' L530 '+(lerp(410,530,pay)*(1-.34*follow)-16)+' L510 '+(lerp(410,530,pay)*(1-.34*follow))+' L490 '+(lerp(410,530,pay)*(1-.34*follow)-16):''}H0Z`} fill={fill} stroke={t<9.08?'#B3A68E':C.line} strokeWidth="2"/>
  <rect x="0" y="0" width="590" height="10" fill={C.gold}/>
  <T opacity={1-align} x={542} y={79} size={45} anchor="start" fill={ink} weight={700}>بطاقة الطالب</T>
  <T opacity={1-align} x={542} y={131} size={29} anchor="start" fill={t<9.08?'#897E6B':'#98948B'}>نموذج توضيحي</T>
  <g transform={`translate(62 ${lerp(204,265,pay)*(1-follow)+204*follow})`}>
  {source.map(([qx,qy],i)=>{
   const a=i/(n-1);const chk=a<.36?[lerp(0,52,a/.36),lerp(72,125,a/.36)]:[lerp(52,177,(a-.36)/.64),lerp(125,0,(a-.36)/.64)];
   const rec=[(i%9)*46,Math.floor(i/9)*22];
   const line=[a*425,lerp(110,110+Math.sin(a*Math.PI*2)*0,follow)];
   let mx=lerp(qx,chk[0],att),my=lerp(qy,chk[1],att);mx=lerp(mx,rec[0],pay);my=lerp(my,rec[1],pay);mx=lerp(mx,line[0],follow);my=lerp(my,line[1],follow);mx=lerp(mx,qx,pull);my=lerp(my,qy,pull);
   return <rect key={i} x={mx} y={my} width={lerp(lerp(14,38,pay),7,follow)} height={lerp(14,3,Math.max(pay,follow))} rx={lerp(1,1.5,att)} fill={i===n-1?C.gold:ink}/>;
  })}
  <path d="M-13 -13H191V191H-13Z" fill="none" stroke={ink} strokeWidth="2" opacity={1-att}/>
  <path d={`M-22 ${lerp(-17,190,lin(t,5.90,6.13))}H201`} stroke={C.gold} strokeWidth="4" opacity={visible(t,5.89,6.16,.08)}/>
  <circle cx={425*follow+185*(1-follow)} cy={110*follow+40*(1-follow)} r={lerp(8,13,follow)} fill={C.gold} opacity={att}/>
  {[0,.5,1].map(a=><g key={a} opacity={follow*(1-pull)}><circle cx={a*425} cy={110} r={10} fill={fill} stroke={C.gold} strokeWidth={3}/><path d={`M${a*425} 129V155`} stroke={C.gold} strokeWidth="2"/></g>)}
  </g>
  <g opacity={att*(1-pay)}><T x={524} y={270} size={49} anchor="start" fill={ink}>حاضر</T><T x={524} y={332} size={28} anchor="start" fill={t<9.08?'#897E6B':'#98948B'}>تم تسجيل الحضور</T></g>
  <g opacity={pay*(1-follow)}><T x={527} y={194} size={42} anchor="start" fill={ink}>سجل التحصيل</T><T x={527} y={235} size={28} anchor="start" fill={t<9.08?'#897E6B':'#98948B'}>دفعة الطالب</T><path d="M64 430H525" stroke="#C6BBA5" strokeWidth="2"/><T x={527} y={487} size={27} anchor="start" fill={ink}>عملية توضيحية</T></g>
  <T x={526} y={268} size={42} anchor="start" fill={ink} opacity={follow*(1-align)*(1-pull)}>مسار الطالب</T>
 </g>;
};
export const OperationWords=({t}:{t:number})=> <g>
 <T x={906} y={660+lerp(32,0,p(t,5.983,6.2))} size={166} anchor="start" weight={850} opacity={visible(t,5.983,6.766,.12)}>حضور</T>
 <T x={906} y={660+lerp(32,0,p(t,6.766,6.98))} size={158} anchor="start" weight={850} opacity={visible(t,6.766,7.742,.12)}>تحصيل</T>
 <T x={906} y={660+lerp(32,0,p(t,7.742,7.96))} size={156} anchor="start" weight={850} opacity={visible(t,7.742,8.99,.12)}>متابعة</T>
</g>;
