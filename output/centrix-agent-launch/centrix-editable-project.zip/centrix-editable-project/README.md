# CENTRIX — من الكلام للفعل

A 55-second Egyptian Arabic launch commercial. 1920 × 1080, 30 fps.

The idea is a visible change from answering a question to completing an operation. A golden command line activates a student lookup, records attendance, and retrieves that student's payments. A connected system sequence extends the idea across students, attendance, collection and reports. The final line is “سنتركس… سستم السنتر.”

## Edit and preview

```sh
npm ci
npm start
```

Open the Studio URL and choose **CentrixLaunch**. Each of the nine scenes is also registered separately under **Scenes**, with its own timeline. Scene durations and offsets are authored explicitly in `src/Film.tsx`. Copy, vector geometry, lighting, 3D projection, movement, colors and data are editable source, not baked screenshots.

## Export

```sh
npm run check
node scripts/render.mjs
```

Remotion can download a compatible browser. To use an existing browser, set `CHROME_PATH=/path/to/chromium`. Set `CENTRIX_OUTPUT` to choose a destination. The render uses H.264, CRF 16, YUV 4:2:0 and AAC audio. For Linux this production used Chromium at `/usr/bin/chromium`.

## Project map

- `src/scenes/`: the nine scene components.
- `src/design.tsx`: typography, original icon system, lighting, floor, command rails and shared components.
- `src/Mechanism.tsx`: original procedural 3D brass mechanism; geometry is projected and lit in SVG, frame by frame.
- `src/Film.tsx`: complete timeline and audio.
- `public/centrix-logo-exact.svg`: supplied logo, preserved byte for byte. The file contains an embedded raster image; `centrix-logo-original.png` is a lossless extraction of that exact embedded image for rendering.
- `public/fonts/`: bundled IBM Plex Sans Arabic and its SIL Open Font License.
- `public/audio/`: original music and sound effects, Egyptian Arabic narration and final mix.
- `scripts/create_score.py`: reproducible original score and sound effects, with no external samples. Requires NumPy and SciPy.
- `scripts/voice-script.json`: exact Egyptian Arabic copy and timeline.
- `scripts/generate_voice.py`: generates the Egyptian Arabic speech with `ar-EG-ShakirNeural`; requires edge-tts and permitted network access.
- `scripts/assemble_voice.py`: cleans and places the recorded segments; requires FFmpeg, NumPy and SciPy.

## Product representation and sources

The scenes are advertising visualizations, not screen recordings. Student names, identifiers, payments and dates are fictional example data. The operation sequence is one request at a time and does not imply bulk writes, money transfers, automatic messages or unrestricted access.

The official site was reviewed on 15 October 2026:

- https://centrix.company/
- https://centrix.company/features/ai-agent

The published scope supports natural-language student and data lookup, supported attendance operations, supported collection/payment operations and available reports. This commercial shows attendance execution and payment retrieval; it does not claim that all conceivable requests can be executed.

## Assets and rights

Brand artwork: supplied by the client. Motion, score and sound effects: created for this project. Fonts: SIL OFL, included. Speech is synthesized Egyptian Arabic; no voice has been cloned. Dependency licenses and any Remotion licensing obligations remain applicable.
