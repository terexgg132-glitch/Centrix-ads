import React from "react";
import { useCurrentFrame } from "remotion";
import {
  SceneFrame,
  C,
  Micro,
  p,
  Header,
  TaskLabel,
  Icon,
  Logo,
} from "../design";
export const Network = () => {
  const f = useCurrentFrame();
  const nodes = [
    { x: 340, y: 345, n: "student", t: "الطلاب" },
    { x: 1310, y: 345, n: "attendance", t: "الحضور" },
    { x: 340, y: 665, n: "money", t: "التحصيل" },
    { x: 1310, y: 665, n: "report", t: "التقارير" },
  ];
  return (
    <SceneFrame grid>
      <Header number="05" label="ONE CONNECTED SYSTEM" />
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 152,
          left: 120,
          right: 120,
          textAlign: "center",
          fontSize: 77,
          fontWeight: 500,
          opacity: p(f, 0, 23),
        }}
      >
        طلبك بيتحوّل لشغل.
      </div>
      <svg
        width="1920"
        height="1080"
        style={{ position: "absolute", inset: 0 }}
      >
        {nodes.map((n, i) => (
          <g key={i}>
            <path
              d={`M960 565C${n.x < 960 ? 720 : 1200} 565 ${n.x < 960 ? 780 : 1140} ${n.y + 80} ${n.x + 135} ${n.y + 80}`}
              fill="none"
              stroke="#e8ba5528"
              strokeWidth="2"
            />
            <path
              d={`M960 565C${n.x < 960 ? 720 : 1200} 565 ${n.x < 960 ? 780 : 1140} ${n.y + 80} ${n.x + 135} ${n.y + 80}`}
              fill="none"
              stroke={C.gold}
              strokeWidth="3"
              pathLength="1"
              strokeDasharray=".12 .88"
              strokeDashoffset={-((f / 95 + i * 0.22) % 1)}
              opacity={p(f, 30, 80)}
            />
          </g>
        ))}
      </svg>
      <div
        style={{
          position: "absolute",
          left: 780,
          top: 395,
          width: 360,
          height: 360,
          rotate: "45deg",
          border: "1px solid #edc66f88",
          background: "linear-gradient(140deg,#3c2f18,#090b0d 70%)",
          boxShadow: "0 0 120px #e8ba551c",
          scale: 0.7 + 0.3 * p(f, 10, 55),
        }}
      >
        <div
          style={{
            rotate: "-45deg",
            position: "absolute",
            inset: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <Icon name="spark" size={86} />
          <Micro style={{ fontSize: 23, letterSpacing: 5, marginTop: 30 }}>
            CENTRIX
          </Micro>
          <Micro
            style={{
              fontSize: 16,
              letterSpacing: 5,
              marginTop: 14,
              color: "#898479",
            }}
          >
            AI AGENT
          </Micro>
        </div>
      </div>
      {nodes.map((n, i) => (
        <div
          key={n.n}
          style={{
            position: "absolute",
            left: n.x,
            top: n.y,
            width: 270,
            height: 180,
            border: "1px solid #9d834858",
            borderRadius: 18,
            background: "linear-gradient(130deg,#1b1e20,#0a0c0f)",
            padding: 26,
            opacity: p(f, 20 + i * 13, 49 + i * 13),
            translate: `0 ${(1 - p(f, 20 + i * 13, 49 + i * 13)) * 30}px`,
            display: "flex",
            alignItems: "center",
            flexDirection: "column",
            gap: 18,
          }}
        >
          <Icon name={n.n} size={46} />
          <span dir="rtl" style={{ fontSize: 36 }}>
            {n.t}
          </span>
        </div>
      ))}
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 905,
          left: 130,
          right: 130,
          textAlign: "center",
          fontSize: 39,
          color: "#aaa498",
          opacity: p(f, 90, 120),
        }}
      >
        بيفهم السياق. بيتعامل مع أقسام النظام. وبينفّذ المطلوب.
      </div>
    </SceneFrame>
  );
};
