"""Original procedural score and UI foley. No samples / external music.
48 kHz stereo, deterministic seed, voice-driven bed ducking.
"""
import numpy as np, subprocess, json, os
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=Path(os.environ.get('CENTRIX_OUTPUT',str(ROOT/'renders'))).resolve();OUT.mkdir(parents=True,exist_ok=True);SR=48000;N=SR*27
rng=np.random.default_rng(2017)
music=np.zeros((N,2));sfx=music.copy()
def add(dst,start,signal,level=1,pan=0):
 i=round(start*SR);sig=np.asarray(signal)*level
 if sig.ndim==1:sig=np.stack([sig*np.sqrt((1-pan)/2),sig*np.sqrt((1+pan)/2)],axis=1)
 if i<0:sig=sig[-i:];i=0
 n=min(len(sig),len(dst)-i)
 if n>0:dst[i:i+n]+=sig[:n]
def tone(freq,dur,decay=4,fm=0.1):
 t=np.arange(round(dur*SR))/SR
 env=(1-np.exp(-t*100))*np.exp(-t*decay)*(np.minimum((dur-t)*12,1))
 return (np.sin(2*np.pi*freq*t+fm*np.sin(2*np.pi*freq*2.005*t))+.15*np.sin(2*np.pi*freq*3*t))*env

def click(dur=.07,bright=2200):
 t=np.arange(int(dur*SR))/SR;n=rng.normal(0,1,len(t));s=sosfilt(butter(2,bright,fs=SR,output='sos'),n)
 return s*np.exp(-t*70)+.25*np.sin(2*np.pi*(450+150*np.exp(-t*70))*t)*np.exp(-t*90)
def paper(dur=.18):
 t=np.arange(int(dur*SR))/SR;n=rng.normal(size=len(t));n=sosfilt(butter(2,[1000,7500],btype='band',fs=SR,output='sos'),n)
 return n*np.sin(np.pi*t/dur)**2*np.exp(-t*15)*.75+click(dur)*.18
def kick():
 t=np.arange(int(.35*SR))/SR;f=48+70*np.exp(-t*40);ph=2*np.pi*np.cumsum(f)/SR
 return np.sin(ph)*np.exp(-t*17)*(1-np.exp(-t*1100))
def sweep(dur=.26):
 t=np.arange(int(dur*SR))/SR;n=rng.normal(size=len(t));n=sosfilt(butter(2,[600,4500],btype='band',fs=SR,output='sos'),n)
 return n*np.sin(np.pi*t/dur)**3*.5+np.sin(2*np.pi*(340*t+200*t*t))*np.sin(np.pi*t/dur)**2*.1
# Narrative punctuation from a shared, authored timbre family.
add(sfx,.12,click(.045),.13,-.18)
for j,st in enumerate([3.23,4.59,5.23]):add(sfx,st,paper(),.17,[-.3,.28,0][j])
add(sfx,5.983,tone(1174.66,.115,18,.3),.11,.1)
add(sfx,6.766,click(.095,1800),.21,-.15)
add(sfx,7.742,sweep(.26),.13,.18)
add(sfx,8.99,click(.10,3200),.12)
add(sfx,8.99,tone(146.83,.6,7,.7),.10)
add(sfx,12.715,tone(293.66,.5,8,.3)+tone(440,.5,9,.2)*.25,.09)
for st in [15.69,15.83,15.98,16.14,16.30,16.46]:add(sfx,st,click(.025,4000),.025,.18)
add(sfx,17.04,tone(880,.28,13,.2),.07)
# Bare intro sub texture, almost silence.
add(music,.15,tone(55,2.5,1.1,.18),.035)
# 108 BPM clock; percussive idea is paper/scanner/click, never a stock loop.
beat=60/108
for k in range(11):
 st=3.233+k*beat
 if st>8.72:break
 add(music,st,click(.065,2600) if k%3 else paper(.10),.035,(-1)**k*.25)
 if k%2==0:add(music,st+.75*beat,tone(587.33,.11,22,.35),.018,-.1)
 notes=[73.416,73.416,55,65.406,73.416,87.307]
 add(music,st,tone(notes[k%6],.45,5,.12),.039)
# Modern restrained groove, with drop for AI explanation.
for k in range(23):
 st=9.11+k*beat
 if st>=21.45:break
 if not 14.68<=st<18.26:
  if k%2==0:add(music,st,kick(),.11)
  if k%2:add(music,st,click(.085,1800),.044,.1)
  add(music,st+.75*beat,paper(.055),.034,-.2)
  add(music,st,tone(notes[k%6],.45,5,.12),.072)
 if k%4==0:add(music,st+.5*beat,tone([293.66,349.23,440][(k//4)%3],1.0,3,.5),.028,.25)
# Airy harmonic bed handoff around assistant: D / F / A, highpass softness.
for st in [9.0,12.33,14.75,18.15]:
 dur=3.1
 pad=sum(tone(fr,dur,.8,.05) for fr in [293.66,349.23,440])/3
 add(music,st,pad,.027)
# Resolve the same scanner timbre into a 3-note brand motif: D5 / A4 / F5.
for st,fr,dur in [(21.70,587.33,2.0),(22.12,440,2.0),(22.83,698.46,3.4)]:
 add(music,st,tone(fr,dur,1.5,.48),.066)
 add(music,st+.045,tone(fr*2,dur,2.3,.1),.012,.32)
add(sfx,21.66,click(.08,1500),.08)
add(music,21.70,tone(73.416,4.6,1.0,.14),.056)
# Sample-derived ducking without changing narration.
p=ROOT/'public/assets/centrix_voiceover_original.mp3'
b=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-ar',str(SR),'-ac','2','-f','f32le','-'])
v=np.frombuffer(b,dtype='<f4').reshape(-1,2);voice=np.zeros((N,2));voice[:len(v)]=v
mono=np.mean(voice,axis=1);win=int(.03*SR);rms=np.sqrt(np.convolve(mono**2,np.ones(win)/win,'same'))
# Smooth anticipation/hold/release: 8 dB duck at speech energy.
activity=np.clip((rms-.006)/.026,0,1);hold=np.maximum.reduce([np.roll(activity,j) for j in [0,-2400,-1200,1200,2400,4800]])
sm=sosfilt(butter(1,3,fs=SR,output='sos'),hold);duck=1-.63*sm
music*=duck[:,None]
# Intentional 100ms silence contrast before activation (voice continues).
for a,b in [(8.88,8.99),(21.52,21.66)]:
 music[int(a*SR):int(b*SR)]=0;sfx[int(a*SR):int(b*SR)]=0
fade=np.clip((27-np.arange(N)/SR)/1.35,0,1);music*=fade[:,None];sfx*=fade[:,None]
music*=np.where(np.arange(N)/SR<3,1.0,3.8)[:,None];sfx*=1.25
# Leave voice untouched. Mix has a conservative common static gain.
mix=voice+music+sfx
peak=np.max(np.abs(mix));gain=min(10**(2.2/20),.88/peak)
def write(p,x):wavfile.write(str(p),SR,np.int32(np.clip(x,-1,1)*2147483647))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-ar',str(SR),'-ac','2','-c:a','pcm_s24le',str(OUT/'centrix-voice.wav')],check=True)
write(OUT/'centrix-original-music.wav',music);write(OUT/'centrix-sfx.wav',sfx)
write(ROOT/'public/assets/centrix-full-mix.wav',mix*gain)
write(OUT/'centrix-full-mix.wav',mix*gain)
json.dump({'sample_rate':SR,'duration':27,'voice_samples':len(v),'voice_duration':len(v)/SR,'static_master_gain':gain,'pre_gain_peak':float(peak),'ducking_db':8,'original_music':'procedural deterministic composition, no sampled recordings'},open(OUT/'audio-report.json','w'),indent=2)
# Waveform inspection with cue times.
import os;os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.review/mpl'))
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(16,3));tt=np.arange(len(mono))/SR;ax.plot(tt[::240],mono[::240],lw=.5,color='#30302D')
for st in [.306,3.233,4.596,5.983,6.766,7.742,8.876,10.005,12.715,14.685,16.236,18.526,21.661,22.513,23.519]:ax.axvline(st,color='#B58B38',lw=.6)
ax.set(xlim=(0,27),xlabel='Seconds — original decoded voice, no trimming');fig.tight_layout();(ROOT/'.review').mkdir(exist_ok=True);fig.savefig(ROOT/'.review/voice-waveform.png',dpi=120)
print('Original audio samples',len(v),'gain',gain,'peak',peak)
