import { AbsoluteFill } from "remotion";
import { C, ease, mix, pop, useMotion, SceneProps } from "../design";
import { Avatar, Check, Icon, Words } from "../components";

const items = [
  {
    x: 282,
    y: 480,
    w: 290,
    h: 170,
    r: -12,
    kind: "students",
    label: "٣٢ طالب",
  },
  {
    x: 811,
    y: 563,
    w: 244,
    h: 176,
    r: 14,
    kind: "calendar",
    label: "المواعيد",
  },
  { x: 171, y: 660, w: 154, h: 154, r: -16, kind: "check", label: "" },
  { x: 910, y: 1174, w: 145, h: 170, r: 11, kind: "note", label: "" },
  { x: 244, y: 1308, w: 279, h: 169, r: 9, kind: "note", label: "الملاحظات" },
  { x: 801, y: 1365, w: 274, h: 178, r: -13, kind: "bell", label: "المتابعة" },
  { x: 535, y: 1490, w: 194, h: 180, r: 7, kind: "avatar", label: "" },
  { x: 552, y: 368, w: 152, h: 146, r: 10, kind: "calendar", label: "" },
];
export const Problem: React.FC<SceneProps> = ({ standalone = false }) => {
  const f = useMotion();
  const fold = ease(f, 133, 178);
  const exit = ease(f, 175, 186);
  return (
    <AbsoluteFill style={{ background: standalone ? C.blue : undefined }}>
      <div
        style={{
          position: "absolute",
          left: 85,
          top: 710,
          width: 910,
          zIndex: 2,
          translate: `0 ${-160 * ease(f, 128, 158)}px`,
          opacity: 1 - ease(f, 135, 159),
          scale: mix(1, 0.93, ease(f, 128, 158)),
        }}
      >
        <Words text="طلاب كتير..." start={4} size={140} />
        <Words text="وتفاصيل أكتر؟" start={32} size={106} color={C.cyan} />
      </div>
      {items.map((o, i) => {
        const p = pop(f, 14 + i * 10);
        const theta = (i * Math.PI) / 4 - Math.PI / 2 + 0.16 * fold;
        const x = mix(
          o.x + Math.sin(f * 0.033 + i) * 3,
          540 + Math.cos(theta) * 218,
          fold,
        );
        const y = mix(
          o.y + Math.cos(f * 0.026 + i) * 4,
          1040 + Math.sin(theta) * 218,
          fold,
        );
        const w = mix(o.w, 82, fold);
        const h = mix(o.h, 82, fold);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x - w / 2,
              top: y - h / 2,
              width: w,
              height: h,
              borderRadius: mix(28, 45, fold),
              background: i % 3 === 0 ? C.cyan : C.white,
              scale: mix(0, 1, p) * (1 - exit),
              rotate: `${mix(o.r, (theta * 180) / Math.PI + 90, fold)}deg`,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: o.w,
                height: o.h,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 14,
                opacity: 1 - ease(f, 138, 161),
                scale: mix(1, 0.7, fold),
                transformOrigin: "top left",
              }}
            >
              {o.kind === "avatar" ? (
                <Avatar variant={2} size={114} />
              ) : o.kind === "check" ? (
                <Check size={80} />
              ) : (
                <Icon
                  kind={o.kind as "students" | "calendar" | "note" | "bell"}
                  size={o.label ? 67 : 85}
                />
              )}
              {o.label && (
                <span
                  style={{
                    fontFamily: "Cairo",
                    fontSize: 32,
                    fontWeight: 800,
                    color: C.blue,
                    direction: "rtl",
                  }}
                >
                  {o.label}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
