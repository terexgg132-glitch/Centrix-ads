# Official product verification

Checked on 14 October 2026. Only the official Centrix site informed the illustrated UI.

| Depiction | Official evidence | Implementation |
|---|---|---|
| Student is the central operational record | https://centrix.company/ | One persistent student card and registration point |
| QR can identify a student for attendance and supported payment operations | https://centrix.company/features/qr-operations | Three separate illustrative operations; no automatic completion from a single scan |
| Attendance, accounts, collection, reporting and follow-up belong to the same system | https://centrix.company/ | Integrated illustrative operational board with labels, no invented numerical metrics |
| Natural-language attendance/absence queries and supported data/report operations | https://centrix.company/features/ai-agent | «مين غاب النهارده؟», source-labeled attendance result; no names or specific counts |
| Original brand artwork and requested tagline | Supplied `centrix_logo_original.svg` and user brief | Original SVG displayed directly; «سستم السنتر» and website below |

The official AI feature page gives a comparable attendance question and explicitly limits operations to supported product functionality. The film does not depict sending messages, moving money outside the product, or executing unrestricted autonomous actions. Its demo results card identifies the lesson register as the source and is labeled as an illustrative example with test data.
