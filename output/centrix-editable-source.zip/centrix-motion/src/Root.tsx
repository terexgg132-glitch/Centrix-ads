import { Composition, Folder } from "remotion";
import { CentrixAd } from "./CentrixAd";
import { Problem } from "./scenes/Problem";
import { Reveal } from "./scenes/Reveal";
import { Attendance } from "./scenes/Attendance";
import { Organization } from "./scenes/Organization";
import { Outro } from "./scenes/Outro";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="Centrix-Reel"
        component={CentrixAd}
        durationInFrames={900}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{
          sound: true,
          concept: true,
          voiceoverFile: "",
          parentNotifications: true,
        }}
      />
      <Folder name="Scenes">
        <Composition
          id="Problem"
          component={Problem}
          durationInFrames={188}
          fps={30}
          width={1080}
          height={1920}
          defaultProps={{ standalone: true }}
        />
        <Composition
          id="Brand-Reveal"
          component={Reveal}
          durationInFrames={152}
          fps={30}
          width={1080}
          height={1920}
          defaultProps={{ standalone: true }}
        />
        <Composition
          id="Attendance"
          component={Attendance}
          durationInFrames={246}
          fps={30}
          width={1080}
          height={1920}
          defaultProps={{ standalone: true, parentNotifications: true }}
        />
        <Composition
          id="Organization"
          component={Organization}
          durationInFrames={281}
          fps={30}
          width={1080}
          height={1920}
          defaultProps={{ standalone: true }}
        />
        <Composition
          id="Outro"
          component={Outro}
          durationInFrames={195}
          fps={30}
          width={1080}
          height={1920}
          defaultProps={{ standalone: true }}
        />
      </Folder>
    </>
  );
};
