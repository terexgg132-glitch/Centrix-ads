"""Verify codec, length, streams, exact frame count and full decode integrity."""
import json,subprocess,sys,hashlib
from pathlib import Path
p=Path(sys.argv[1]); info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]))
v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1920,1080)
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
assert v['r_frame_rate']=='30/1' and int(v['nb_read_frames'])==1650
assert a['codec_name']=='aac' and int(a['channels'])==2 and int(a['sample_rate'])==48000
assert abs(float(info['format']['duration'])-55)<.1
r=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],capture_output=True,text=True,check=True)
assert not r.stderr.strip(),r.stderr
report={'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'duration_seconds':float(info['format']['duration']),'width':v['width'],'height':v['height'],'frames':int(v['nb_read_frames']),'fps':v['r_frame_rate'],'video_codec':v['codec_name'],'pixel_format':v['pix_fmt'],'audio_codec':a['codec_name'],'audio_sample_rate':a['sample_rate'],'audio_channels':a['channels'],'decode_errors':r.stderr.strip(),'checks_passed':True}
p.with_suffix('.verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
