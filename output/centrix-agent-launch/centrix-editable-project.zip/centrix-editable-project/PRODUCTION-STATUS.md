# Production status

Picture, original music and sound effects are complete. Egyptian Arabic narration has not yet been generated: Runway lacked credits, and the alternative speech endpoint is blocked by the cloud network allowlist. The 55-second MP4 currently supplied as a review has music and effects, but no speech.

The final narration script, timing, generation, assembly and mastering scripts are ready. After speech.platform.bing.com is permitted, run the voice pipeline, add the completed master to the main composition, and export the final. Do not label the current review as the completed voiced advertisement.
