import React from 'react';
import {AbsoluteFill,Composition,Folder,Sequence,useVideoConfig,staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {ControlMachine} from './ControlMachine';
import {HookV2,ChaosV2,AssistantV2,ConnectedV2,BrandV2} from './Scenes';
export const FilmV2:React.FC<{audioEnabled?:boolean}>=({audioEnabled=true})=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#020204'}}>
<Sequence name="The teaching day begins earlier" durationInFrames={81} premountFor={fps}><HookV2/></Sequence>
<Sequence name="The hidden work" from={81} durationInFrames={98} premountFor={fps}><ChaosV2/></Sequence>
<Sequence name="From operations to one system" from={179} durationInFrames={261} premountFor={fps}><ControlMachine/></Sequence>
<Sequence name="Ask Centrix" from={440} durationInFrames={96} premountFor={fps}><AssistantV2/></Sequence>
<Sequence name="Connected teaching day" from={536} durationInFrames={114} premountFor={fps}><ConnectedV2/></Sequence>
<Sequence name="Authentic brand resolve" from={650} durationInFrames={160} premountFor={fps}><BrandV2/></Sequence>
{audioEnabled&&<Audio src={staticFile('assets/v2/Centrix_Final_Mix.wav')} premountFor={fps}/>}
</AbsoluteFill>};
export const CentralTestV2:React.FC<{audioEnabled?:boolean}>=({audioEnabled=true})=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#08080B'}}>
<Sequence name="Continuous operation-to-system morph" from={-1} durationInFrames={261} premountFor={fps}><ControlMachine/></Sequence>
{audioEnabled&&<Audio src={staticFile('assets/v2/Centrix_Final_Mix.wav')} trimBefore={6*fps} premountFor={fps}/>}
</AbsoluteFill>};
export const RootV2:React.FC=()=> <>
<Composition id="Centrix-V2-Final" component={FilmV2} width={1080} height={1920} fps={30} durationInFrames={810} defaultProps={{audioEnabled:true}}/>
<Composition id="Centrix-V2-Style-Test" component={CentralTestV2} width={1080} height={1920} fps={30} durationInFrames={240} defaultProps={{audioEnabled:true}}/>
<Folder name="V2-Scenes">
<Composition id="Centrix-V2-Hook" component={HookV2} width={1080} height={1920} fps={30} durationInFrames={81}/>
<Composition id="Centrix-V2-Chaos" component={ChaosV2} width={1080} height={1920} fps={30} durationInFrames={98}/>
<Composition id="Centrix-V2-Control-Machine" component={ControlMachine} width={1080} height={1920} fps={30} durationInFrames={261} defaultProps={{start:179}}/>
<Composition id="Centrix-V2-Assistant" component={AssistantV2} width={1080} height={1920} fps={30} durationInFrames={96}/>
<Composition id="Centrix-V2-Connected" component={ConnectedV2} width={1080} height={1920} fps={30} durationInFrames={114}/>
<Composition id="Centrix-V2-Brand" component={BrandV2} width={1080} height={1920} fps={30} durationInFrames={160}/>
</Folder>
</>;
