import React from "react";
import { useCurrentFrame } from "remotion";
import {
  SceneFrame,
  C,
  Micro,
  p,
  Header,
  TaskLabel,
  Icon,
  Rail,
  Check,
} from "../design";
export const Finance = () => {
  const f = useCurrentFrame();
  const done = p(f, 55, 85);
  return (
    <SceneFrame grid>
      <Header number="04" label="DELIVER" />
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 170,
          left: 150,
          right: 150,
          textAlign: "center",
          fontSize: 80,
          fontWeight: 500,
          opacity: p(f, 0, 25),
        }}
      >
        «اعرض مدفوعاته»
      </div>
      <div
        style={{
          position: "absolute",
          left: 235,
          top: 355,
          width: 1450,
          height: 450,
          display: "flex",
          gap: 30,
          opacity: p(f, 20, 47),
          translate: `0 ${(1 - p(f, 20, 47)) * 60}px`,
        }}
      >
        <div
          dir="rtl"
          style={{
            width: 430,
            border: "1px solid #cba35366",
            borderRadius: 24,
            background: "linear-gradient(145deg,#302819,#0a0c0d)",
            padding: 44,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <Icon name="money" size={62} />
          <div>
            <div style={{ fontSize: 30, color: "#aaa596" }}>إجمالي المدفوع</div>
            <div
              style={{
                fontSize: 102,
                color: C.pale,
                lineHeight: 1.3,
                fontFamily: "Arial",
                fontWeight: 400,
              }}
            >
              {Math.round(600 * done).toLocaleString("en-US")}
            </div>
            <div style={{ fontSize: 26, color: C.gold }}>جنيه مصري</div>
          </div>
        </div>
        <div
          dir="rtl"
          style={{
            flex: 1,
            border: "1px solid #45423a",
            borderRadius: 24,
            background: "linear-gradient(125deg,#191b1d,#0a0d10)",
            padding: 44,
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 25,
            }}
          >
            <div style={{ fontSize: 39 }}>مدفوعات عمر أحمد</div>
            <Micro style={{ fontSize: 17, color: "#92928d", letterSpacing: 3 }}>
              1042 / STUDENT
            </Micro>
          </div>
          {[
            { a: "اشتراك سبتمبر", b: "300" },
            { a: "اشتراك أكتوبر", b: "300" },
          ].map((r, i) => (
            <div
              key={i}
              style={{
                height: 112,
                display: "flex",
                alignItems: "center",
                borderTop: "1px solid #ffffff13",
                gap: 30,
                opacity: p(f, 58 + i * 10, 84 + i * 10),
              }}
            >
              <Icon name="check" size={32} />
              <div style={{ fontSize: 32, flex: 1 }}>{r.a}</div>
              <div style={{ fontSize: 35, color: C.gold }}>
                {r.b}
                <span style={{ fontSize: 22, color: C.muted, marginRight: 13 }}>
                  جنيه
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Rail progress={0.5 + 0.25 * p(f, 30, 100)} />
      <TaskLabel />
    </SceneFrame>
  );
};
