import React from "react";
import { useCurrentFrame } from "remotion";
// A deterministic, editable vector renderer for a sculptural brass command mechanism.
// All geometry, lighting, depth sorting and camera projection are evaluated per frame.
type V = [number, number, number];
const add = (a: V, b: V): V => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const rotate = (v: V, ax: number, ay: number, az: number): V => {
  let [x, y, z] = v;
  [y, z] = [
    y * Math.cos(ax) - z * Math.sin(ax),
    y * Math.sin(ax) + z * Math.cos(ax),
  ];
  [x, z] = [
    x * Math.cos(ay) + z * Math.sin(ay),
    -x * Math.sin(ay) + z * Math.cos(ay),
  ];
  [x, y] = [
    x * Math.cos(az) - y * Math.sin(az),
    x * Math.sin(az) + y * Math.cos(az),
  ];
  return [x, y, z];
};
export const Mechanism = ({
  style = {},
  opacity = 1,
  scale = 1,
}: {
  style?: React.CSSProperties;
  opacity?: number;
  scale?: number;
}) => {
  const f = useCurrentFrame();
  const polys: { v: V[]; z: number; color: string }[] = [];
  for (let ring = 0; ring < 4; ring++) {
    const a = 230 - ring * 47,
      b = a - 14 - ring * 1.3,
      d = 15 + ring * 4,
      phi = (f / 230) * (ring % 2 ? 1 : -1) + ring * 0.37;
    const q = (v: V) =>
      rotate(
        rotate(v, phi * 0.45, phi * 0.7, Math.PI / 4),
        0.42,
        -0.48,
        f * 0.0011,
      );
    for (let side = 0; side < 4; side++) {
      const local: V[] = [
        [-a, a, d],
        [a, a, d],
        [b, b, d],
        [-b, b, d],
        [-a, a, -d],
        [a, a, -d],
        [b, b, -d],
        [-b, b, -d],
      ];
      const verts = local.map((v) => q(rotate(v, 0, 0, (side * Math.PI) / 2)));
      for (const [inds, base] of [
        [[0, 1, 2, 3], 0.85],
        [[4, 7, 6, 5], 0.35],
        [[0, 4, 5, 1], 0.53],
        [[3, 2, 6, 7], 0.62],
        [[0, 3, 7, 4], 0.35],
      ] as [number[], number][]) {
        const vv = inds.map((i) => verts[i]);
        const light = base + 0.15 * Math.sin(phi + side * 1.4);
        polys.push({
          v: vv,
          z: vv.reduce((s, v) => s + v[2], 0) / 4,
          color: `rgb(${Math.round(220 * light)},${Math.round(173 * light)},${Math.round(76 * light)})`,
        });
      }
    }
  }
  polys.sort((a, b) => a.z - b.z);
  const project = (v: V) => {
    const k = 800 / (800 - v[2]);
    return `${450 + v[0] * k * scale},${450 + v[1] * k * scale}`;
  };
  return (
    <svg
      viewBox="0 0 900 900"
      width="900"
      height="900"
      style={{ position: "absolute", opacity, ...style }}
    >
      <defs>
        <radialGradient id="mechGlow">
          <stop stopColor="#e8ba55" stopOpacity=".15" />
          <stop offset="1" stopColor="#e8ba55" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="polish" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#fff8e0" stopOpacity=".5" />
          <stop offset=".25" stopColor="#fff8e0" stopOpacity="0" />
          <stop offset=".7" stopColor="#ffe59a" stopOpacity=".25" />
          <stop offset="1" stopColor="#ffe59a" stopOpacity="0" />
        </linearGradient>
      </defs>
      <ellipse cx="450" cy="450" rx="430" ry="430" fill="url(#mechGlow)" />
      {polys.map((q, i) => (
        <g key={i}>
          <polygon
            points={q.v.map(project).join(" ")}
            fill={q.color}
            stroke="#f1d28a"
            strokeWidth=".65"
            strokeOpacity=".55"
          />
          <polygon points={q.v.map(project).join(" ")} fill="url(#polish)" />
        </g>
      ))}
    </svg>
  );
};
