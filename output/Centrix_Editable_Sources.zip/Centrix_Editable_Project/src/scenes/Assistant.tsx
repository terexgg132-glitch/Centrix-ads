import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BG,C,Text,Label,Thread,Plate,Icon,Concept,prog,mix,useScene} from '../design';
export const Assistant:React.FC=()=>{const {f,fps}=useScene();const enter=prog(f,0,17),q=prog(f,.17*fps,13),response=prog(f,1.72*fps,16);return <AbsoluteFill>
<BG frame={f+440}/><Label index="CENTRIX / AI AGENT">اسأل عن تفاصيل يومك</Label>
<Text y={342} size={73} style={{opacity:enter}}>ومحتاج تعرف حاجة؟</Text>
<Text y={462} size={46} color={C.gold} style={{opacity:prog(f,1.57*fps,12)}}>اسأل مساعد سنتريكس الذكي</Text>
<Thread d="M45 1380C185 1380 131 1230 131 975C131 660 268 561 538 561C818 561 949 668 949 944" p={enter} opacity={.55} width={2.4}/>
<Plate x={140} y={616} w={800} h={779} active style={{translate:'0 '+mix(52,0,enter)+'px',opacity:enter,scale:mix(.95,1,enter)}}>
 <div style={{position:'absolute',left:35,top:29}}><Icon type="ai" size={80}/></div>
 <Text x={130} y={45} w={627} size={49} align="right">مساعد سنتريكس</Text>
 <div style={{position:'absolute',left:34,right:34,top:147,borderTop:'1px solid #776F5B44'}}/>
 <div style={{position:'absolute',left:32,top:197,width:736,height:244,borderRadius:25,background:'linear-gradient(130deg,#3B33241C,#DDB34B15)',border:'1px solid #DDB34B55',opacity:q,translate:'0 '+mix(25,0,q)+'px'}}>
 <Text x={32} y={38} w={667} size={49} weight={700} align="right">مين غاب النهارده في<br/>مجموعة مستر محمد؟</Text>
 </div>
 <div style={{position:'absolute',left:32,top:483,width:736,height:240,opacity:response,translate:'0 '+mix(24,0,response)+'px'}}>
 <Text x={22} y={1} w={682} size={33} weight={650} color={C.gold} align="right">نتيجة توضيحية</Text>
 <Text x={22} y={54} w={682} size={40} weight={750} align="right">عرض كشف الغياب للمجموعة</Text>
 <div style={{position:'absolute',left:22,top:133,display:'flex',gap:17,alignItems:'center',width:682,flexDirection:'row-reverse'}}>
  <div style={{width:49,height:49,borderRadius:50,background:'#98917C22'}}/>
  <div style={{flex:1,height:10,background:'#857B6555',borderRadius:10}}/>
  <div style={{width:110,height:32,border:'1px solid #DDB34B66',borderRadius:9,background:'#DDB34B14'}}/>
 </div>
 <Text x={22} y={193} w={682} size={28} color={C.gray} align="right">مثال بدون بيانات طلاب حقيقية</Text>
 </div>
</Plate><Concept/>
</AbsoluteFill>};
