from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]; out=root/'output'; name='Centrix_Editable_Project/'
target=out/'Centrix_Editable_Sources.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts','.gitignore','README.md','requirements-audio.txt']:
  z.write(root/p,name+p)
 for folder in ['src','scripts','assets','public','production_reference']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in str(p) and 'public/review/' not in p.relative_to(root).as_posix():
    z.write(p,name+p.relative_to(root).as_posix())
 for p in [out/'Centrix_Assets_Manifest.json',out/'Centrix_Audio_Cue_Sheet.csv',out/'review/validation.json',out/'review/Production_Report.md']:
  if p.exists():z.write(p,name+'documentation/'+p.name)
 for p in (out/'audio').glob('*'):
  if p.name.startswith('Centrix_') and p.is_file():z.write(p,name+'audio/'+p.name)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 names=z.namelist()
 assert name+'src/Root.tsx' in names
 assert name+'assets/centrix_logo_original.svg' in names
 assert name+'public/fonts/OFL.txt' in names
 print('Verified source archive:',target.stat().st_size,'bytes;',len(names),'files')
