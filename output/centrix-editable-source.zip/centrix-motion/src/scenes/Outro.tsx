import { AbsoluteFill } from "remotion";
import { C, ease, mix, pop, useMotion, SceneProps } from "../design";
import { BrandMark, Wordmark, Words } from "../components";

export const Outro: React.FC<SceneProps> = ({ standalone = false }) => {
  const f = useMotion();
  const emerge = ease(f, 8, 46);
  const logo = pop(f, 12, 44);
  const tap = ease(f, 137, 143) - ease(f, 144, 155);
  return (
    <AbsoluteFill style={{ background: standalone ? C.blue : undefined }}>
      <div
        style={{
          position: "absolute",
          left: 540 - 235,
          top: mix(1135 - 235, 431, emerge),
          width: 470,
          height: 470,
          borderRadius: mix(95, 235, emerge),
          background: C.cyan,
          scale: mix(0.55, 1, logo),
          rotate: `${mix(90, 0, emerge)}deg`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: ease(f, 8, 20),
        }}
      >
        <div style={{ rotate: `${mix(-90, 0, emerge)}deg` }}>
          <BrandMark
            size={329}
            color={C.blue}
            progress={ease(f, 20, 43)}
            id="outro"
          />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 90,
          top: 938,
          width: 900,
          textAlign: "center",
          scale: pop(f, 34, 30),
          opacity: ease(f, 34, 47),
        }}
      >
        <Wordmark size={150} />
      </div>
      <div style={{ position: "absolute", left: 90, top: 1152, width: 900 }}>
        <Words text="ركّز في الشرح،" start={48} size={84} />
        <Words text="وسيب التنظيم علينا" start={67} size={76} color={C.cyan} />
      </div>
      <div
        style={{
          position: "absolute",
          left: 237,
          top: 1506,
          width: 606,
          height: 144,
          borderRadius: 76,
          background: C.cyan,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 32,
          scale: pop(f, 94, 34) * (1 - tap * 0.055),
          translate: `0 ${mix(70, 0, pop(f, 94, 34))}px`,
          opacity: ease(f, 94, 103),
        }}
      >
        <svg
          width="51"
          height="45"
          viewBox="0 0 60 50"
          fill="none"
          stroke={C.blue}
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ translate: `${-6 * tap}px 0` }}
        >
          <path d="M50 25H10 M27 8L10 25L27 42" />
        </svg>
        <span
          dir="rtl"
          style={{
            fontFamily: "Cairo",
            fontSize: 57,
            fontWeight: 900,
            color: C.blue,
          }}
        >
          جرّب <bdi dir="ltr">Centrix</bdi>
        </span>
      </div>
    </AbsoluteFill>
  );
};
