import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig, interpolateColors} from 'remotion';
import {C as OldC} from '../design'; // Loads the licensed local Cairo font once.
export const V={black:'#08080B',ink:'#111217',panel:'#24252A',gold:'#DBAD43',goldHi:'#FFE4A0',ivory:'#F6F0DF',gray:'#ABA596',muted:'#625E53'};
export const sat=(v:number)=>Math.min(1,Math.max(0,v));
export const lerp=(a:number,b:number,p:number)=>a+(b-a)*p;
export const s=(v:number)=>{v=sat(v);return 1-Math.pow(1-v,3);};
export const p=(t:number,a:number,d:number)=>s((t-a)/d);
export const linear=(t:number,a:number,d:number)=>sat((t-a)/d);
export const bell=(t:number,a:number,d:number)=>Math.sin(Math.PI*sat((t-a)/d));
export const now=()=>{const f=useCurrentFrame(),{fps}=useVideoConfig();return {f,fps,t:f/fps};};
export const rgba=(a:string,b:string,q:number)=>interpolateColors(q,[0,1],[a,b]);
export const Type:React.FC<{children:React.ReactNode;x?:number;y:number;w?:number;size?:number;color?:string;weight?:number;align?:'left'|'center'|'right';opacity?:number;style?:React.CSSProperties}>=({children,x=100,y,w=880,size=74,color=V.ivory,weight=850,align='center',opacity=1,style})=><div dir="rtl" style={{position:'absolute',left:x,top:y,width:w,fontFamily:'Cairo, sans-serif',fontWeight:weight,fontSize:size,lineHeight:1.2,color,textAlign:align,opacity,...style}}>{children}</div>;
export const Stage:React.FC<{t:number;children?:React.ReactNode;light?:number}>=({t,children,light=1})=><AbsoluteFill style={{background:V.black,color:OldC.light,fontFamily:'Cairo',overflow:'hidden'}}>
 <AbsoluteFill style={{background:'radial-gradient(ellipse at '+(44+8*Math.sin(t*.4))+'% 50%, #504025'+Math.round(35*light).toString(16).padStart(2,'0')+' 0%, #17171B55 34%, #08080B 73%)'}}/>
 <svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity:.4}}>


  <g transform={'translate(540 1020) rotate('+(-24+t*.3)+')'}>
   <ellipse rx="540" ry="760" fill="none" stroke="#D4AA4520" strokeWidth="1"/>
   <ellipse rx="620" ry="870" fill="none" stroke="#D4AA4510" strokeWidth="1"/>
   <path d="M-600 0H600M0 -800V800" stroke="#ABA5960D" strokeWidth="1"/>
  </g>
 </svg>
 {children}
</AbsoluteFill>;
export const DiagramNote:React.FC<{opacity?:number}>=({opacity=1})=><Type y={1500} size={28} weight={450} color={V.gray} opacity={opacity}>تصوّر بصري توضيحي</Type>;
export const Ribbon:React.FC<{d:string;q?:number;opacity?:number;weight?:number;glow?:boolean;flow?:number}>=({d,q=1,opacity=1,weight=3,glow=true,flow=0})=><svg width="1080" height="1920" style={{position:'absolute',inset:0,overflow:'visible',opacity}}>

 {glow&&<path d={d} fill="none" stroke="#DDB452" strokeWidth={weight+12} opacity=".12" pathLength={1} strokeDasharray="1" strokeDashoffset={1-q} style={{filter:'blur(8px)'}}/>}
 <path d={d} fill="none" stroke="#BFA26F" strokeWidth={weight} strokeLinecap="round" strokeOpacity=".14"/>
 <path d={d} fill="none" stroke={V.gold} strokeWidth={weight} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1-q}/>
 {q>.03&&<path d={d} fill="none" stroke={V.goldHi} strokeWidth={weight+2} strokeLinecap="round" pathLength={1} strokeDasharray=".014 .986" strokeDashoffset={-(q-.016+flow)%1}/>}
</svg>;
export const Trace:React.FC<{d:string;q?:number;weight?:number;color?:string;opacity?:number}>=({d,q=1,weight=4,color=V.gold,opacity=1})=><path d={d} fill="none" stroke={color} strokeWidth={weight} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1-q} opacity={opacity}/>;
export const Seal:React.FC<{r?:number;t:number;opacity?:number}>=({r=360,t,opacity=1})=><svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity}}>
 <g transform={'translate(540 1010) rotate('+t*9+')'}>
  <circle r={r} fill="none" stroke="#D2AE6133" strokeWidth="1"/>
  <circle r={r+24} fill="none" stroke="#C3AB6824" strokeWidth="1" strokeDasharray="4 13"/>
  <circle r={r-18} fill="none" stroke="#EDD08D" strokeWidth="2" opacity=".36" strokeDasharray="122 520 65 1400"/>
 </g>
</svg>;
export const QR2:React.FC<{size?:number;color?:string}>=({size=260,color=V.ivory})=>{
 const m=[];for(let y=0;y<21;y++)for(let x=0;x<21;x++){
  const find=[[0,0],[14,0],[0,14]].find(([a,b])=>x>=a&&x<a+7&&y>=b&&y<b+7);
  let on=false;if(find){const xx=x-find[0],yy=y-find[1];on=xx===0||yy===0||xx===6||yy===6||(xx>=2&&xx<=4&&yy>=2&&yy<=4);}
  else if(!((x<8&&y<8)||(x>12&&y<8)||(x<8&&y>12)))on=(x*13+y*19+x*y)%11<5;
  if(on)m.push(<rect key={x+'-'+y} x={x*12} y={y*12} width="9" height="9" rx=".8"/>);
 }return <svg width={size} height={size} viewBox="-12 -12 276 276" fill={color}>{m}</svg>;
};
export const Outline:React.FC<{w:number;h:number;fill?:string;stroke?:string;radius?:number}>=({w,h,fill=V.panel,stroke='#CFB67155',radius=38})=><svg width={w} height={h} style={{position:'absolute',inset:0,overflow:'visible'}}><path d={'M'+radius+' 0H'+(w-radius)+'L'+w+' '+radius+'V'+(h-radius)+'L'+(w-radius)+' '+h+'H'+radius+'L0 '+(h-radius)+'V'+radius+'Z'} fill={fill} stroke={stroke} strokeWidth="2"/></svg>;
