import React from 'react';
import {World} from './World';

import {V,Type,Stage,Ribbon,Trace,Seal,Outline,DiagramNote,p,lerp,rgba,sat,now} from './primitives';
const Headline:React.FC<{t:number;merge:number;lock:number}>=({t})=>{
 const stage=t<6.766?0:t<7.742?1:2;
 const feature=t<8.876,brand=t>=8.876&&t<10.005,unified=t>=10.005&&t<12.715;
 const title=feature?['حضور','تحصيل','متابعة'][stage]:brand?'ومع سنتريكس':unified?'في منظومة واحدة':'سيستم واحد';
 const onset=feature?[5.983,6.766,7.742][stage]:brand?8.876:unified?10.005:12.715;
 const arrival=p(t,onset,.18);
 return <>
 <Type y={268} size={feature?38:34} color={V.gray} weight={600}>{feature?'وراء كل حصة':'الحضور · الحسابات · التقارير'}</Type>
 <Type y={349} size={feature?143:brand?103:unified?88:110} weight={950} opacity={arrival} color={brand?V.gold:V.ivory} style={{translate:'0 '+lerp(30,0,arrival)+'px'}}>{!feature&&!brand&&!unified?<>{'سيستم '}<span style={{color:V.gold}}>واحد</span></>:title}</Type>
 </>;
};
export const ControlMachine:React.FC<{start?:number}>=({start=179})=>{
 const {f,fps}=now();const t=(f+start)/fps;
 const b=p(t,6.766,.28),c=p(t,7.742,.32),merge=p(t,8.876,1.05),lock=p(t,12.715,.26);
 const plateW=lerp(lerp(lerp(700,618,b),810,c),880,merge);
 const plateH=lerp(lerp(lerp(720,790,b),675,c),865,merge);
 const top=lerp(lerp(670,630,b),620,merge);
 const plateLeft=(1080-plateW)/2;
 const rotation=lerp(lerp(lerp(1.8,-4,b),2.3,c),0,merge);

 
 const paperFill=rgba(rgba(V.panel,V.ivory,b),V.panel,c);
 const fill=rgba(paperFill,'#14151B',merge);


 const boardMove=lerp(50,0,p(t,5.983,.35));
 return <Stage t={t}>
 {t<10.12&&<div style={{position:"absolute",inset:0,opacity:1-merge}}><World t={t} mode="features"/></div>}
 <div style={{position:"absolute",left:0,top:1290,width:1080,height:220,background:"linear-gradient(transparent,#08080BCC 62%,#08080B)",opacity:1-merge}}/>
 <Type y={1370} size={47} color={V.ivory} opacity={1-merge}>{t<6.766?"حضور يتسجل":t<7.742?"تحصيل يتوثّق":"متابعة تبقى واضحة"}</Type>
 <div style={{position:'absolute',inset:0,opacity:merge,scale:1+.014*Math.sin(Math.PI*sat((t-10)/2.7))-.014*lock,transformOrigin:'540px 1060px'}}>
 <Seal r={lerp(340,465,merge)} t={t} opacity={(1-merge)*.52}/>
 <Ribbon d="M-30 1310C270 1330 230 1140 540 1080C861 1018 1024 1199 1100 711" q={p(t,5.98,.7)} weight={4.8} opacity={(1-merge)*.7}/>
 <Ribbon d="M1130 520C1043 520 870 690 940 986C985 1180 808 1350 550 1350C235 1350 220 813 114 803" q={p(t,8.876,.80)} weight={5.6} opacity={merge*(1-lock)*.95}/>
 <div style={{position:'absolute',left:plateLeft,top:top+boardMove,width:plateW,height:plateH,rotate:rotation+'deg',boxShadow:'0 28px 100px #0007'}}>
  <Outline w={plateW} h={plateH} fill={fill} stroke={merge>.4?'#D3AD6677':'#E1C78066'} radius={lerp(35,52,merge)}/>
  <div data-v2='body' style={{position:'absolute',inset:0,opacity:p(t,9.30,.40)}}>
   <Type x={480} y={53} w={342} size={56} align="right" color={V.ivory}>الحضور</Type>
   <Type x={55} y={53} w={331} size={56} align="left" color={V.ivory}>الحسابات</Type>
   <svg width="880" height="865" style={{position:'absolute',inset:0}}>
    <path d="M40 292H839" fill="none" stroke="#A49A7925" strokeWidth="1"/>
    <Trace d="M80 335L215 335Q292 335 322 407L359 482M799 335L665 335Q588 335 559 407L521 482M440 686V743" q={p(t,10.20,.70)} weight={2.4+lock*.6} color="#B99445" opacity={.8}/>
    <g transform="translate(530 160)" opacity={p(t,9.55,.42)}>
    {[0,1,2,3].map(i=><g key={i} transform={'translate('+i*72+' 0)'}><rect x="0" y="0" width="48" height="48" rx="12" fill={i===3?'#A39B8A09':'#D9AD4419'} stroke={i===3?'#A39B8A44':'#D9AD4488'}/>{i<3?<Trace d="M12 25L22 35L39 15" q={p(t,9.55+i*.08,.30)} weight={3}/>:<path d="M13 24H35" stroke={V.gray} strokeWidth="2"/>}</g>)}
    </g>
    <g transform="translate(58 140)" opacity={p(t,9.9,.4)}>
     <path d="M16 0H78V102L63 94L47 102L31 94L16 102Z" stroke={V.gold} strokeWidth="3" fill="#E3C05B09"/>
     <path d="M30 25H63M30 42H63M30 59H51" stroke={V.gold} strokeWidth="2.5"/>
     <path d="M111 11H292M111 38H251M111 65H271" stroke="#B5AA8666" strokeWidth="5"/>
    </g>
    <g transform="translate(440 440)" opacity={p(t,10.20,.6)}>
     <path d="M0 -125L112 -63V63L0 125L-112 63V-63Z" stroke={V.gold} strokeWidth={lerp(2,3.5,lock)} fill="#28251C"/>
     <path d="M0 -147L131 -74V74L0 147L-131 74V-74Z" stroke="#D0B47533" strokeWidth="1" fill="none"/>
     <circle cy="-27" r="27" fill="none" stroke={V.ivory} strokeWidth="4"/>
     <path d="M-47 66C-47 13 47 13 47 66" stroke={V.ivory} strokeWidth="4" fill="none"/>
    </g>
    <g opacity={p(t,10.58,.7)}>
     <path d="M64 810H816M64 756H816" stroke="#ADA68F22" strokeWidth="1" strokeDasharray="4 12"/>
     <Trace d="M65 801C115 801 118 771 171 777S242 808 306 773S364 806 424 753S487 781 550 748S603 794 674 750S728 774 809 731" q={p(t,10.58,1.20)} weight={4}/>
    </g>
    <path d="M80 335L215 335Q292 335 322 407L359 482M799 335L665 335Q588 335 559 407L521 482M440 686V743" fill="none" stroke={V.goldHi} strokeWidth="5" pathLength={1} strokeDasharray=".017 .983" strokeDashoffset={-(t*.45)%1} opacity={lock*.8}/>
   </svg>
   <Type x={62} y={251} w={316} size={29} color={V.gray} align="left">مدفوعات · تحصيل</Type>
   <Type x={490} y={222} w={316} size={29} color={V.gray} align="right">حضور · غياب</Type>
   <Type x={302} y={574} w={278} size={39} weight={700}>ملف الطالب</Type>
   <Type x={304} y={627} w={273} size={25} color={V.gray} weight={600}>QR · الاسم · الكود</Type>
   <Type x={62} y={654} w={752} size={46} align="right">التقارير</Type>
  </div>
 </div>
 </div>
 <Headline t={t} merge={merge} lock={lock}/>
 <DiagramNote/>
 </Stage>;
};
