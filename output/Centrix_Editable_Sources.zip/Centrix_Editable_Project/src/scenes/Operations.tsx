import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BG,C,Text,Label,Thread,Plate,Icon,Concept,prog,mix,useScene,QR,ramp} from '../design';

// One plate changes its silhouette and data treatment on three exact narration cues.
export const Operations:React.FC=()=>{
 const {f,fps}=useScene(); const a=prog(f,0,.24*fps);const b=prog(f,.783*fps,.28*fps);const c=prog(f,1.762*fps,.28*fps);
 const phase=b+c;const w=mix(650,620,b); const h=mix(mix(530,625,b),530,c);
 const word=phase<.5?'حضور':phase<1.5?'تحصيل':'متابعة';
 const att=1-ramp(f,.733*fps,.783*fps),pay=ramp(f,.783*fps,.833*fps)*(1-ramp(f,1.712*fps,1.762*fps)),rep=ramp(f,1.762*fps,1.812*fps);
 const line=prog(f,0,.63*fps);
 return <AbsoluteFill style={{fontFamily:'Cairo',color:C.light}}><BG frame={f+180}/>
  <Label index="CENTRIX">تفاصيل يوم السنتر</Label>
  <Text y={338} size={132} weight={900} style={{translate:'0 '+mix(26,0,a)+'px',opacity:a}}>{word}</Text>
  <Thread d="M1040 840C890 840 906 616 780 616L690 616" p={line} opacity={.6}/>
  <Thread d="M390 1230L252 1230C162 1230 162 1370 100 1370" p={line} opacity={.45}/>
  <Plate x={(1080-w)/2} y={625} w={w} h={h} active style={{scale:mix(.94,1,a),rotate:mix(-3.5,0,a)+'deg'}}>
   <div style={{position:'absolute',inset:0,opacity:att}}>
    <div style={{position:'absolute',left:56,top:45}}><Icon type="student" size={76}/></div>
    <Text x={140} y={53} w={445} size={48} align="right" weight={700}>بطاقة الطالب</Text>
    <div style={{position:'absolute',left:61,top:188,width:224,height:224,padding:12,border:'1px solid #DDB34B44',borderRadius:16}}><QR size={200}/></div>
    <div style={{position:'absolute',right:71,top:212}}><Icon type="attendance" size={150} progress={prog(f,4,13)}/></div>
    <Text x={284} y={383} w={300} size={44} color={C.gold}>تم الحضور</Text>
   </div>
   <div style={{position:'absolute',inset:0,opacity:pay,translate:'0 '+mix(45,0,b)+'px'}}>
    <div style={{position:'absolute',left:230,top:35}}><Icon type="payment" size={155}/></div>
    <Text x={50} w={520} y={207} size={56}>إيصال تحصيل</Text>
    <div style={{position:'absolute',left:65,right:65,top:314,borderTop:'1px dashed #DDB34B55'}}/>
    <Text x={62} w={490} y={338} size={44} color={C.gray}>دفعة مرتبطة بالطالب</Text>
    <Text x={62} w={490} y={439} size={47} color={C.gold}>مسجلة في الحسابات</Text>
    <svg width="620" height="30" style={{position:'absolute',bottom:0}}><path d="M0 30L15 15L30 30L45 15L60 30L75 15L90 30L105 15L120 30L135 15L150 30L165 15L180 30L195 15L210 30L225 15L240 30L255 15L270 30L285 15L300 30L315 15L330 30L345 15L360 30L375 15L390 30L405 15L420 30L435 15L450 30L465 15L480 30L495 15L510 30L525 15L540 30L555 15L570 30L585 15L600 30L615 15L630 30" fill={C.bg}/></svg>
   </div>
   <div style={{position:'absolute',inset:0,opacity:rep,translate:'0 '+mix(40,0,c)+'px'}}>
    <div style={{position:'absolute',left:66,top:45}}><Icon type="report" size={98}/></div>
    <Text x={196} w={359} y={56} size={48} align="right">تقرير متابعة</Text>
    <div style={{position:'absolute',left:66,top:226,display:'flex',gap:30,alignItems:'end',height:170}}>
    {[90,133,105,162,144,176].map((v,i)=><div key={i} style={{width:58,height:v*prog(f,1.762*fps+i*1.5,15),borderRadius:'8px 8px 0 0',background:i===5?'linear-gradient(#F3D389,#BC902F)':'linear-gradient(#847553,#393229)'}}/>)}</div>
    <Text x={50} y={431} w={520} size={44} color={C.gold}>رؤية أوضح لكل طالب</Text>
   </div>
   <div style={{position:'absolute',left:0,right:0,top:115+line*360,height:1.4,background:'linear-gradient(90deg,transparent,#F4D78B,transparent)',opacity:att*.4}}/>
  </Plate>
  <div style={{position:'absolute',left:180,top:1370,width:720,display:'flex',justifyContent:'space-between',direction:'rtl'}}>
   {['حضور','تحصيل','متابعة'].map((x,i)=><div key={x} style={{fontSize:44,fontWeight:700,color:i===Math.round(phase)?C.light:'#635F57',display:'flex',alignItems:'center',gap:16}}><span style={{width:7,height:7,background:i===Math.round(phase)?C.gold:'#635F57',borderRadius:9}}/>{x}</div>)}
  </div><Concept/>
 </AbsoluteFill>;
};
