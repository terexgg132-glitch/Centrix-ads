import React from "react";
import { useCurrentFrame } from "remotion";
import { SceneFrame, C, Micro, p, Beam, Logo } from "../design";
import { Mechanism } from "../Mechanism";
export const Agent = () => {
  const f = useCurrentFrame();
  return (
    <SceneFrame grid>
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(ellipse at center,#d5a535${Math.round(
            16 * (1 - p(f, 0, 30)),
          )
            .toString(16)
            .padStart(2, "0")},transparent 70%)`,
        }}
      />
      <Mechanism
        style={{
          left: 1100,
          top: 85,
          scale: 1.2,
          translate: `${(1 - p(f, 5, 55)) * 450}px 0`,
        }}
        opacity={p(f, 5, 40) * 0.9}
      />
      <Beam f={f} duration={38} />
      {[0, 1, 2, 3, 4].map((i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            width: 540 + i * 105,
            height: 540 + i * 105,
            left: 960 - (540 + i * 105) / 2,
            top: 540 - (540 + i * 105) / 2,
            border: `1px solid rgba(232,186,85,${0.22 - i * 0.035})`,
            rotate: `${45 + i * 0.1 * f}deg`,
            scale: 0.25 + p(f, 0, 54) * 0.75,
            opacity: 0.25 * p(f, 0, 15) * (1 - p(f, 105, 150)),
            borderRadius: i === 0 ? 16 : 0,
          }}
        />
      ))}
      <div
        style={{
          position: "absolute",
          left: 100,
          width: 1160,
          top: 220,
          textAlign: "center",
          opacity: p(f, 10, 35),
        }}
      >
        <Micro>CENTRIX AI AGENT</Micro>
        <div
          dir="rtl"
          style={{
            fontSize: 192,
            fontWeight: 600,
            lineHeight: 1.5,
            color: C.pale,
            marginTop: 35,
            scale: 0.9 + p(f, 10, 60) * 0.1,
          }}
        >
          بيعمله.
        </div>
        <div
          dir="rtl"
          style={{
            fontSize: 43,
            marginTop: 5,
            color: "#a8a49b",
            opacity: p(f, 48, 72),
          }}
        >
          ذكاء يفهم طلبك. وينفّذه جوّه النظام.
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 570,
          top: 790,
          opacity: p(f, 70, 100),
        }}
      >
        <Micro style={{ fontSize: 18, letterSpacing: 8 }}>WORDS → WORK</Micro>
      </div>
    </SceneFrame>
  );
};
