# Original audio provenance

Music and SFX were composed and synthesized specifically for this Centrix film by the supplied `scripts/compose_audio.py` source. The source uses sine/FM oscillators, filtered deterministically seeded noise, amplitude envelopes, and authored event timing. No stock tracks, recognizable branded melodies, sample packs, or downloaded sound libraries were used.

Three-note signature: D5 (587.33 Hz), A4 (440 Hz), F5 (698.46 Hz), beginning at 21.70, 22.12, and 22.83 seconds. The scanner timbre shares the same FM family. The paper/click/scanner electronic motif runs at 108 BPM with intentional breaks and a reduced AI section.

The supplied original logo and voice are user-provided assets, retained as supplied. Cairo is distributed under the bundled SIL Open Font License. This document records production provenance and does not assert a third-party license for the user-provided assets.
