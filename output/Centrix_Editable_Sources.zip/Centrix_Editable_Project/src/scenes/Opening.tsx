import React from 'react';
import {AbsoluteFill} from 'remotion';
import {CameraMotionBlur} from '@remotion/motion-blur';
import {BG,C,Text,Label,Thread,Plate,Icon,QR,Concept,prog,mix,useScene} from '../design';

const ScannedCard:React.FC=()=>{
 const {f,fps}=useScene();
 const enter=prog(f,0,.35*fps),push=prog(f,0,2.4*fps);
 const scan=prog(f,.306*fps,1.15*fps);
 return <div style={{position:'absolute',inset:0,scale:mix(.90,1.06,push),transformOrigin:'540px 1010px'}}>
 <Plate x={220} y={737} w={640} h={500} active style={{opacity:enter,translate:'0 '+mix(70,0,enter)+'px'}}>
 <div style={{position:'absolute',left:42,top:38}}><Icon type="student" size={75}/></div>
 <Text x={172} w={420} y={43} size={47} align="right">كارنيه الطالب</Text>
 <div style={{position:'absolute',left:53,top:171,clipPath:'inset(0 0 '+((1-scan)*100)+'% 0)'}}><QR size={238}/></div>
 <div style={{position:'absolute',left:333,top:215,width:253,height:12,background:'#7E766055',borderRadius:9}}/>
 <div style={{position:'absolute',left:371,top:257,width:215,height:9,background:'#7E766033',borderRadius:9}}/>
 <div style={{position:'absolute',left:341,top:331,opacity:prog(f,1.55*fps,10)}}><Icon type="attendance" size={78}/></div>
 <Text x={415} y={344} w={175} size={35} color={C.gold} align="right" style={{opacity:prog(f,1.55*fps,10)}}>حضور</Text>
 <div style={{position:'absolute',left:0,right:0,top:140+scan*310,height:2,background:'linear-gradient(90deg,transparent,#FFE8A3,transparent)',boxShadow:'0 0 20px #DDB34B77',opacity:f<55?1:.18}}/>
 </Plate></div>;
};
export const Opening:React.FC=()=>{const {f,fps}=useScene();const onset=prog(f,.306*fps,12);return <AbsoluteFill>
<BG frame={f}/>
<Label index="CENTRIX">قبل أول حصة</Label>
<Text y={324} size={51} color={C.gray} style={{opacity:onset}}>فاكر إن...</Text>
<Text y={415} size={105} weight={900} style={{opacity:onset,translate:'0 '+mix(26,0,onset)+'px'}}>شغل السنتر</Text>
<Text y={558} size={69} style={{opacity:prog(f,.95*fps,12)}}>بيبدأ مع الحصة؟</Text>
<Thread d="M1080 918L961 918Q904 918 904 837L904 786Q904 708 820 708L430 708Q174 708 174 986L174 1320Q174 1392 100 1392" p={prog(f,0,2.2*fps)} width={2.3} opacity={.68}/>
<CameraMotionBlur samples={3} shutterAngle={85}><ScannedCard/></CameraMotionBlur>
<Text y={1375} size={39} color={C.gray} weight={650} style={{opacity:prog(f,1.85*fps,12)}}>QR · اسم الطالب · الكود</Text>
<Concept/>
</AbsoluteFill>};
