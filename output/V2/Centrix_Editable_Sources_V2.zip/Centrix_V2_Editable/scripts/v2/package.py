"""Package a lean, standalone editable V2 project, with exact supplied assets."""
from pathlib import Path
import zipfile,json
R=Path(__file__).resolve().parents[2];O=R/'output/V2';base='Centrix_V2_Editable/'
target=O/'Centrix_Editable_Sources_V2.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 package=json.loads((R/'package.json').read_text())
 package['name']='centrix-cinematic-v2'
 package['description']='Revised CENTRIX hybrid CGI/vector commercial'
 package['scripts']={
  'dev':'remotion studio','check':'tsc --noEmit',
  'render:style':'node scripts/v2/render.mjs style',
  'render:final':'node scripts/v2/render.mjs final',
  'render:frames':'node scripts/v2/render.mjs frames',
  'audio:build':'bash scripts/v2/build_audio.sh',
  'validate':'python3 scripts/v2/validate.py'}
 # Keep the lockfile root identity consistent; dependencies remain exact.
 lock=json.loads((R/'package-lock.json').read_text());lock['name']=package['name']
 lock['packages']['']['name']=package['name']
 z.writestr(base+'package.json',json.dumps(package,indent=2))
 z.writestr(base+'package-lock.json',json.dumps(lock,indent=2))
 z.writestr(base+'src/index.ts',"import {registerRoot} from 'remotion';\nimport {RootV2} from './v2/RootV2';\nregisterRoot(RootV2);\n")
 for p in ['src/design.tsx','tsconfig.json','remotion.config.ts','requirements-audio.txt','.gitignore']:
  z.write(R/p,base+p)
 for folder in ['src/v2','scripts/v2','assets','public/fonts']:
  for p in (R/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.as_posix():
    z.write(p,base+p.relative_to(R).as_posix())
 for p in [R/'public/assets/centrix_logo_original.svg',R/'public/assets/v2/Centrix_Final_Mix.wav',R/'public/assets/grain.png']:
  z.write(p,base+p.relative_to(R).as_posix())
 for p in (O/'audio').glob('*'):
  if p.is_file():z.write(p,base+'output/V2/audio/'+p.name)
 for p in [O/'Centrix_Assets_Manifest_V2.json',O/'Centrix_Audio_Cue_Sheet_V2.csv',O/'review/validation.json',O/'review/Production_Report_V2.md']:
  if p.exists():z.write(p,base+'documentation/'+p.name)
 z.writestr(base+'README.md',"""# CENTRIX V2 — editable cinematic film

27 seconds, 1080×1920, 30fps. Hybrid Three.js CGI and SVG/HTML typography.
The client granted full creative freedom after reviewing V1. V2 introduces
physical paper objects, extruded gold symbols, a spatial data conductor,
larger word-synchronized typography, and a newly composed soundtrack.

Run npm ci, then npm run dev. Open Centrix-V2-Final in the Studio.
Six scene compositions and the 8-second central style test are registered.
World.tsx defines the CGI objects, studio environment, textures and camera;
Scenes.tsx contains the hook, record layers, AI, connected system and brand;
ControlMachine.tsx owns the continuous feature-to-system transformation.
primitives.tsx controls palette, Arabic typography and vector strokes.
RootV2.tsx contains editable scene timing nodes.

On Linux use /usr/bin/chromium. Else set CENTRIX_CHROME to Chrome/Chromium.
Install Python dependencies with pip install -r requirements-audio.txt.
FFmpeg and ffprobe are required. Run npm run audio:build to rebuild audio,
npm run render:style or npm run render:final to export, and npm run validate
to inspect the actual encoded master.

The browser renders deterministic frames without collecting audio; FFmpeg
muxes the original-voice mix and enforces exact duration, H.264 yuv420p,
limited-range BT.709 and AAC 48kHz stereo. Studio audio remains enabled.

The original 23.712s voice MP3 and full SVG brand asset are preserved exactly.
Voice is never cut, retimed or regenerated. The complete raster-backed SVG
is displayed intact. UI and graphs are clearly illustrative; no real student
identities, financial metrics or automated message sending are depicted.

All music, effects, studio reflections and paper textures are original
procedural work. No external music, stock sounds, image assets, 3D models or
copyrighted samples are used. Cairo is legally redistributed unchanged with
its SIL Open Font License, in public/fonts/OFL.txt.

Physical phone-speaker listening is unavailable in this cloud environment.
The validation generates a mono phone-band proxy for technical review;
actual handset listening and subjective creative approval remain manual.
""")
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 print('Verified',len(z.namelist()),'files;',target.stat().st_size,'bytes')
