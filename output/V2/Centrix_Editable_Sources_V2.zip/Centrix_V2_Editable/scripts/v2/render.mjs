import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill,renderMedia} from '@remotion/renderer';
import {mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
const mode=process.argv[2]||'probe';
const serveUrl=await bundle({entryPoint:resolve('src/index.ts'),outDir:resolve('work/v2/bundle-'+mode),enableCaching:true});
const browser=await openBrowser('chrome',{browserExecutable:process.env.CENTRIX_CHROME||'/usr/bin/chromium',chromiumOptions:{gl:process.env.CENTRIX_GL||'swangle'}});
try{
 const id=mode==='style'?'Centrix-V2-Style-Test':mode==='probe'?'Centrix-V2-Control-Machine':'Centrix-V2-Final';
 const composition=await selectComposition({serveUrl,id,inputProps:{audioEnabled:false},puppeteerInstance:browser});
 if(mode==='probe'||mode==='frames'){
  mkdirSync('work/v2/frames',{recursive:true});
  const frames=process.argv[3]?[Number(process.argv[3])]:mode==='probe'?[12,36,75,111,226]:[15,105,204,276,375,486,594,684,786];
  for(const frame of frames){
   await renderStill({serveUrl,composition,frame,output:'work/v2/frames/'+id+'-'+frame+'.png',imageFormat:'png',puppeteerInstance:browser,logLevel:'error'});
   console.log('Frame '+frame+' done');
  }
 }else{
  const file=mode==='style'?'Centrix_Cinematic_Style_Test_V2.mp4':'Centrix_Cinematic_Final_27s_V2.mp4';
  const raw=resolve('work/v2/'+file);
  let last=-1;
  await renderMedia({serveUrl,composition,outputLocation:raw,inputProps:{audioEnabled:false},timeoutInMilliseconds:120000,codec:'h264',crf:16,pixelFormat:'yuv420p',audioCodec:'aac',audioBitrate:'320k',audioSampleRate:48000,concurrency:2,puppeteerInstance:browser,logLevel:'error',onProgress:({progress})=>{const n=Math.floor(progress*10)*10;if(n!==last){last=n;console.log(mode+' '+n+'%');}}});
  const audio=mode==='style'?['-ss','6','-i','output/V2/audio/Centrix_Final_Mix.wav']:['-i','output/V2/audio/Centrix_Final_Mix.wav'];
  const output='output/V2/'+file;
  const r=spawnSync('ffmpeg',['-y','-loglevel','error','-i',raw,...audio,'-map','0:v:0','-map','1:a:0',
   '-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p',
   '-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
   '-c:a','aac','-b:a','320k','-ar','48000','-ac','2','-t',mode==='style'?'8':'27','-movflags','+faststart',output],{stdio:'inherit'});
  if(r.status!==0)throw new Error('Final encode failed');
  console.log('DONE '+output);
 }
}finally{await browser.close({silent:true});}
