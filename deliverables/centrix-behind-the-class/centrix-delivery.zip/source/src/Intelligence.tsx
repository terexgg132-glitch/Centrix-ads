import React from 'react';
import {C,T,p,lin,lerp,visible,Line,Dot} from './shared';
export const Intelligence=({t}:{t:number})=>{
 const enter=p(t,14.68,15.40),type=lin(t,15.66,16.80),result=p(t,17.02,17.50),exit=p(t,18.10,19.55);
 const query='مين غاب النهارده؟';const text=query.slice(0,Math.floor(type*query.length));
 const opacity=enter*(1-exit);
 return <g opacity={opacity}>
  <T x={913} y={410} size={88} anchor="start" fill={C.ivory} weight={750}>محتاج تعرف حاجة؟</T>
  <T x={913} y={513} size={47} anchor="start" fill="#B4AE9F">مساعد Centrix الذكي</T>
  <g transform={`translate(0 ${lerp(200,0,enter)})`}>
   <path d="M160 699H920" stroke={C.gold} strokeWidth="2"/>
   <path d="M160 699Q132 699 132 728V952Q132 981 161 981H919Q948 981 948 952V728Q948 699 919 699" fill={C.panel} stroke={C.line} strokeWidth="2"/>
   <T x={897} y={772} size={29} anchor="start" fill="#9D978B">سؤال باللغة الطبيعية</T>
   <T x={894} y={890} size={66} anchor="start" fill={C.ivory} weight={600}>{text}</T>
   <path d="M894 910H890" stroke={C.gold} strokeWidth="2" opacity={t<16.85?1:0}/>
   <g transform="translate(192 861)">
    <circle r="28" fill="none" stroke="#4D4739" strokeWidth={2}/>
    <path d="M-14 0H14M4-10L14 0L4 10" stroke={C.gold} fill="none" strokeWidth={2}/>
   </g>
  </g>
  <g opacity={result} transform={`translate(0 ${lerp(35,0,result)})`}>
   <path d="M186 1009V1072Q186 1087 204 1087H840" stroke={C.gold} strokeWidth="2" fill="none"/>
   <rect x="132" y="1130" width="816" height="313" rx="16" fill={C.panel} stroke={C.line} strokeWidth="2"/>
   <T x={893} y={1210} size={48} anchor="start" fill={C.ivory} weight={650}>نتائج الحضور</T>
   <T x={893} y={1280} size={32} anchor="start" fill="#AAA396">المصدر: سجل الحصة</T>
   <path d="M183 1320H895" stroke={C.line} strokeWidth="2"/>
   <T x={891} y={1386} size={34} anchor="start" fill={C.ivory}>عرض سجل الغياب</T>
   <g transform="translate(196 1370)"><path d="M-10 0H10 M0-10V10" stroke={C.gold} strokeWidth="2"/></g>
  </g>
  <T x={912} y={1518} size={29} anchor="start" fill="#9D978B">نموذج توضيحي • بيانات تجريبية</T>
  <g transform="translate(178 541)" opacity={p(t,16.236,16.70)}>
   <path d={`M0-22Q${14+8*Math.sin(t*2)} 0 0 22Q${-14-8*Math.sin(t*2)} 0 0-22Z`} fill="none" stroke={C.gold} strokeWidth={2}/>
   <circle r={4} fill={C.ivory}/>
  </g>
 </g>;
};
