import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { SceneFrame, C, Micro, p, Icon } from "../design";
export const Pressure = () => {
  const f = useCurrentFrame();
  const out = p(f, 145, 180);
  const cards = [
    {
      x: 110,
      y: 165,
      r: -11,
      n: "attendance",
      t: "الحضور",
      sub: "مجموعة الساعة ٤",
    },
    {
      x: 1270,
      y: 140,
      r: 9,
      n: "money",
      t: "التحصيل",
      sub: "مراجعة المدفوعات",
    },
    { x: -110, y: 660, r: 8, n: "student", t: "الطلاب", sub: "ملفات ومتابعة" },
    {
      x: 1390,
      y: 670,
      r: -10,
      n: "report",
      t: "التقارير",
      sub: "تفاصيل كل يوم",
    },
  ];
  return (
    <SceneFrame grid>
      <div
        style={{
          position: "absolute",
          inset: 0,
          scale: 1 + out * 0.32,
          opacity: 1 - out,
        }}
      >
        {cards.map((c, i) => (
          <div
            key={c.t}
            dir="rtl"
            style={{
              position: "absolute",
              left: c.x,
              top: c.y + Math.sin(f / 37 + i) * 12,
              width: 520,
              height: 210,
              background: "linear-gradient(130deg,#202122,#090b0e)",
              border: "1px solid #8b704d44",
              borderRadius: 18,
              padding: 32,
              transform: `perspective(1600px) rotateY(${i % 2 ? -18 : 18}deg) rotateZ(${c.r}deg) translateY(${(1 - p(f, i * 9, 28 + i * 9)) * 180}px)`,
              boxShadow: "0 35px 75px #0009",
              opacity: 0.45 + 0.1 * p(f, 10, 40),
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
              <Icon name={c.n} />
              <span style={{ fontSize: 42 }}>{c.t}</span>
            </div>
            <div style={{ fontSize: 26, color: "#888", marginTop: 20 }}>
              {c.sub}
            </div>
          </div>
        ))}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "radial-gradient(ellipse at 50% 49%,#050607 9%,#050607d9 24%,transparent 64%)",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 275,
            left: 180,
            right: 180,
            textAlign: "center",
          }}
        >
          <Micro style={{ opacity: p(f, 5, 25), marginBottom: 28 }}>
            EVERY DAY. EVERY DETAIL.
          </Micro>
          <div
            dir="rtl"
            style={{
              fontSize: 124,
              fontWeight: 500,
              lineHeight: 1.35,
              opacity: p(f, 10, 34),
              translate: `0 ${(1 - p(f, 10, 40)) * 45}px`,
            }}
          >
            كل يوم.
          </div>
          <div
            dir="rtl"
            style={{
              fontSize: 142,
              fontWeight: 600,
              lineHeight: 1.3,
              color: C.gold,
              opacity: p(f, 37, 62),
              translate: `0 ${(1 - p(f, 37, 62)) * 60}px`,
            }}
          >
            مئات التفاصيل.
          </div>
          <div
            dir="rtl"
            style={{
              fontSize: 37,
              color: C.muted,
              marginTop: 30,
              opacity: p(f, 65, 87),
            }}
          >
            وكل خطوة… بتاخد من وقتك.
          </div>
        </div>
        <div
          style={{
            position: "absolute",
            left: 860,
            top: 850,
            width: 200,
            height: 2,
            background: "#8d70433b",
          }}
        >
          <div
            style={{ height: 2, width: 200 * p(f, 0, 165), background: C.gold }}
          />
        </div>
      </div>
    </SceneFrame>
  );
};
