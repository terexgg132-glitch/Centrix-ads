import React from 'react';
import {Img,staticFile} from 'remotion';
import {C,T,p,lerp} from './shared';
export const Outro=({t}:{t:number})=> <g opacity={p(t,21.77,22.16)}>
 <foreignObject x={115} y={390+lerp(22,0,p(t,21.77,22.16))} width={850} height={850}>
  <div style={{width:850,height:850}}><Img src={staticFile('assets/centrix_logo_original.svg')} style={{width:850,height:850}}/></div>
 </foreignObject>
 <T x={540} y={1361+lerp(18,0,p(t,22.513,23.15))} size={83} weight={650} fill={C.ivory} opacity={p(t,22.513,23.15)}>سستم السنتر</T>
 <text x="540" y="1473" textAnchor="middle" fontFamily="Cairo" fontSize="34" fontWeight="400" fill="#ADA79A" opacity={p(t,23.05,23.55)}>centrix.company</text>
</g>;
