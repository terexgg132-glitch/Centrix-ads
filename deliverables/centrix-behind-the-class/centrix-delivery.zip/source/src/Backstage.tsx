import React from 'react';
import {C,T,p,visible,lerp} from './shared';
const Sheet=({x,y,r,fold,label,sub}:{x:number;y:number;r:number;fold:number;label:string;sub:string})=> <g transform={`translate(${x} ${y}) rotate(${r})`}>
 <path d={`M0 0H470L${470+fold*80} 75V510H0Z`} fill="#E8E1D4" stroke="#C8BEAD" strokeWidth="2"/>
 <path d={`M470 0V75H${470+fold*80}`} fill="#D7CEBE" stroke="#C8BEAD" strokeWidth="2"/>
 <T x={430} y={110} size={52} anchor="start" weight={700}>{label}</T>
 <T x={430} y={173} size={29} anchor="start" fill="#837A6C">{sub}</T>
 {[235,315,395,475].map((cy,i)=><g key={cy} opacity={.8}><path d={`M35 ${cy}H465`} stroke="#BBB09D" strokeWidth="2"/><rect x={425} y={cy-44} width={24} height={24} fill="none" stroke="#A89C86" strokeWidth="2"/><path d={`M60 ${cy-30}H${240+i*17}`} stroke="#C8BDAA" strokeWidth="7"/></g>)}
</g>;
export const Backstage=({t}:{t:number})=>{
 const enter=p(t,2.2,3.5),stage=p(t,4.6,5.45),out=p(t,8.99,9.62);
 const zoom=lerp(.85,1.09,p(t,3.1,5.65));
 return <g opacity={enter*(1-out)} transform={`translate(540 960) scale(${zoom}) translate(-540 -960)`}>
  <g opacity={p(t,3.15,3.48)*(1-p(t,5.25,5.87))}><T x={913} y={404} size={114} anchor="start" weight={800}>ورا كل حصة</T>
  <T x={906} y={540} size={100} anchor="start" weight={400} opacity={stage}>تفاصيل كتير</T></g>
  <g opacity={lerp(.65,.18,p(t,5.5,6.15))}>
   <g transform={`translate(${-120*enter} ${-75*enter})`}><Sheet x={72} y={762} r={-13*enter} fold={enter} label="الحضور" sub="كشف الحصة"/></g>
   <g transform={`translate(${90*stage} ${100*stage})`}><Sheet x={431} y={856} r={10*stage} fold={stage} label="التحصيل" sub="سجل المدفوعات"/></g>
   <g transform={`translate(${-90*stage} ${190*stage})`}><Sheet x={236} y={982} r={-4} fold={stage} label="المتابعة" sub="مسار الطالب"/></g>
  </g>
 </g>;
};
