import os,json,subprocess,hashlib,argparse,re
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',default=os.environ.get('CENTRIX_OUTPUT',ROOT/'renders'));a=p.parse_args();OUT=Path(a.output).resolve()
def run(args):return subprocess.run(args,capture_output=True,check=True)
def probe(path):return json.loads(run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(path)]).stdout)
def pcm(path):return np.frombuffer(run(['ffmpeg','-v','error','-i',str(path),'-ar','48000','-ac','2','-f','f32le','-']).stdout,dtype='<f4').reshape(-1,2)
def image_at(t):
 b=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(OUT/'centrix-behind-the-class-final.mp4'),'-frames:v','1','-f','image2pipe','-c:v','png','-']).stdout
 import io
 return Image.open(io.BytesIO(b)).convert('RGB')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'auditory_review':'Unavailable: this environment does not support audio audition. No listening review claimed.','assets':{}}
for name in ['centrix-behind-the-class-final.mp4','centrix-behind-the-class-preview.mp4','centrix-8s-motion-proof.mp4']:
 pr=probe(OUT/name);dec=run(['ffmpeg','-v','error','-i',str(OUT/name),'-f','null','-']);video=next(s for s in pr['streams'] if s['codec_type']=='video');audio=next(s for s in pr['streams'] if s['codec_type']=='audio')
 report[name]={'duration':float(pr['format']['duration']),'video_duration':float(video['duration']),'width':video['width'],'height':video['height'],'frames':int(video['nb_frames']),'fps':video['r_frame_rate'],'codec':video['codec_name'],'pixel_format':video['pix_fmt'],'color_range':video.get('color_range'),'audio_codec':audio['codec_name'],'audio_rate':int(audio['sample_rate']),'audio_channels':audio['channels'],'end_to_end_decode':'pass','bytes':(OUT/name).stat().st_size}
 assert video['codec_name']=='h264' and video['pix_fmt']=='yuv420p' and audio['codec_name']=='aac' and audio['sample_rate']=='48000' and audio['channels']==2
 assert int(video['nb_frames'])==(240 if 'proof' in name else 810)
# The voice stem is unedited except stereo resampling/PCM quantization.
original=pcm(ROOT/'public/assets/centrix_voiceover_original.mp3');voice=pcm(OUT/'centrix-voice.wav');assert original.shape==voice.shape
report['voice']={'original_seconds':len(original)/48000,'stem_seconds':len(voice)/48000,'samples_per_channel':len(original),'resampled_pcm_max_error':float(np.max(np.abs(original-voice))),'resampled_pcm_correlation':float(np.corrcoef(original[:,0],voice[:,0])[0,1]),'no_time_stretch_or_trim':len(original)==1138176}
assert report['voice']['resampled_pcm_max_error']<2e-7
# Recover the voice from the untouched stem sum before the common master gain.
gain=json.loads((OUT/'audio-report.json').read_text())['static_master_gain'];mix=pcm(OUT/'centrix-full-mix.wav');music=pcm(OUT/'centrix-original-music.wav');sfx=pcm(OUT/'centrix-sfx.wav');recovered=mix/gain-music-sfx
report['voice']['recovered_from_stem_sum_max_error']=float(np.max(np.abs(recovered[:len(original)]-original)))
assert report['voice']['recovered_from_stem_sum_max_error']<2e-7
# Verify the encoded audio tracks the lossless mix with no time shift.
encoded=pcm(OUT/'centrix-behind-the-class-final.mp4');n=min(len(encoded),len(mix));report['encoded_audio_correlation']=float(np.corrcoef(encoded[:n,0],mix[:n,0])[0,1]);assert report['encoded_audio_correlation']>.99
rr=run(['ffmpeg','-hide_banner','-i',str(OUT/'centrix-behind-the-class-final.mp4'),'-af','loudnorm=I=-15:TP=-1:LRA=9:print_format=json','-f','null','-']).stderr.decode();m=re.findall(r'\{\s*"input_i"[\s\S]*?\}',rr);loud=json.loads(m[-1]);report['master_loudness']={k:loud[k] for k in ['input_i','input_tp','input_lra']};assert -16<=float(loud['input_i'])<=-14;assert float(loud['input_tp'])<=-1
(OUT/'loudness-report.txt').write_text(rr[rr.rfind('{'):])
proof_audio=pcm(OUT/'centrix-8s-motion-proof.mp4');expected_proof=mix[264000:648000];n=min(len(proof_audio),len(expected_proof));report['proof_audio_correlation_to_5_5s_mix']=float(np.corrcoef(proof_audio[:n,0],expected_proof[:n,0])[0,1]);assert report['proof_audio_correlation_to_5_5s_mix']>.99
# Original assets: exact hashes, not approximations.
for name in ['centrix_voiceover_original.mp3','centrix_logo_original.svg']:report['assets'][name]={'sha256':sha(ROOT/'public/assets'/name),'original_asset_retained':True,'usage':'displayed directly from supplied SVG' if name.endswith('.svg') else 'complete untrimmed resample in the mix'}
# Final hold: whole-frame stability after the voice has finished.
im1=image_at(23.60);im2=image_at(26.9666);arr1=np.asarray(im1).astype(float);arr2=np.asarray(im2).astype(float);report['final_hold']={'start_seconds':23.60,'end_seconds':27,'mean_absolute_rgb_difference':float(np.abs(arr1-arr2).mean()),'maximum_rgb_difference':float(np.abs(arr1-arr2).max())};assert report['final_hold']['mean_absolute_rgb_difference']<.5
im2.save(OUT/'frame-final.png')
# Six frames, extracted from the encoded final master, not the source timeline.
times=[0,6.20,13.07,17.53,19.53,26.0];canvas=Image.new('RGB',(1136,1432),'#272724');d=ImageDraw.Draw(canvas);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
for i,t in enumerate(times):
 im=image_at(t).resize((360,640),Image.Resampling.LANCZOS);x=16+i%3*376;y=16+i//3*704;canvas.paste(im,(x,y));d.text((x+10,y+652),f'{t:05.2f}s',font=font,fill='#F4F0E7')
canvas.save(OUT/'contact-sheet.png');report['contact_sheet_timestamps']=times
(OUT/'verification-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
