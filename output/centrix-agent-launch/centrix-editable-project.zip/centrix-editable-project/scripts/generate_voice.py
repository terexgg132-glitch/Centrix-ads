"""Generate Egyptian Arabic voice segments, preserving the configured network proxy.
Install edge-tts, then run this script. Network must allow speech.platform.bing.com.
"""
import asyncio,json,os,ssl,subprocess
from pathlib import Path
import certifi
# The managed environment injects a CA certificate for its HTTPS proxy.
ca=os.environ.get('SSL_CERT_FILE') or '/etc/ssl/certs/ca-certificates.crt'
if Path(ca).exists():certifi.where=lambda:ca
import edge_tts
ROOT=Path(__file__).resolve().parent.parent
SCRIPT=json.loads((ROOT/'scripts/voice-script.json').read_text())
async def main():
 out=ROOT/'public/audio/voice';out.mkdir(exist_ok=True)
 for row in SCRIPT:
  dest=out/(row['id']+'.mp3')
  if dest.exists() and dest.stat().st_size>1000:continue
  voice=edge_tts.Communicate(row['text'],'ar-EG-ShakirNeural',rate='-2%',pitch='-2Hz',proxy=os.environ.get('HTTPS_PROXY'))
  await voice.save(str(dest))
  print(row['id'],dest.stat().st_size,flush=True)
asyncio.run(main())
