import React from "react";
import { useCurrentFrame } from "remotion";
import { SceneFrame, C, Micro, p, Icon } from "../design";
export const Promise = () => {
  const f = useCurrentFrame();
  return (
    <SceneFrame light>
      <div
        style={{
          position: "absolute",
          width: 950,
          height: 950,
          left: -400,
          top: 40,
          border: "1px solid #8a691955",
          rotate: `${45 + f * 0.07}deg`,
          opacity: 0.5,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 950,
          height: 950,
          right: -400,
          top: 40,
          border: "1px solid #8a691955",
          rotate: `${45 - f * 0.07}deg`,
          opacity: 0.5,
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 200,
          left: 100,
          right: 100,
          textAlign: "center",
        }}
      >
        <Micro style={{ color: "#80601e", opacity: p(f, 0, 22) }}>
          YOUR INTENT. IN MOTION.
        </Micro>
        <div
          dir="rtl"
          style={{
            fontSize: 113,
            fontWeight: 500,
            lineHeight: 1.6,
            marginTop: 55,
            opacity: p(f, 5, 31),
            translate: `0 ${(1 - p(f, 5, 31)) * 40}px`,
          }}
        >
          إنت تقول المطلوب.
        </div>
        <div
          dir="rtl"
          style={{
            fontSize: 139,
            fontWeight: 600,
            lineHeight: 1.45,
            color: "#967020",
            opacity: p(f, 35, 64),
            translate: `0 ${(1 - p(f, 35, 64)) * 40}px`,
          }}
        >
          وسنتركس ينفّذ.
        </div>
        <div
          style={{
            width: 100,
            height: 2,
            background: "#b29448",
            margin: "48px auto",
            scale: p(f, 65, 100),
          }}
        />
        <div
          dir="rtl"
          style={{ fontSize: 40, color: "#666258", opacity: p(f, 90, 116) }}
        >
          وقت أكتر للتدريس. مساحة أكبر للنمو.
        </div>
      </div>
    </SceneFrame>
  );
};
