import React from "react";
import { useCurrentFrame } from "remotion";
import {
  SceneFrame,
  C,
  Micro,
  p,
  Header,
  TaskLabel,
  Icon,
  Check,
  Rail,
  Beam,
} from "../design";
export const Attendance = () => {
  const f = useCurrentFrame();
  const done = p(f, 74, 96);
  return (
    <SceneFrame grid>
      <Header number="03" label="EXECUTE" />
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 175,
          left: 150,
          right: 150,
          textAlign: "center",
          fontSize: 88,
          fontWeight: 500,
          opacity: p(f, 0, 23),
        }}
      >
        «سجّل حضوره»
      </div>
      <svg
        width="1920"
        height="1080"
        style={{ position: "absolute", inset: 0 }}
      >
        <path d="M400 565H1520" stroke="#b38b3c30" strokeWidth="2" />
        <path
          d="M400 565H1520"
          stroke={C.gold}
          strokeWidth="3"
          strokeDasharray="1120"
          strokeDashoffset={1120 * (1 - p(f, 25, 78))}
        />
        <circle cx={400 + 1120 * p(f, 25, 78)} cy="565" r="7" fill={C.pale} />
      </svg>
      <div
        style={{
          position: "absolute",
          left: 190,
          top: 400,
          width: 330,
          height: 330,
          border: "1px solid #cfaa5450",
          borderRadius: 20,
          background: "#0e1011",
          textAlign: "center",
          padding: 45,
          scale: 0.9 + p(f, 5, 34) * 0.1,
          opacity: p(f, 5, 34),
        }}
      >
        <Icon name="student" size={68} />
        <div dir="rtl" style={{ fontSize: 41, marginTop: 23 }}>
          عمر أحمد
        </div>
        <Micro style={{ fontSize: 17, marginTop: 22 }}>ID / 1042</Micro>
      </div>
      <div
        style={{
          position: "absolute",
          left: 695,
          top: 420,
          width: 250,
          height: 250,
          rotate: "45deg",
          border: "1px solid #e8ba5588",
          background: "linear-gradient(135deg,#44351b,#0b0d0d 70%)",
          boxShadow: "0 0 100px #e8ba5514",
          opacity: p(f, 18, 48),
        }}
      >
        <div
          style={{
            rotate: "-45deg",
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 20,
          }}
        >
          <Icon name="spark" size={65} />
          <Micro style={{ fontSize: 17, letterSpacing: 3 }}>AI AGENT</Micro>
        </div>
      </div>
      <div
        dir="rtl"
        style={{
          position: "absolute",
          left: 1150,
          top: 365,
          width: 560,
          height: 400,
          border: `1px solid ${done > 0.5 ? "#e8ba5588" : "#53565b"}`,
          borderRadius: 24,
          background: "linear-gradient(130deg,#1b1e1d,#0b0d0f)",
          padding: 45,
          opacity: p(f, 27, 53),
          translate: `${(1 - p(f, 27, 53)) * 80}px 0`,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Icon name="attendance" size={58} />
          <span style={{ fontSize: 27, color: C.muted }}>الحضور</span>
        </div>
        <div style={{ fontSize: 49, marginTop: 30 }}>عمر أحمد</div>
        <div style={{ height: 1, background: "#ffffff14", marginTop: 22 }} />
        <div style={{ position: "relative", height: 80, marginTop: 23 }}>
          <div style={{ fontSize: 35, color: C.muted, opacity: 1 - done }}>
            جاري تنفيذ الطلب…
          </div>
          <div
            style={{
              position: "absolute",
              inset: 0,
              color: C.pale,
              opacity: done,
              display: "flex",
              alignItems: "center",
              gap: 18,
            }}
          >
            <Check size={56} />
            <span style={{ fontSize: 42 }}>تم تسجيل الحضور</span>
          </div>
        </div>
      </div>
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 816,
          left: 0,
          right: 0,
          textAlign: "center",
          fontSize: 31,
          color: C.gold,
          opacity: p(f, 104, 124),
        }}
      >
        المهمة اتنفّذت جوّه النظام.
      </div>
      <Rail progress={0.25 + 0.25 * p(f, 30, 105)} />
      <TaskLabel />
    </SceneFrame>
  );
};
