import React from "react";
import { Composition, Folder } from "remotion";
import { Film } from "./Film";
import { Pressure } from "./scenes/Pressure";
import { Reply } from "./scenes/Reply";
import { Agent } from "./scenes/Agent";
import { FindStudent } from "./scenes/FindStudent";
import { Attendance } from "./scenes/Attendance";
import { Finance } from "./scenes/Finance";
import { Network } from "./scenes/Network";
import { Promise } from "./scenes/Promise";
import { Brand } from "./scenes/Brand";
export const Root = () => (
  <>
    <Composition
      id="CentrixLaunch"
      component={Film}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={1650}
    />
    <Folder name="Scenes">
      <Composition
        id="EveryDetail"
        component={Pressure}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={180}
      />
      <Composition
        id="TheAnswer"
        component={Reply}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={150}
      />
      <Composition
        id="IntoAction"
        component={Agent}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={150}
      />
      <Composition
        id="FindStudent"
        component={FindStudent}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={180}
      />
      <Composition
        id="ExecuteAttendance"
        component={Attendance}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={180}
      />
      <Composition
        id="RetrievePayments"
        component={Finance}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={180}
      />
      <Composition
        id="ConnectedSystem"
        component={Network}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={240}
      />
      <Composition
        id="YourIntent"
        component={Promise}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={180}
      />
      <Composition
        id="Brand"
        component={Brand}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={210}
      />
    </Folder>
  </>
);
