"""Original Centrix score and sound-design stems. No samples or external music.
Reproducible NumPy/SciPy synthesis: 108 BPM, D minor → F major, 55 seconds.
"""
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io.wavfile import write
from pathlib import Path
SR=48000; D=55.; N=int(SR*D); rng=np.random.default_rng(1409)
music=np.zeros((N,2),np.float64); fx=np.zeros_like(music)
def add(dst,s,t,g=1,pan=0):
 i=int(t*SR)
 if i<0:s=s[-i:];i=0
 n=min(len(s),len(dst)-i)
 if n<=0:return
 if s.ndim==1:s=np.column_stack([s*np.sqrt((1-pan)/2),s*np.sqrt((1+pan)/2)])
 dst[i:i+n]+=s[:n]*g
def midi(n):return 440*2**((n-69)/12)
def env(t,a=.02,d=.4):return np.minimum(1,t/a)*np.exp(-t/d)
def tone(note,dur=1.,kind='pluck'):
 t=np.arange(int(dur*SR))/SR;hz=midi(note)
 if kind=='pluck':
  s=sum(np.sin(2*np.pi*hz*k*t+(.16 if k>1 else 0))*np.exp(-t*(1.3+k*.75))/(k**1.5) for k in range(1,7))
  return s*np.minimum(t/.008,1)*np.minimum((dur-t)/.1,1)
 if kind=='bass':return (np.sin(2*np.pi*hz*t)+.2*np.sin(2*np.pi*hz*2*t))*env(t,.018,.3)
 if kind=='bell':return (np.sin(2*np.pi*hz*t)+.45*np.sin(2*np.pi*hz*2.76*t)+.16*np.sin(2*np.pi*hz*4.05*t))*env(t,.004,.45)
 return np.sin(2*np.pi*hz*t)
def pad(notes,dur):
 t=np.arange(int(dur*SR))/SR;s=np.zeros((len(t),2))
 for j,n in enumerate(notes):
  for ch,det in enumerate([-.0018,.0018]):
   hz=midi(n)*(1+det)
   for k in range(1,6):s[:,ch]+=np.sin(2*np.pi*hz*k*t+j*.7)/(k**2.5)
 e=np.minimum(t/1.4,1)*np.minimum((dur-t)/1.9,1)
 return s*e[:,None]/len(notes)
def kick(dur=.6):
 t=np.arange(int(dur*SR))/SR;freq=46+95*np.exp(-t*29);phase=np.cumsum(freq)/SR*2*np.pi
 return np.sin(phase)*np.exp(-t*10)+.09*rng.normal(size=len(t))*np.exp(-t*160)
def hat(dur=.14):
 t=np.arange(int(dur*SR))/SR;s=rng.normal(size=len(t));s=sosfilt(butter(3,7000,fs=SR,btype='high',output='sos'),s)
 return s*env(t,.001,.025)
def snare(dur=.23):
 t=np.arange(int(dur*SR))/SR;s=rng.normal(size=len(t));s=sosfilt(butter(2,[1500,6500],fs=SR,btype='band',output='sos'),s)
 return .55*s*env(t,.003,.055)+.2*np.sin(2*np.pi*180*t)*env(t,.004,.035)
def swell(t0,dur,g=.3):
 t=np.arange(int(dur*SR))/SR;s=rng.normal(size=len(t));s=sosfilt(butter(2,[650,4700],fs=SR,btype='band',output='sos'),s);e=(t/dur)**2*np.minimum((dur-t)/.06,1)
 add(fx,s*e,t0,g,-.2)
 add(fx,s[::-1]*e,t0,g*.6,.5)
def impact(t0,g=.6):
 t=np.arange(int(SR*1.6))/SR
 add(fx,np.sin(2*np.pi*(43*t+6*(1-np.exp(-t*12))))*env(t,.005,.34),t0,g)
 add(fx,tone(74,1.4,'bell'),t0,.1)
# Opening: breath, clock, restrained ominous harmonic bed.
add(music,pad([38,50,57,62],7),0,.29)
for t0 in [0.5,1.5,2.5,3.5,4.5,5.25,5.6]:add(fx,tone(85,.12,'bell'),t0,.055,(-1 if int(t0*2)%2 else 1)*.3)
add(music,pad([38,45,53],5),6,.22)
# Brand turning point: deliberately empty just before the strike.
swell(10.15,.85,.35);impact(11,.8)
add(music,pad([38,50,57,65,69],6.2),11,.37)
# Pulse arrangement. Detailed but spacious, leaves room for Egyptian narration.
beat=60/108;step=beat/2
chords=[[50,57,62,65],[46,53,58,62],[53,60,65,69],[48,55,60,64]]
for bar in range(12):
 t0=16+bar*4*beat
 if t0>=42:break
 ch=chords[(bar//2)%4]
 if bar%2==0:add(music,pad(ch,4*beat*2+1.6),t0,.24)
 for b in range(4):
  t=t0+b*beat
  if t<42:
   add(music,kick(),t,.34 if bar<8 else .42)
   add(music,tone(ch[0]-12,.45,'bass'),t+.03,.25)
   if b%2:add(music,snare(),t,.10,.08)
  for h in range(2):
   tt=t+h*step
   if tt<42:add(music,hat(),tt,.055 if h else .035,(-.35 if h else .35))
 for j in range(8):
  t=t0+j*step
  if t<42:
   note=ch[[0,2,1,3,2,1,3,2][j]]+12
   s=tone(note,1.5)
   add(music,s,t,.11,(-.35 if j%2 else .35))
   add(music,s,t+beat*.75,.03,(-.35 if not j%2 else .35))
# Precisely timed mechanism gestures and completion signatures.
for t0 in [16,22,28,34,42,48]:swell(t0-.6,.6,.18);impact(t0,.35)
for t0 in [18.6,24.7,30.8]:
 add(fx,tone(74,.65,'bell'),t0,.16,-.2)
 add(fx,tone(81,.9,'bell'),t0+.115,.13,.2)
 add(fx,tone(86,1.2,'bell'),t0+.25,.055,.5)
for t0 in [34.8,35.2,35.6,36.0]:add(fx,tone(81,.45,'bell'),t0,.06,(t0-35.4)*.7)
# Open, optimistic resolution and an original three-note sonic signature.
add(music,pad([41,53,60,65,69],7.8),41.5,.43)
for t0,n in [(42,77),(43.12,81),(44.24,84),(45.35,81),(46.47,77)]:add(music,tone(n,2.2),t0,.095,.15)
add(music,pad([41,53,60,65,69],7.0),48,.34)
for t0,n in [(49.0,65),(49.42,69),(49.84,72)]:add(fx,tone(n,3.2,'bell'),t0,.22,(n-69)/12)
# Stereo diffuse echoes; short deliberate reverberation, no uncontrolled wash.
for dst in [music,fx]:
 dry=dst.copy()
 for sec,decay in [(.113,.10),(.181,.08),(.293,.06),(.479,.035),(.719,.02)]:
  q=int(sec*SR);dst[q:,0]+=dry[:-q,1]*decay;dst[q:,1]+=dry[:-q,0]*decay
 fade=np.minimum(np.arange(N)/SR/.06,1)*np.minimum((D-np.arange(N)/SR)/1.6,1)
 dst*=fade[:,None]
 dst[:]=np.tanh(dst*.88)
base=Path(__file__).resolve().parent.parent/'public'/'audio';base.mkdir(exist_ok=True)
for name,s in [('music',music),('sfx',fx)]:
 write(base/(name+'.wav'),SR,(s.clip(-1,1)*32767).astype('int16'));print(name,'peak',float(abs(s).max()))
