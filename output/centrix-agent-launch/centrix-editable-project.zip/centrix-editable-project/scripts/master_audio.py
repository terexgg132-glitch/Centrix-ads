"""Mix and master the original music, designed effects and Egyptian narration.
FFmpeg applies voice EQ, gentle compression and music ducking, then two-pass EBU
R128 normalization. Targets: -16 LUFS integrated, -1 dBTP maximum, stereo 48 kHz.
"""
from pathlib import Path
import subprocess,json,re
ROOT=Path(__file__).resolve().parent.parent;A=ROOT/'public/audio'
raw=A/'mix-premaster.wav';out=A/'final-mix.wav'
fc='[0:a]highpass=f=78,lowpass=f=11500,acompressor=threshold=0.18:ratio=2.2:attack=8:release=100,volume=1.45,asplit=2[v][key];[1:a]volume=0.45[m];[m][key]sidechaincompress=threshold=0.018:ratio=5:attack=15:release=340:makeup=1[duck];[2:a]volume=0.58[s];[v][duck][s]amix=inputs=3:normalize=0,alimiter=limit=0.94:level=0[a]'
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(A/'narration.wav'),'-i',str(A/'music.wav'),'-i',str(A/'sfx.wav'),'-filter_complex',fc,'-map','[a]','-ar','48000','-ac','2','-c:a','pcm_s24le',str(raw)],check=True)
p=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-16:TP=-1:LRA=7:print_format=json','-f','null','-'],text=True,capture_output=True,check=True)
m=json.loads(re.findall(r'\{\s*"input_i".*?\}',p.stderr,re.S)[-1])
f=f"loudnorm=I=-16:TP=-1:LRA=7:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=json"
p=subprocess.run(['ffmpeg','-y','-hide_banner','-i',str(raw),'-af',f,'-ar','48000','-ac','2','-c:a','pcm_s24le',str(out)],text=True,capture_output=True,check=True)
(A/'mastering-report.json').write_text(json.dumps({'input':m,'output':json.loads(re.findall(r'\{\s*"input_i".*?\}',p.stderr,re.S)[-1])},indent=2))
print(out)
