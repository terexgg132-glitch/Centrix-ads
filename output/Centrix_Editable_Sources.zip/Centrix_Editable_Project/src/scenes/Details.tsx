import React from 'react';
import {AbsoluteFill} from 'remotion';
import {CameraMotionBlur} from '@remotion/motion-blur';
import {BG,C,Text,Label,Thread,Plate,Icon,Concept,prog,mix,useScene} from '../design';

const DetachedLayers:React.FC=()=>{const {f,fps}=useScene();const split=prog(f,0,.70*fps),p2=prog(f,4,.8*fps),p3=prog(f,8,.8*fps);return <>
<Plate x={mix(220,123,split)} y={mix(737,638,split)} w={mix(640,596,split)} h={mix(500,240,split)} style={{rotate:mix(0,-5,split)+'deg'}}>
<div style={{position:'absolute',left:33,top:35}}><Icon type="attendance" size={70}/></div>
<Text x={119} y={32} w={440} size={50} align="right">الحضور والغياب</Text>
<div style={{position:'absolute',top:132,left:35,right:35,display:'flex',gap:20}}>
{[1,1,0,1,1,0].map((n,i)=><div key={i} style={{width:71,height:45,borderRadius:9,border:'1px solid #8A7A5144',background:n?'#DDB34B1C':'#8A7A5106',color:n?C.gold:C.gray,fontSize:24,textAlign:'center',paddingTop:6}}>{n?'✓':'—'}</div>)}</div>
</Plate>
<Plate x={mix(220,348,p2)} y={mix(737,894,p2)} w={mix(640,600,p2)} h={mix(500,280,p2)} style={{rotate:mix(0,6,p2)+'deg',opacity:p2}}>
<div style={{position:'absolute',left:32,top:35}}><Icon type="payment" size={71}/></div>
<Text x={117} y={34} w={440} size={49} align="right">التحصيل والحسابات</Text>
<Text x={32} y={130} w={525} size={37} color={C.gray} align="right">إيصالات · دفعات · مراجعة</Text>
<div style={{position:'absolute',top:213,left:38,width:110,height:5,background:'#DDB34BAA',borderRadius:4}}/>
<div style={{position:'absolute',top:213,left:165,width:255,height:5,background:'#827A6833',borderRadius:4}}/>
</Plate>
<Plate x={mix(220,144,p3)} y={mix(737,1197,p3)} w={mix(640,644,p3)} h={mix(500,232,p3)} style={{rotate:mix(0,-3,p3)+'deg',opacity:p3}}>
<div style={{position:'absolute',left:35,top:35}}><Icon type="report" size={68}/></div>
<Text x={125} y={31} w={481} size={49} align="right">المجموعات والمتابعة</Text>
<div style={{position:'absolute',left:36,top:140,display:'flex',gap:20}}>
{['حصة','مجموعة','تقرير'].map((x,i)=><div key={x} dir="rtl" style={{width:178,height:56,borderRadius:10,background:i===2?'#DDB34B19':'#77716614',border:'1px solid #77716633',textAlign:'center',fontSize:31,color:i===2?C.gold:C.gray,fontWeight:600,paddingTop:6}}>{x}</div>)}
</div>
</Plate>
</>};
export const Details:React.FC=()=>{const {f,fps}=useScene();const hit=prog(f,1.896*fps,10);return <AbsoluteFill>
<BG frame={f+81}/><Label index="CENTRIX">يوم السنتر فيه أكتر</Label>
<Text y={348} size={72} style={{opacity:prog(f,.20*fps,12)}}>ورا كل حصة</Text>
<Text y={456} size={101} color={C.gold} weight={900} style={{opacity:hit,translate:'0 '+mix(20,0,hit)+'px'}}>تفاصيل كتير</Text>
<Thread d="M50 960C178 960 218 687 303 687L530 687M792 866L792 1248C792 1370 907 1470 1040 1470" p={prog(f,0,70)} opacity={.28} width={1.6}/>
<CameraMotionBlur samples={3} shutterAngle={75}><DetachedLayers/></CameraMotionBlur>
<Concept/>
</AbsoluteFill>};
