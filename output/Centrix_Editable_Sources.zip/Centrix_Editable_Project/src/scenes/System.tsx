import React from 'react';
import {AbsoluteFill,useVideoConfig} from 'remotion';
import {BG,C,Text,Label,Plate,Icon,Thread,Concept,prog,mix,useScene,MiniChart} from '../design';

export const SystemArchitecture:React.FC<{frame:number;mode?:'organize'|'hero'|'network'}>=({frame:f,mode='hero'})=>{
 const {fps}=useVideoConfig();
 const organizing=mode==='organize';const spread=organizing?1-prog(f,0,26):0;
 const entry=organizing?prog(f,0,24):1;
 const lock=organizing?0:prog(f,2.715*fps,14);
 const report=organizing?1:prog(f,14,27);
 const aPulse=organizing?1:1+.055*Math.sin(Math.PI*Math.max(0,Math.min(1,f/25)));
 const bPulse=organizing?1:1+.055*Math.sin(Math.PI*Math.max(0,Math.min(1,(f-22)/25)));
 return <>
 <svg width="1080" height="1920" style={{position:'absolute',opacity:.4*entry}}><rect x="110" y="545" width="860" height="905" rx="42" fill="#0B0B0E" stroke="#DDB34B55" strokeWidth={mix(1.3,2,lock)}/>
 <path d="M140 875H940M140 1100H940" stroke="#56504244" strokeWidth=".8"/><path d="M125 545H170M110 560V605M955 545H910M970 560V605M125 1450H170M110 1435V1390M955 1450H910M970 1435V1390" stroke={C.gold} strokeWidth="3" strokeLinecap="round"/>
 </svg>
 <Thread d="M327 855L327 930Q327 975 376 975L704 975Q755 975 755 930L755 855M540 975L540 1130" p={entry*report} width={mix(2.3,3.2,lock)} opacity={.75}/>
 <Plate x={140-spread*130} y={590-spread*60} w={375} h={270} style={{rotate:-spread*8+'deg',opacity:entry,scale:mix(.9,1,entry)*aPulse}}>
 <div style={{position:'absolute',left:25,top:27}}><Icon type="attendance" size={65}/></div>
 <Text x={106} w={234} y={33} size={47} align="right">الحضور</Text>
 <div style={{position:'absolute',left:28,right:28,top:115,borderTop:'1px solid #74705D44'}}/>
 <div style={{position:'absolute',left:29,top:145,display:'flex',gap:16}}>
 {[1,1,1,0,1].map((n,i)=><svg width="49" height="50" viewBox="0 0 50 50" key={i}><rect x="1" y="1" width="47" height="47" rx="11" fill={n?'#DDB34B14':'#A6A29A09'} stroke={n?'#DDB34B66':'#74705D44'}/>{n?<path d="M13 24L22 32L37 16" stroke={C.gold} strokeWidth="2.5" fill="none"/>:<path d="M15 25H35" stroke={C.gray} strokeWidth="2"/>}</svg>)}
 </div><Text x={24} y={210} w={327} size={30} color={C.gray}>سجل الحضور والغياب</Text>
 </Plate>
 <Plate x={565+spread*130} y={590+spread*160} w={375} h={270} style={{rotate:spread*9+'deg',opacity:entry,scale:mix(.9,1,entry)*bPulse}}>
 <div style={{position:'absolute',left:24,top:28}}><Icon type="payment" size={65}/></div>
 <Text x={108} w={232} y={33} size={47} align="right">الحسابات</Text>
 <div style={{position:'absolute',left:28,right:28,top:115,borderTop:'1px solid #74705D44'}}/>
 <Text x={29} y={146} w={317} size={31} weight={650} align="right">مدفوعات · تحصيل</Text>
 <div style={{position:'absolute',left:29,top:221,width:60,height:5,background:C.gold,borderRadius:5}}/>
 <div style={{position:'absolute',left:103,top:221,width:108,height:5,background:'#58503D',borderRadius:5}}/>
 <div style={{position:'absolute',left:225,top:221,width:117,height:5,background:'#39362F',borderRadius:5}}/>
 </Plate>
 <Plate x={325} y={902} w={430} h={183} active style={{opacity:entry,scale:mix(.9,1,entry)}}>
 <div style={{position:'absolute',left:21,top:31}}><Icon type="student" size={85}/></div>
 <Text x={115} y={31} w={285} size={44} align="right">ملف الطالب</Text>
 <Text x={102} y={105} w={297} size={29} color={C.gray} align="right">QR · الاسم · الكود</Text>
 </Plate>
 <Plate x={organizing?mix(230,140,entry):140} y={organizing?mix(625,1128,entry):1128} w={organizing?mix(620,800,entry):800} h={organizing?mix(530,283,entry):283} style={{opacity:1}}>
 <div style={{position:'absolute',left:24,top:25}}><Icon type="report" size={68}/></div>
 <Text x={111} y={24} w={organizing?mix(450,652,entry):652} size={48} align="right">التقارير</Text>
 <div style={{position:'absolute',left:31,top:organizing?mix(210,119,entry):119}}><MiniChart p={report} w={organizing?mix(558,733,entry):733} h={organizing?mix(160,90,entry):90}/></div>
 <Text x={33} y={organizing?mix(431,221,entry):221} w={organizing?mix(560,730,entry):730} size={30} color={C.gray} align="right">الحضور · الحسابات · المتابعة</Text>
 </Plate>
 </>;
};
export const Organize:React.FC=()=>{const {f}=useScene();return <AbsoluteFill><BG frame={f+267}/><Label index="CENTRIX">كل التفاصيل تتصل</Label><Text y={349} size={78} color={C.gold} style={{opacity:prog(f,2,12)}}>ومع سنتريكس</Text><SystemArchitecture frame={f} mode="organize"/><Thread d="M1020 465C805 465 955 975 540 975C190 975 275 1450 60 1450" p={prog(f,0,27)} opacity={.9}/><Concept/></AbsoluteFill>};
export const UnifiedSystem:React.FC=()=>{const {f,fps}=useScene();const lock=prog(f,2.715*fps,15);return <AbsoluteFill><BG frame={f+300}/><Label index="CENTRIX">الطالب في قلب المنظومة</Label>
<Text y={317} size={64} style={{opacity:1-lock,translate:'0 '+(-lock*32)+'px'}}>الحضور · الحسابات</Text>
<Text y={399} size={86} style={{opacity:1-lock,translate:"0 "+(-lock*32)+"px"}}>والتقارير</Text>
<Text y={313} size={46} color={C.gray} style={{opacity:lock,translate:'0 '+mix(25,0,lock)+'px'}}>كلهم في</Text>
<Text y={378} size={98} style={{opacity:lock,translate:'0 '+mix(32,0,lock)+'px'}}>سيستم <span style={{color:C.gold}}>واحد</span></Text>
<div style={{position:"absolute",inset:0,scale:mix(1,1.025,prog(f,0,80))-.025*lock,transformOrigin:"540px 980px"}}><SystemArchitecture frame={f}/></div><Concept/></AbsoluteFill>};
