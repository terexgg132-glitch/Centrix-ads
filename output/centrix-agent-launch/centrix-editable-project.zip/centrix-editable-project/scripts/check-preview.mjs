import { openBrowser } from "@remotion/renderer";
import { writeFileSync } from "node:fs";
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.CHROME_PATH || "/usr/bin/chromium",
  logLevel: "error",
});
try {
  const page = await browser.newPage({
    context: () => null,
    logLevel: "error",
    indent: false,
    pageIndex: 0,
    onBrowserLog: null,
    onLog: () => {},
  });
  await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 1 });
  await page.goto({
    url: process.argv[2] || "http://localhost:3000/CentrixLaunch",
    timeout: 20000,
  });
  await new Promise((r) => setTimeout(r, 4500));
  console.log(
    await page.evaluate(() => ({
      title: document.title,
      body: document.body.innerText.slice(0, 1500),
      videos: [...document.querySelectorAll("video")].map((v) => ({
        readyState: v.readyState,
        duration: v.duration,
        error: v.error?.message,
      })),
    })),
  );
  const pic = await page
    ._client()
    .send("Page.captureScreenshot", { format: "png" });
  writeFileSync(
    process.argv[3] || "/workspace/work/review/studio.png",
    Buffer.from(pic.value.data, "base64"),
  );
} finally {
  await browser.close({ silent: true });
}
