import React from 'react';
import {AbsoluteFill,Img,staticFile} from 'remotion';
import {V,Type,Stage,Ribbon,Trace,DiagramNote,p,lerp,now,sat} from './primitives';
import {World} from './World';

export const HookV2:React.FC=()=>{const {t}=now();const read=p(t,.22,.20);return <Stage t={t}>
 <World t={t} mode="hook"/>
 <Type y={277} size={44} color={V.gray} opacity={read}>فاكر إن شغل السنتر بيبدأ مع</Type>
 <Type y={375} size={162} weight={950} opacity={read} style={{translate:'0 '+lerp(28,0,read)+'px'}}>الحصة؟</Type>
 <div style={{position:"absolute",left:0,top:1300,width:1080,height:310,background:"linear-gradient(transparent,#08080BCC 52%,#08080B)"}}/>
 <Type y={1375} size={52} weight={750} opacity={p(t,1.22,.24)}>كارنيه الطالب</Type>
 <Type y={1450} size={32} color={V.gold} weight={650} opacity={p(t,1.7,.24)}>QR · الاسم · الكود</Type>
 <DiagramNote opacity={.7}/>
 </Stage>};
export const ChaosV2:React.FC=()=>{const {f,fps}=now();const t=(f+81)/fps;const headline=p(t,4.596,.20);return <Stage t={t}>
 <World t={t} mode="chaos"/>
 <Type y={286} size={76} opacity={p(t,3.233,.2)}>ورا كل حصة</Type>
 <Type y={398} size={104} color={V.gold} opacity={headline} style={{translate:'0 '+lerp(26,0,headline)+'px'}}>تفاصيل كتير</Type>
 <div style={{position:"absolute",left:0,top:1330,width:1080,height:260,background:"linear-gradient(transparent,#08080BCC 55%,#08080B)"}}/>
 <Type y={1433} size={36} color={V.gray} opacity={p(t,3.4,.3)}>مجموعات · إيصالات · متابعة</Type>
 <DiagramNote/>
 </Stage>};

export const AssistantV2:React.FC=()=>{const {f,fps}=now();const t=(f+440)/fps;const enter=p(t,14.685,.22),answer=p(t,16.42,.34),name=p(t,16.236,.22);
return <Stage t={t}>
 <svg width="1080" height="1920" style={{position:'absolute',inset:0}}>
 
 <circle cx="540" cy="1040" r="540" fill="#D7AB4207"/>
 <g transform={'translate(540 1030) rotate('+lerp(-8,1,enter)+')'}>
  <ellipse rx="456" ry="356" fill="none" stroke="#A6956840" strokeWidth="1"/>
  <ellipse rx="475" ry="376" fill="none" stroke="#A6956820" strokeWidth="1"/>
 </g>
 <Trace d="M960 1050C1050 1220 892 1420 542 1417C199 1414 71 1260 120 1030C136 698 870 621 960 1050" q={p(t,14.72,.7)} weight={3.3} color={V.gold} opacity={.6}/>
 <path d="M127 825Q127 770 184 770H897Q953 770 953 826V1007Q953 1063 897 1063H184Q127 1063 127 1007Z" fill="#191A20" stroke="#D2AC5C66" strokeWidth="1.8"/>
 <path d="M166 1125H914M166 1325H914" stroke="#A49A792F" strokeWidth="1"/>
 </svg>
 <Type y={321} size={96} weight={950} opacity={enter*(1-name)}>محتاج تعرف؟</Type>
 <Type y={271} size={128} weight={950} opacity={name} style={{translate:'0 '+lerp(38,0,enter)+'px'}}>اسأل.</Type>
 <Type y={431} size={112} color={V.gold} weight={950} opacity={name}>سنتريكس</Type>
 <Type y={590} size={44} color={V.gray} opacity={name}>مساعدك الذكي</Type>
 <Type x={171} y={823} w={738} size={49} weight={700} align="right" opacity={p(t,14.91,.25)}>مين غاب النهارده في<br/>مجموعة مستر محمد؟</Type>
 <Type x={169} y={1173} w={742} size={67} align="right" opacity={answer} style={{translate:'0 '+lerp(21,0,answer)+'px'}}>كشف الغياب</Type>
 <Type x={169} y={1265} w={742} size={30} weight={650} align="right" color={V.gold} opacity={answer}>مثال توضيحي · بدون بيانات طلاب حقيقية</Type>
 <Ribbon d="M154 1125C282 1111 385 1148 540 1125C708 1098 841 1135 938 1125" q={answer} weight={2.0} opacity={answer*.7}/>
 <DiagramNote/>
 </Stage>};
export const ConnectedV2:React.FC=()=>{const {f,fps}=now();const t=(f+536)/fps,fade=1-p(t,21.25,.41),show=p(t,18.526,.2);return <Stage t={t}>
 <div style={{position:'absolute',inset:0,opacity:fade}}><World t={t} mode="network"/></div>
 <Type y={291} size={82} opacity={show*fade}>كل تفاصيل سنتريكس</Type>
 <Type y={418} size={87} color={V.gold} opacity={p(t,20.045,.24)*fade}>متوصلة ببعضها</Type>
 <Type x={112} y={730} w={330} size={40} align="left" opacity={p(t,18.5,.3)*fade}>حضور</Type>
 <Type x={646} y={846} w={320} size={40} align="right" opacity={p(t,18.5,.3)*fade}>حسابات</Type>
 <Type x={611} y={1305} w={320} size={40} align="right" opacity={p(t,18.8,.3)*fade}>تقارير</Type>
 <Type x={111} y={1270} w={320} size={40} align="left" opacity={p(t,18.8,.3)*fade}>مساعد ذكي</Type>
 <div style={{position:'absolute',left:414,top:910,width:252,height:252,opacity:p(t,21.25,.40)}}><Img src={staticFile('assets/centrix_logo_original.svg')} style={{width:'100%',height:'100%'}}/></div>
 <DiagramNote opacity={fade}/>
 </Stage>};
export const BrandV2:React.FC=()=>{const {f,fps}=now();const t=(f+650)/fps;const hero=p(t,21.6667,.48),text=p(t,22.513,.28),fade=1-sat((t-26.65)/.35);
return <AbsoluteFill style={{background:'#020204',opacity:fade}}>
 <Img src={staticFile('assets/centrix_logo_original.svg')} style={{position:'absolute',left:lerp(414,110,hero),top:lerp(910,284,hero),width:lerp(252,860,hero),height:lerp(252,860,hero),objectFit:'contain'}}/>
 <Type y={1225} x={110} w={860} size={109} weight={950} opacity={text} style={{translate:'0 '+lerp(21,0,text)+'px'}}>سستم السنتر</Type>
 <div style={{position:'absolute',left:393,top:1385,width:294,height:1,background:'linear-gradient(90deg,transparent,#DDB34B88,transparent)',opacity:p(t,23.0,.22)}}/>
 <div style={{position:'absolute',top:1444,left:100,width:880,fontFamily:'Arial, sans-serif',fontSize:39,letterSpacing:3,textAlign:'center',color:V.gray,opacity:p(t,23.04,.26)}}>centrix.company</div>
 </AbsoluteFill>};
