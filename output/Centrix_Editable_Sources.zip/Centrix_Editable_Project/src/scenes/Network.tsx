import React from 'react';
import {AbsoluteFill,Img,staticFile} from 'remotion';
import {CameraMotionBlur} from '@remotion/motion-blur';
import {BG,C,Text,Label,Thread,Plate,Icon,Concept,prog,mix,useScene} from '../design';
type NodeProps={x:number;y:number;type:'attendance'|'payment'|'report'|'ai';title:string;f:number};
const Node:React.FC<NodeProps>=({x,y,type,title,f})=><Plate x={x} y={y} w={264} h={204} style={{opacity:1-prog(f,97,16),scale:1}}>
<div style={{position:'absolute',top:20,left:95}}><Icon type={type} size={74}/></div><Text x={10} y={126} w={244} size={43}>{title}</Text></Plate>;
const NetworkField:React.FC=()=>{const {f,fps}=useScene();const pull=prog(f,0,1.3*fps);const converge=prog(f,2.65*fps,34);const shrink=1-converge*.43;return <div style={{position:'absolute',inset:0,scale:mix(1.30,1,pull)*shrink,transformOrigin:'540px 1050px',opacity:1-prog(f,101,13)}}>
<svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity:.6}}><ellipse cx="540" cy="1040" rx="370" ry="325" fill="none" stroke="#DDB34B33" strokeWidth="1"/><ellipse cx="540" cy="1040" rx="480" ry="416" fill="none" stroke="#DDB34B16" strokeWidth="1"/></svg>
<Thread d="M276 853C276 1040 540 868 540 1003C540 1180 807 1092 807 939M540 1003C540 888 794 937 794 1163C794 1368 540 1286 540 1100C540 1286 273 1336 273 1153C273 1080 423 1070 540 1100" p={prog(f,0,29)} width={2.6} opacity={.8}/>
<Node x={mix(408,144,pull)+converge*150} y={mix(753,662,pull)+converge*150} type="attendance" title="الحضور" f={f}/>
<Node x={mix(408,672,pull)-converge*150} y={mix(753,744,pull)+converge*75} type="payment" title="الحسابات" f={f}/>
<Node x={mix(408,672,pull)-converge*150} y={mix(753,1162,pull)-converge*75} type="report" title="التقارير" f={f}/>
<Node x={mix(408,144,pull)+converge*150} y={mix(753,1156,pull)-converge*75} type="ai" title="المساعد" f={f}/>
<Plate x={380} y={954} w={320} h={217} active>
<div style={{position:'absolute',left:123,top:20}}><Icon type="student" size={75}/></div><Text x={10} y={127} w={300} size={47}>الطالب</Text>
</Plate>
<Thread d="M144 750Q540 520 936 848Q1090 1120 804 1380Q510 1590 144 1240" p={prog(f,19,76)} width={1.7} opacity={.4}/>
</div>};
export const Network:React.FC=()=>{const {f,fps}=useScene();const title=prog(f,.646*fps,12),both=prog(f,2.165*fps,12);return <AbsoluteFill><BG frame={f+536}/><Label index="CENTRIX">منظومة واحدة ليومك كله</Label>
<Text y={336} size={85} style={{opacity:title*(1-prog(f,96,17))}}>كل تفاصيل سنتريكس</Text>
<Text y={456} size={88} color={C.gold} style={{opacity:both*(1-prog(f,96,17)),translate:'0 '+mix(25,0,both)+'px'}}>متوصلة ببعضها</Text>
<CameraMotionBlur samples={3} shutterAngle={70}><NetworkField/></CameraMotionBlur>
<div style={{position:'absolute',left:402,top:906,width:276,height:276,opacity:prog(f,98,16)}}><Img src={staticFile('assets/centrix_logo_original.svg')} style={{width:'100%',height:'100%',objectFit:'contain'}}/></div>
<div style={{opacity:1-prog(f,96,17)}}><Concept/></div>
</AbsoluteFill>};
