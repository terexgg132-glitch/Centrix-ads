"""Validate finished media and create review frames from the encoded master."""
from pathlib import Path
import hashlib,json,subprocess,re
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'output/V2'; REVIEW=OUT/'review'
def run(args): return subprocess.run(args,check=True,capture_output=True,text=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
master=OUT/'Centrix_Cinematic_Final_27s_V2.mp4'
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(master)]).stdout)
v=next(s for s in probe['streams'] if s['codec_type']=='video')
a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['pix_fmt'])==(1080,1920,'30/1','yuv420p')
assert v['codec_name']=='h264' and a['codec_name']=='aac'
assert a['sample_rate']=='48000' and a['channels']==2
assert abs(float(probe['format']['duration'])-27)<.035
assert int(v.get('nb_frames','810'))==810
decode=run(['ffmpeg','-v','error','-i',str(master),'-f','null','-'])
assert not decode.stderr.strip(),decode.stderr
REVIEW.mkdir(exist_ok=True)
times=[.5,3.5,6.8,9.2,12.5,16.2,19.8,22.8,26.2]
images=[]
for i,t in enumerate(times):
 p=REVIEW/('scene_'+str(i+1).zfill(2)+'_'+str(t).replace('.','p')+'s.png')
 run(['ffmpeg','-y','-loglevel','error','-ss',str(t),'-i',str(master),'-frames:v','1',str(p)])
 images.append((p,t))
sheet=Image.new('RGB',(1620,3000),'#111115');draw=ImageDraw.Draw(sheet)
try:ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24)
except OSError:ft=ImageFont.load_default()
for i,(p,t) in enumerate(images):
 im=Image.open(p).convert('RGB').resize((540,960),Image.Resampling.LANCZOS)
 x=i%3*540;y=i//3*1000
 sheet.paste(im,(x,y));draw.text((x+22,y+967),f'{t:.1f} sec',font=ft,fill='#DDB34B')
sheet.save(REVIEW/'scene_contact_sheet.png')
loud=run(['ffmpeg','-hide_banner','-i',str(master),'-af','loudnorm=I=-14:TP=-1:LRA=11:print_format=json','-f','null','-']).stderr
metrics=json.loads(re.findall(r'\{\s*"input_i".*?\}',loud,re.S)[-1])
assert float(metrics['input_tp'])<=-1.0,metrics
assert -16.0<float(metrics['input_i'])<-13.0,metrics
# Technical phone proxy. This cannot replace listening on a physical handset.
(ROOT/'work/v2/audio').mkdir(parents=True,exist_ok=True)
run(['ffmpeg','-y','-loglevel','error','-i',str(OUT/'audio/Centrix_Final_Mix.wav'),'-af','highpass=f=180,lowpass=f=6500','-ac','1',str(ROOT/'work/v2/audio/phone_proxy.wav')])
voice_same=sha(ROOT/'assets/centrix_voice_original.mp3')==sha(OUT/'audio/Centrix_Voice_Original.mp3')
logo_same=sha(ROOT/'assets/centrix_logo_original.svg')==sha(ROOT/'public/assets/centrix_logo_original.svg')
assert voice_same and logo_same
p=ROOT/'work/v2/brand_hold_start.png'
run(['ffmpeg','-y','-loglevel','error','-ss','23.6','-i',str(master),'-frames:v','1',str(p)])
import numpy as np
first=np.asarray(Image.open(p).convert('RGB'),dtype=float)
last=np.asarray(Image.open(images[-1][0]).convert('RGB'),dtype=float)
mad=float(np.abs(first-last).mean())
assert mad<1.5,mad
report={'duration':float(probe['format']['duration']),'video':{k:v[k] for k in ['codec_name','width','height','r_frame_rate','pix_fmt','nb_frames']},'audio':{k:a[k] for k in ['codec_name','sample_rate','channels']},'integrated_lufs':float(metrics['input_i']),'true_peak_dbtp':float(metrics['input_tp']),'decode_errors':0,'original_voice_sha256':sha(ROOT/'assets/centrix_voice_original.mp3'),'original_logo_sha256':sha(ROOT/'assets/centrix_logo_original.svg'),'voice_original_bytes_preserved':voice_same,'public_logo_bytes_preserved':logo_same,'review_times_seconds':times,'brand_hold_mean_pixel_difference':mad,'physical_phone_speaker_listening':'Unavailable in cloud environment; phone-band proxy generated. Human listening still required.'}
(REVIEW/'validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
