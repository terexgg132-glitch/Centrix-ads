import { AbsoluteFill, Sequence, staticFile, useVideoConfig } from "remotion";
import { Audio } from "@remotion/media";
import { AdProps, C, ease, useMotion } from "./design";
import { Problem } from "./scenes/Problem";
import { Reveal } from "./scenes/Reveal";
import { Attendance } from "./scenes/Attendance";
import { Organization } from "./scenes/Organization";
import { Outro } from "./scenes/Outro";

export const CentrixAd: React.FC<AdProps> = ({
  sound,
  concept,
  voiceoverFile,
  parentNotifications,
}) => {
  const f = useMotion();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill
      style={{ background: C.blue, overflow: "hidden", fontFamily: "Cairo" }}
    >
      <svg width="1080" height="1920" style={{ position: "absolute" }}>
        <defs>
          <clipPath id="white-stage">
            <circle cx="540" cy="1040" r={2200 * ease(f, 259, 294)} />
          </clipPath>
        </defs>
        <rect
          width="1080"
          height="1920"
          fill={C.pale}
          clipPath="url(#white-stage)"
        />
        <circle cx="540" cy="1135" r={2200 * ease(f, 728, 758)} fill={C.blue} />
      </svg>
      <Sequence
        name="01 — Details accumulate"
        durationInFrames={Math.round(6.25 * fps)}
        premountFor={fps}
      >
        <Problem />
      </Sequence>
      <Sequence
        name="02 — One circle / Centrix"
        from={4.5 * fps}
        durationInFrames={Math.round(5.05 * fps)}
        premountFor={fps}
      >
        <Reveal />
      </Sequence>
      <Sequence
        name="03 — Attendance into notification"
        from={8.5 * fps}
        durationInFrames={8.2 * fps}
        premountFor={fps}
      >
        <Attendance parentNotifications={parentNotifications} />
      </Sequence>
      <Sequence
        name="04 — Notification into organization"
        from={16 * fps}
        durationInFrames={Math.round(9.35 * fps)}
        premountFor={fps}
      >
        <Organization />
      </Sequence>
      <Sequence
        name="05 — Hub into brand / CTA"
        from={23.5 * fps}
        durationInFrames={6.5 * fps}
        premountFor={fps}
      >
        <Outro />
      </Sequence>
      {concept && (
        <div
          dir="rtl"
          style={{
            position: "absolute",
            left: 82,
            top: 170,
            fontSize: 26,
            fontWeight: 600,
            color: f > 288 && f < 749 ? C.ink : C.white,
            opacity: 0.65,
          }}
        >
          تصوّر إعلاني
        </div>
      )}
      {sound && (
        <Audio
          src={staticFile("audio/centrix-soundtrack.wav")}
          premountFor={fps}
          volume={voiceoverFile ? 0.5 : 0.85}
        />
      )}
      {voiceoverFile && (
        <Audio src={staticFile(voiceoverFile)} premountFor={fps} volume={1} />
      )}
    </AbsoluteFill>
  );
};
