"""Original deterministic 120 BPM score and motion cues. No sampled assets."""
import numpy as np
import wave
from pathlib import Path

SR=48000
audio=np.zeros((SR*30,2),dtype=np.float64)
rng=np.random.default_rng(2026)

def add(t,sig,gain=.1,pan=0):
    start=round(t*SR); end=min(start+len(sig),len(audio))
    if start<0 or end<=start:return
    sig=sig[:end-start]*gain
    audio[start:end,0]+=sig*np.sqrt((1-pan)/2)
    audio[start:end,1]+=sig*np.sqrt((1+pan)/2)

def pluck(freq,d=.65):
    t=np.arange(round(d*SR))/SR
    env=(1-np.exp(-t*900))*np.exp(-t*7)
    return (np.sin(2*np.pi*freq*t)+.24*np.sin(2*np.pi*freq*2*t)+.09*np.sin(2*np.pi*freq*3*t))*env

def kick():
    t=np.arange(round(.18*SR))/SR
    return np.sin(2*np.pi*(52*t+10*(1-np.exp(-t*35))))*np.exp(-t*23)

def hat():
    n=round(.06*SR);t=np.arange(n)/SR;x=rng.normal(0,1,n)
    return (x-np.concatenate(([0],x[:-1])))*np.exp(-t*75)

def pop():
    t=np.arange(round(.095*SR))/SR
    return np.sin(2*np.pi*(480*t-950*t*t))*np.exp(-t*65)

def sweep(d=.4):
    t=np.arange(round(d*SR))/SR;x=rng.normal(0,1,len(t))
    x=np.convolve(x,np.ones(40)/40,mode='same')
    return x*np.sin(np.pi*t/d)**2+np.sin(2*np.pi*(190*t+330*t*t))*np.sin(np.pi*t/d)**2*.12

# The arrangement opens dry, then fills out when Centrix brings order.
chords=[[261.626,329.628,391.995,493.883],[293.665,349.228,440,523.251],[261.626,349.228,440,523.251],[246.942,293.665,391.995,493.883]]
for beat in range(60):
    t=beat*.5;ch=chords[(beat//8)%4]
    if beat<57:add(t,kick(),.12 if beat>16 else .07)
    if beat%2 and beat<57:add(t,hat(),.03)
    if beat>=16 and beat<55:
        add(t,pluck(ch[beat%4],.7),.075,(-.25 if beat%2 else .25))
        if beat%2==0:add(t+.25,pluck(ch[(beat+2)%4]*2,.45),.034,.35)
    if beat%4==0:
        add(t,pluck(ch[0]/2,1.4),.07)

for t in [.47,.8,1.13,1.47,1.8,2.13,2.47,2.8,9.16,9.46,9.76,11.24,11.74,12.24,16.4,16.64,16.88,17.1,20.0,20.5,26.6,27.05,28.22]:
    add(t,pop(),.21)
for t,d in [(4.45,.95),(5.68,.3),(8.58,.78),(12.7,.7),(15.52,.72),(23.55,.75),(24.2,.42),(26.53,.3)]:
    add(t,sweep(d),.17)
for t,root in [(6.02,523.251),(13.62,659.255),(24.48,523.251),(26.7,659.255)]:
    add(t,pluck(root,1.5),.17,-.2)
    add(t+.09,pluck(root*1.25,1.2),.13,.2)
    add(t+.18,pluck(root*1.5,1.2),.1)
for freq in [261.626,329.628,391.995,523.251]:add(28.5,pluck(freq,1.5),.10)
f=np.arange(len(audio))/SR
audio*=np.minimum(f/.05,1)[:,None]*np.clip((30-f)/.65,0,1)[:,None]
audio=np.tanh(audio*1.15)
audio*=.78/max(np.max(np.abs(audio)),.01)
out=Path('public/audio/centrix-soundtrack.wav')
with wave.open(str(out),'wb') as w:
    w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR)
    w.writeframes((audio*32767).astype('<i2').tobytes())
print(f'Original score: {out}; peak {np.max(np.abs(audio)):.3f}; duration 30.0s')
