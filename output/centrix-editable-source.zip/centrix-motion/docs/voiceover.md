# Optional Egyptian Arabic voiceover

Use a calm, warm Egyptian delivery with a smile in the voice, 135–150 words per minute. Leave the transition beats clear. The exported concept includes music and sound effects; voiceover is optional.

| Cue | Exact line |
| --- | --- |
| 0.5–3.6s | طلاب كتير... وتفاصيل أكتر؟ |
| 6.1–8.5s | خليها أبسط مع سنتريكس. |
| 9.5–12.7s | سجّل الحضور... وتابع بسهولة. |
| 17.2–20.6s | كل شغلك... في مكان واحد. |
| 25.1–27.8s | ركّز في الشرح، وسيب التنظيم علينا. |
| 28.1–29.3s | جرّب سنتريكس. |

For integration, place the aligned 30-second recording in `public/audio/voiceover.wav`, then set `voiceoverFile` to `audio/voiceover.wav` in the composition props. The music ducks automatically when a voiceover file is present.
