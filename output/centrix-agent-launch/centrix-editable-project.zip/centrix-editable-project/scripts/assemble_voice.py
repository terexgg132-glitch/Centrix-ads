import json,subprocess,wave
from pathlib import Path
import numpy as np
from scipy.io.wavfile import read,write
ROOT=Path(__file__).resolve().parent.parent;A=ROOT/'public/audio';SR=48000
rows=json.loads((ROOT/'scripts/voice-script.json').read_text());out=np.zeros(SR*55,dtype=np.float64)
for r in rows:
 src=A/'voice'/(r['id']+'.mp3');temp=A/'voice'/(r['id']+'-clean.wav')
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(src),'-af','silenceremove=start_periods=1:start_duration=0.02:start_threshold=-48dB,areverse,silenceremove=start_periods=1:start_duration=0.05:start_threshold=-48dB,areverse','-ar',str(SR),'-ac','1',str(temp)]
 subprocess.run(cmd,check=True);sr,x=read(temp);duration=len(x)/sr
 speed=max(1.,duration/r['maxDuration'])
 if speed>1.015:
  alt=temp.with_name(r['id']+'-fit.wav');subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(temp),'-af',f'atempo={speed:.5f}',str(alt)],check=True);sr,x=read(alt)
 x=x.astype(np.float64)/32768.;x*=.79/max(.01,abs(x).max());i=round(r['start']*SR);out[i:i+len(x)]+=x
 r['actualDuration']=len(x)/SR;r['timeCompression']=round(speed,5)
 print(r['id'],round(duration,2),'→',round(len(x)/SR,2),'seconds')
write(A/'narration.wav',SR,(np.clip(out,-1,1)*32767).astype('int16'))
(A/'voice-timing.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
