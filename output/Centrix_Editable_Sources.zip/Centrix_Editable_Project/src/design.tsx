import React from 'react';
import {AbsoluteFill, Easing, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender} from 'remotion';

export const C={bg:'#08080B',panel:'#141418',gold:'#DDB34B',light:'#F8F5ED',gray:'#9F9A92',line:'#38352E'};
export const ease=Easing.bezier(.16,1,.3,1);
export const clamp=(x:number)=>Math.max(0,Math.min(1,x));
export const mix=(a:number,b:number,p:number)=>a+(b-a)*p;
export const prog=(f:number,s:number,d:number)=>ease(clamp((f-s)/d));
export const ramp=(f:number,a:number,b:number)=>clamp((f-a)/(b-a));
export const font='Cairo, sans-serif';
if (typeof document!=='undefined') {
  const hold=delayRender('Load licensed Cairo variable Arabic font');
  const face=new FontFace('Cairo','url('+staticFile('fonts/Cairo.ttf')+')',{weight:'200 1000'});
  face.load().then(loaded=>{document.fonts.add(loaded);continueRender(hold);}).catch(()=>continueRender(hold));
}
export const BG:React.FC<{frame?:number}> = ({frame=0})=><AbsoluteFill style={{background:C.bg,color:C.light,fontFamily:font,overflow:'hidden'}}>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at '+(45+Math.sin(frame/150)*8)+'% 46%, #28231966 0%, #15141855 36%, #08080B 76%)'}}/>
  <svg width="1080" height="1920" style={{position:'absolute',opacity:.42}}>
    <defs><pattern id="grid" width="120" height="120" patternUnits="userSpaceOnUse"><path d="M 120 0 L 0 0 0 120" stroke="#A5A090" strokeWidth=".6" fill="none" opacity=".10"/></pattern></defs>
    <rect width="1080" height="1920" fill="url(#grid)"/>
    <ellipse cx="530" cy="950" rx="650" ry="620" fill="none" stroke={C.gold} strokeWidth="1" opacity=".07"/>
    <ellipse cx="530" cy="950" rx="760" ry="760" fill="none" stroke={C.gold} strokeWidth="1" opacity=".04"/>
  </svg>
  <AbsoluteFill style={{backgroundImage:'url('+staticFile('assets/grain.png')+')',opacity:.035,mixBlendMode:'screen'}}/>
</AbsoluteFill>;
export const Text:React.FC<{children:React.ReactNode;x?:number;y:number;w?:number;size?:number;weight?:number;color?:string;align?:'center'|'right'|'left';style?:React.CSSProperties}>=({children,x=100,y,w=880,size=64,weight=800,color=C.light,align='center',style})=>
<div dir="rtl" style={{position:'absolute',left:x,top:y,width:w,fontFamily:font,fontSize:size,fontWeight:weight,lineHeight:1.3,color,textAlign:align,...style}}>{children}</div>;
export const Label:React.FC<{children:React.ReactNode;y?:number;index?:string}>=({children,y=232,index='CENTRIX'})=><div style={{position:'absolute',left:120,top:y,width:840,display:'flex',alignItems:'center',justifyContent:'space-between',color:C.gray,fontFamily:font,fontSize:26,fontWeight:600}}>
<span style={{fontFamily:'Arial, sans-serif',fontSize:23,letterSpacing:4}}>{index}</span><span dir="rtl">{children}</span></div>;
export const Concept:React.FC<{y?:number}>=({y=1500})=><Text y={y} size={28} color={C.gray} weight={500}>تصوّر توضيحي للواجهة</Text>;
export const Thread:React.FC<{d:string;p?:number;opacity?:number;width?:number;dot?:boolean}>=({d,p=1,opacity=1,width=2.8,dot=true})=><svg width="1080" height="1920" style={{position:'absolute',inset:0,overflow:'visible',opacity}}>
<path d={d} fill="none" stroke={C.gold} strokeWidth={width+9} opacity=".10" pathLength={1} strokeDasharray="1" strokeDashoffset={1-p} style={{filter:'blur(6px)'}}/>
<path d={d} fill="none" stroke="#554B35" strokeWidth="1" opacity=".4"/>
<path d={d} fill="none" stroke={C.gold} strokeWidth={width} strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1-p}/>
{dot&&<path d={d} fill="none" stroke="#FFF1C4" strokeWidth={width+2} strokeLinecap="round" pathLength={1} strokeDasharray=".014 .986" strokeDashoffset={-Math.max(0,p-.018)}/>}
</svg>;
export const Plate:React.FC<{x:number;y:number;w:number;h:number;children:React.ReactNode;style?:React.CSSProperties;active?:boolean}>=({x,y,w,h,children,style,active})=><div style={{position:'absolute',left:x,top:y,width:w,height:h,borderRadius:30,background:'linear-gradient(135deg, #232228 0%, #111115 58%, #19171A 100%)',border:'1.5px solid '+(active?'#DDB34B88':'#77716644'),boxShadow:'0 30px 75px #0008, inset 0 1px 0 #FFFFFF0C',overflow:'hidden',...style}}>
<div style={{position:'absolute',left:26,right:26,top:0,height:1,background:'linear-gradient(90deg,transparent,#DDB34B88,transparent)'}}/>{children}</div>;
export const Icon:React.FC<{type:'attendance'|'payment'|'report'|'student'|'ai';size?:number;color?:string;progress?:number}>=({type,size=80,color=C.gold,progress=1})=><svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={color} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round">
{type==='attendance'&&<><rect x="17" y="17" width="66" height="66" rx="18" strokeOpacity=".4"/><path d="M31 51L45 65L70 36" pathLength={1} strokeDasharray="1" strokeDashoffset={1-progress}/></>}
{type==='payment'&&<><path d="M26 13H74V87L62 80L50 87L38 80L26 87Z"/><path d="M38 32H63M38 47H63M38 62H53" strokeOpacity=".65"/></>}
{type==='report'&&<><path d="M17 16V83H86" strokeOpacity=".45"/><path d="M30 67V47M49 67V32M68 67V23"/><path d="M29 33L48 22L68 15" strokeWidth="2"/></>}
{type==='student'&&<><circle cx="50" cy="32" r="14"/><path d="M22 78C23 51 77 51 78 78"/><path d="M10 10H25M10 10V25M90 10H75M90 10V25M10 90H25M10 90V75M90 90H75M90 90V75" strokeWidth="2" strokeOpacity=".55"/></>}
{type==='ai'&&<><path d="M50 13L57 38L82 45L57 52L50 77L43 52L18 45L43 38Z"/><path d="M81 67L84 78L95 81L84 84L81 95L78 84L67 81L78 78Z" strokeWidth="2.3"/></>}
</svg>;
export const QR:React.FC<{size?:number;progress?:number}>=({size=260,progress=1})=>{
const modules=[]; const n=21;
for(let y=0;y<n;y++)for(let x=0;x<n;x++){
 const inFinder=(fx:number,fy:number)=>x>=fx&&x<fx+7&&y>=fy&&y<fy+7;
 const finder=[ [0,0],[14,0],[0,14] ].find(([fx,fy])=>inFinder(fx,fy));
 let on=false;
 if(finder){const [fx,fy]=finder;const xx=x-fx,yy=y-fy;on=xx===0||xx===6||yy===0||yy===6||(xx>=2&&xx<=4&&yy>=2&&yy<=4);}
 else if(!((x<8&&y<8)||(x>12&&y<8)||(x<8&&y>12)))on=((x*17+y*29+x*y*3)%11)<5;
 if(on)modules.push(<rect key={x+'-'+y} x={x*12} y={y*12} width="10" height="10" rx="1" opacity={Math.min(1,progress*2-y/21)} />);
}
return <svg width={size} height={size} viewBox="-14 -14 280 280" fill={C.light}>{modules}</svg>;
};
export const MiniChart:React.FC<{p?:number;w?:number;h?:number}>=({p=1,w=500,h=100})=><svg width={w} height={h} viewBox="0 0 500 100" fill="none">
<path d="M0 80H500M0 50H500M0 20H500" stroke="#A29B8833" strokeDasharray="3 7" strokeWidth="1"/>
<path d="M0 78 C45 78 60 30 108 46 S174 88 216 49 S280 62 322 30 S387 67 427 26 S470 40 500 10" stroke={C.gold} strokeWidth="3.5" pathLength={1} strokeDasharray="1" strokeDashoffset={1-p}/>
</svg>;
export const useScene=()=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return {f,fps};};
