import React from 'react';
import {C,p,lerp,Line,visible} from './shared';
// A single gold registration point leaves the record and becomes the assistant cursor.
export const IdentityAxis=({t}:{t:number})=>{
 const up=p(t,14.68,15.48),result=p(t,17.02,17.55),back=p(t,18.18,19.65),fold=p(t,20.73,21.60);
 const x=lerp(lerp(329,160,up),540,back),y=lerp(lerp(1064,699,up)+388*result,1072,back)-342*fold;
 return <g opacity={visible(t,14.62,21.66,.25)}>
  <Line d="M329 1064V757Q329 699 270 699H160" color="#766544" width={2} progress={up*(1-result)*(1-back)}/>
  <circle cx={x} cy={y} r={6+2*result} fill={C.gold}/>
  <circle cx={x} cy={y} r={12+4*result} fill="none" stroke={C.gold} strokeWidth={1} opacity={.5*(1-back)}/>
 </g>;
};
