import React from 'react';
import {Easing,interpolate} from 'remotion';
import {C,T,p,lerp} from './shared';
import lesson from './lesson-path.json';
export const Classroom=({t}:{t:number})=>{
 const flight=interpolate(t,[1.15,3.0],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.56,0,.42,1)});
 const z=Math.exp(lerp(0,Math.log(46),flight));
 const cx=lerp(540,450,flight),cy=lerp(960,790,flight);
 const exit=1-p(t,2.90,3.12); const surface=1-p(t,2.15,2.86);
 return <g opacity={exit} transform={`translate(540 960) scale(${z}) translate(${-cx} ${-cy})`}>
  <rect width="1080" height="1920" fill={C.paper} opacity={surface}/>
  <T x={916} y={267} size={38} anchor="start" weight={500}>شغل السنتر</T>
  <path d="M164 275H250" stroke={C.ink} strokeWidth="2"/>
  <T x={540} y={440} size={62} weight={500}>بيبدأ مع</T>
  <rect x="100" y="515" width="880" height="460" rx="4" fill="#E8E2D7" opacity={surface}/>
  <rect x="108" y="523" width="864" height="444" fill={C.paper} opacity={surface} stroke="#C5BFB3" strokeWidth="2"/>
  <path d={lesson.d} transform="translate(101 867) scale(.313)" fill={C.ink}/>
  <rect x="92" y="975" width="896" height="13" fill={C.ink}/>
  <rect x="736" y="957" width="86" height="12" rx="3" fill={C.gold}/>
  <T x={540} y={1158} size={106} weight={400}>؟</T>
  <g fill="none" stroke={C.ink} strokeWidth="3">
   <path d="M112 1260H412V1302H112Z M142 1302V1448 M382 1302V1428"/>
   <path d="M658 1260H958V1302H658Z M688 1302V1428 M928 1302V1448"/>
   <path d="M15 1530H455V1583H15 M61 1583V1738 M410 1583V1738"/>
   <path d="M625 1530H1065V1583H625 M670 1583V1738 M1020 1583V1738"/>
  </g>
  <path d="M425 1920L486 1020 M655 1920L594 1020" stroke="#D5CEC0" strokeWidth="2"/>
 </g>;
};
