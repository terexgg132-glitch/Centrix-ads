#!/usr/bin/env bash
set -euo pipefail
mkdir -p work/audio public/assets output/audio
python3 scripts/synthesize_audio.py
ffmpeg -y -hide_banner -i work/audio/pre_master.wav \
  -af loudnorm=I=-14.5:TP=-1.3:LRA=11:print_format=json \
  -ar 48000 -ac 2 -c:a pcm_s24le output/audio/Centrix_Final_Mix.wav 2> work/audio/mastering.log
cp output/audio/Centrix_Final_Mix.wav public/assets/
cp assets/centrix_voice_original.mp3 output/audio/Centrix_Voice_Original.mp3
