import React,{useMemo} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useVideoConfig} from 'remotion';
import * as THREE from 'three';
import {p,lerp} from './primitives';

function tileShape(w:number,h:number,r=.16){
 const x=-w/2,y=-h/2;const s=new THREE.Shape();
 s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;
}
function face(type:'student'|'receipt'|'report'|'attendance'){
 const canvas=document.createElement('canvas');canvas.width=768;canvas.height=1024;
 const x=canvas.getContext('2d')!;x.fillStyle=type==='student'?'#F0E7D3':'#E9E2D2';x.fillRect(0,0,768,1024);
 x.fillStyle='#1D2025';x.fillRect(0,0,768,118);
 x.fillStyle='#D5AC4D';x.fillRect(48,40,75,8);x.fillRect(48,61,45,8);
 x.fillStyle='#5B5C58';x.fillRect(501,50,209,10);x.fillRect(566,75,145,7);
 if(type==='student'){
  // Private, nonfunctional illustration: no student identity is encoded.
  x.fillStyle='#202229';const unit=17,ox=207,oy=319;
  for(let r=0;r<21;r++)for(let c=0;c<21;c++){
   const finder=[[0,0],[14,0],[0,14]].find(([a,b])=>c>=a&&c<a+7&&r>=b&&r<b+7);
   let on=false;
   if(finder){const xx=c-finder[0],yy=r-finder[1];on=xx===0||xx===6||yy===0||yy===6||(xx>=2&&xx<=4&&yy>=2&&yy<=4);}
   else if(!((c<8&&r<8)||(c>12&&r<8)||(c<8&&r>12)))on=(c*19+r*13+c*r)%11<5;
   if(on)x.fillRect(ox+c*unit,oy+r*unit,14,14);
  }
  x.fillStyle='#8B856F';x.fillRect(196,762,376,13);x.fillRect(269,805,233,8);
  x.strokeStyle='#AD9E7B';x.lineWidth=2;x.strokeRect(47,159,674,764);
 }else if(type==='receipt'){
  x.strokeStyle='#AF9B65';x.lineWidth=3;x.beginPath();x.arc(384,257,65,0,Math.PI*2);x.stroke();
  x.fillStyle='#B98B32';x.fillRect(360,231,48,8);x.fillRect(360,253,33,8);x.fillRect(360,275,48,8);
  for(let i=0;i<6;i++){x.fillStyle=i%3===2?'#B1A68F':'#A8A18F';x.fillRect(79,410+i*66,Math.min(450,300+i%3*60),10);x.fillRect(599,410+i*66,90,10);}
  x.fillStyle='#D7AA43';x.fillRect(79,844,611,4);
 }else if(type==='report'){
  x.strokeStyle='#B5AA8F';x.lineWidth=2;
  for(let r=0;r<4;r++){x.beginPath();x.moveTo(66,430+r*98);x.lineTo(706,430+r*98);x.stroke();}
  x.strokeStyle='#BF9239';x.lineWidth=8;x.beginPath();x.moveTo(76,713);x.bezierCurveTo(180,731,142,574,258,613);x.bezierCurveTo(366,689,402,382,497,441);x.bezierCurveTo(576,509,595,399,688,339);x.stroke();
 }else{
  for(let r=0;r<6;r++){x.strokeStyle='#B5AA8F';x.lineWidth=2;x.strokeRect(80,205+r*112,55,55);x.strokeStyle='#A58439';x.lineWidth=5;x.beginPath();x.moveTo(90,231+r*112);x.lineTo(105,245+r*112);x.lineTo(127,214+r*112);x.stroke();x.fillStyle='#ACA38E';x.fillRect(176,221+r*112,490,9);}
 }
 const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;return tex;
}
function studioEnvironment(){
 const sides=Array.from({length:6},(_,i)=>{
  const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d')!;
  const bg=g.createLinearGradient(0,0,0,256);bg.addColorStop(0,i===2?'#DDD4B8':'#171819');bg.addColorStop(.48,'#49483E');bg.addColorStop(1,'#101113');g.fillStyle=bg;g.fillRect(0,0,256,256);
  g.fillStyle=i%2?'#D6CBA3':'#FFFBEA';g.fillRect(i%2?120:26,15,i%2?22:57,222);
  g.fillStyle='#807967';g.fillRect(210,23,15,208);return c;
 });
 const env=new THREE.CubeTexture(sides);env.colorSpace=THREE.SRGBColorSpace;env.needsUpdate=true;return env;
}
const Gold:React.FC<{env:THREE.CubeTexture;rough?:number;dark?:boolean}>=({env,rough=.24,dark=false})=><meshStandardMaterial color={dark?'#A47E33':'#D8AC42'} metalness={.93} roughness={rough} envMap={env} envMapIntensity={1.30}/>;
const Paper:React.FC<{env:THREE.CubeTexture;type:'student'|'receipt'|'report'|'attendance';w?:number;h?:number}>=({env,type,w=2.18,h=2.94})=>{
 const shape=useMemo(()=>tileShape(w,h,.11),[w,h]);const texture=useMemo(()=>face(type),[type]);
 return <group>
  <mesh position={[0,0,-.07]}><extrudeGeometry args={[shape,{depth:.09,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:.025,bevelThickness:.025}]}/><meshStandardMaterial color="#F5ECD7" metalness={.04} roughness={.58} envMap={env} envMapIntensity={.15}/></mesh>
  <mesh position={[0,0,.058]}><planeGeometry args={[w-.016,h-.016]}/><meshBasicMaterial map={texture}/></mesh>
 </group>;
};
const Tick:React.FC<{env:THREE.CubeTexture}>=({env})=>{
 const shape=useMemo(()=>{const s=new THREE.Shape();s.moveTo(-1.03,.08);s.lineTo(-.48,-.48);s.lineTo(.91,1.04);s.lineTo(1.17,.80);s.lineTo(-.45,-.98);s.lineTo(-1.32,-.10);s.closePath();return s;},[]);
 return <group>
 <mesh position={[0,0,-.12]}><extrudeGeometry args={[shape,{depth:.19,bevelEnabled:true,bevelSegments:3,bevelSize:.047,bevelThickness:.047}]}/><Gold env={env} rough={.21}/></mesh>
 <mesh position={[0,-.10,-.22]} rotation={[0,0,-.04]}><torusGeometry args={[1.53,.036,12,96]}/><Gold env={env} rough={.31}/></mesh>
 </group>;
};
const Bars:React.FC<{env:THREE.CubeTexture;t:number}>=({env,t})=><group>
{[.84,1.36,2.0].map((h,i)=>{
 const growth=p(t,7.742+i*.055,.31);
 return <mesh key={i} position={[-.80+i*.78,-.80+h*growth/2,0]} scale={[1,Math.max(.005,growth),1]}>
 <boxGeometry args={[.46,h,.42]}/><Gold env={env} rough={.24}/>
 </mesh>;
})}
<mesh position={[0,-.97,-.10]}><boxGeometry args={[2.60,.075,.69]}/><Gold env={env} dark rough={.33}/></mesh>
</group>;
const Cable:React.FC<{points:THREE.Vector3[];env:THREE.CubeTexture;t:number;progress?:number;radius?:number}>=({points,env,t,progress=1,radius=.018})=>{
 const curve=useMemo(()=>new THREE.CatmullRomCurve3(points),[points]);
 const part=useMemo(()=>{
  const vv=Array.from({length:96},(_,i)=>curve.getPoint(i/95*Math.max(.01,progress)));
  return new THREE.CatmullRomCurve3(vv);
 },[curve,progress]);
 const spot=curve.getPoint((t*.14)%Math.max(.01,progress));
 return <group>
 <mesh><tubeGeometry args={[part,95,radius,8,false]}/><Gold env={env} rough={.2}/></mesh>
 <mesh position={spot}><sphereGeometry args={[radius*2.1,10,10]}/><meshBasicMaterial color="#FFE7A7"/></mesh>
 </group>;
};
export type WorldMode='hook'|'chaos'|'features'|'network';
export const World:React.FC<{t:number;mode:WorldMode}>=({t,mode})=>{
 const {width,height}=useVideoConfig();const env=useMemo(studioEnvironment,[]);
 const space=mode==='hook'?0:mode==='chaos'?p(t,2.70,.90):0;
 const pull=mode==='network'?p(t,17.90,1.6):0;
 const collect=mode==='network'?p(t,20.1,1.43):0;
 const a=1-p(t,6.766,.22),b=p(t,6.766,.22)*(1-p(t,7.742,.22)),c=p(t,7.742,.22);
 const cameraZ=mode==='hook'?lerp(8.0,8.75,p(t,0,2.70)):mode==='network'?lerp(6.55,9.6,pull):9.8;
 const studentPosition: [number,number,number]=mode==='chaos'?[lerp(0,-.45,space),lerp(-.55,-.45,space),lerp(0,.35,space)]:[0,-.55,0];
 const line=mode==='network'?[
  new THREE.Vector3(-1.35*(1-collect),.92*(1-collect)-.38,.20),
  new THREE.Vector3(.18,-.30,.8),
  new THREE.Vector3(1.34*(1-collect),.12*(1-collect)-.48,.3),
  new THREE.Vector3(.15,-1.68*(1-collect)-.26,.5),
  new THREE.Vector3(-1.27*(1-collect),-1.30*(1-collect)-.2,.1),
  new THREE.Vector3(-1.35*(1-collect),.92*(1-collect)-.38,.20)
 ]:[
  new THREE.Vector3(-2.4,-1.8,-.5),new THREE.Vector3(-1.5,-1.20,.5),
  new THREE.Vector3(.10,-1.86,.65),new THREE.Vector3(1.6,-.72,.15),
  new THREE.Vector3(1.35,.93,-.4),new THREE.Vector3(-.5,1.55,-.70),
  new THREE.Vector3(-1.40,.4,-.1)
 ];
 return <ThreeCanvas width={width} height={height} camera={{position:[0,.18,cameraZ],fov:42}} gl={{antialias:true,alpha:true}} style={{position:'absolute',inset:0}}>
 <ambientLight intensity={.55}/><directionalLight position={[2.5,4,5]} intensity={2.3} color="#FFF3D7"/><directionalLight position={[-3,.8,2]} intensity={1.7} color="#E8EBF4"/><directionalLight position={[0,-3,4]} intensity={.7} color="#DCAA42"/>
 <group rotation={[.035,-.10+.03*Math.sin(t*.7),0]}>
 {(mode==='hook'||mode==='chaos')&&<group position={studentPosition} rotation={[.15,-.18,lerp(-.03,-.15,space)]}><Paper env={env} type="student" w={2.18} h={2.80}/></group>}
 {mode==='hook'&&<mesh position={[0,lerp(.08,-1.56,p(t,.306,1.02)),.32]}><boxGeometry args={[2.18,.015,.004]}/><meshBasicMaterial color="#C79B3C"/></mesh>}
 {mode==='chaos'&&<>
 <group position={[lerp(0,.57,space),lerp(-.55,.14,space),lerp(-.15,-.62,space)]} rotation={[.18,.12,.22*space]} scale={[1,1,1]}><Paper env={env} type="attendance" w={2.35} h={3.04}/></group>
 <group position={[lerp(0,-.62,space),lerp(-.55,-1.07,space),lerp(-.28,-.82,space)]} rotation={[-.06,-.22,-.20*space]}><Paper env={env} type="receipt" w={2.17} h={2.88}/></group>
 <group position={[lerp(0,.44,space),lerp(-.55,-1.42,space),lerp(-.42,-1.25,space)]} rotation={[.22,.08,.08*space]}><Paper env={env} type="report" w={2.25} h={2.90}/></group>
 </>}
 {mode==='features'&&<>
 <group position={[lerp(0,-1.6,p(t,6.766,.24)),-.40,-p(t,6.766,.24)*2]} scale={[Math.max(.001,a),Math.max(.001,a),Math.max(.001,a)]} rotation={[.02,-.22+.07*Math.sin(t),-.10]}><Tick env={env}/></group>
 <group position={[lerp(.6,0,p(t,6.766,.22)),-.32,lerp(1.6,0,p(t,6.766,.22))]} scale={[Math.max(.001,b),Math.max(.001,b),Math.max(.001,b)]} rotation={[.08,.19,lerp(.14,-.08,p(t,6.766,.5))]}><Paper env={env} type="receipt" w={2.12} h={3.09}/></group>
 <group position={[0,-.33,lerp(-1.5,0,c)]} scale={[Math.max(.001,c),Math.max(.001,c),Math.max(.001,c)]} rotation={[.12,-.26,.02]}><Bars env={env} t={t}/></group>
 <mesh position={[0,-1.48,-.63]} rotation={[1.06,0,0]} scale={[1,1,1]}><torusGeometry args={[1.9,.021,8,96]}/><Gold env={env} rough={.36}/></mesh>
 </>}
 {mode==='network'&&<>
 <group position={[0,-.40,.44]} scale={[.61,.61,.61]} rotation={[.05,.02,-.05]}><Paper env={env} type="student" w={2.0} h={2.6}/></group>
 <group position={[-1.35*(1-collect),.66*(1-collect)-.45,-.30]} scale={[.37*(1-collect)+.002,.37*(1-collect)+.002,.37*(1-collect)+.002]} rotation={[.08,-.15,.13]}><Tick env={env}/></group>
 <group position={[1.30*(1-collect),.09*(1-collect)-.55,-.22]} scale={[.34*(1-collect)+.002,.34*(1-collect)+.002,.34*(1-collect)+.002]} rotation={[.15,.22,-.13]}><Paper env={env} type="receipt"/></group>
 <group position={[.84*(1-collect),-1.71*(1-collect)-.28,-.2]} scale={[.37*(1-collect)+.002,.37*(1-collect)+.002,.37*(1-collect)+.002]} rotation={[.05,-.2,.05]}><Bars env={env} t={8}/></group>
 <group position={[-1.22*(1-collect),-1.52*(1-collect)-.24,-.2]} scale={[.34*(1-collect)+.002,.34*(1-collect)+.002,.34*(1-collect)+.002]} rotation={[.12,.15,-.10]}>
 <mesh><torusGeometry args={[.76,.044,12,64]}/><Gold env={env}/></mesh><mesh rotation={[0,0,Math.PI/4]}><boxGeometry args={[.55,.55,.14]}/><Gold env={env} rough={.20}/></mesh>
 </group>
 </>}
 <Cable points={line} env={env} t={t} progress={mode==='network'?1:p(t,.03,1.85)} radius={mode==='network'?.022:.016}/>
 </group>
 </ThreeCanvas>;
};
