import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import "./style.css";
const fontFaces = [
  ["Regular", 400],
  ["Medium", 500],
  ["SemiBold", 600],
  ["Bold", 700],
]
  .map(
    ([name, weight]) =>
      `@font-face{font-family:Plex;src:url('${staticFile("fonts/IBMPlexSansArabic-" + name + ".ttf")}') format('truetype');font-weight:${weight};font-display:block}`,
  )
  .join("");
export const C = {
  ink: "#050607",
  gold: "#E8BA55",
  pale: "#FFE9AE",
  white: "#F7F5F0",
  muted: "#8C9198",
  green: "#B4D4BC",
};
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const p = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });
export const fade = (f: number, start = 0, end = 22) => p(f, start, end);
export const Icon = ({
  name,
  size = 52,
  color = C.gold,
}: {
  name: string;
  size?: number;
  color?: string;
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    stroke={color}
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {name === "student" ? (
      <>
        <circle cx="32" cy="21" r="10" />
        <path d="M13 54v-5c0-10 8-17 19-17s19 7 19 17v5" />
      </>
    ) : name === "attendance" ? (
      <>
        <rect x="10" y="14" width="44" height="42" rx="6" />
        <path d="M21 8v13M43 8v13M10 27h44M22 41l7 7 14-15" />
      </>
    ) : name === "money" ? (
      <>
        <rect x="6" y="17" width="52" height="33" rx="6" />
        <circle cx="32" cy="33.5" r="9" />
        <path d="M14 33h2M48 33h2" />
      </>
    ) : name === "report" ? (
      <>
        <path d="M16 7h23l10 11v39H16zM39 7v12h10M24 44V34M32 44V27M40 44V22" />
      </>
    ) : name === "check" ? (
      <path d="M12 33l13 13 28-29" />
    ) : name === "arrow" ? (
      <path d="M51 32H13m14-14L13 32l14 14" />
    ) : (
      <>
        <path d="M32 7l7 17 18 8-18 7-7 18-7-18-18-7 18-8z" />
      </>
    )}
  </svg>
);
export const Logo = ({
  size = 250,
  style = {},
}: {
  size?: number;
  style?: React.CSSProperties;
}) => (
  <Img
    src={staticFile("centrix-logo-original.png")}
    style={{ width: size, height: size, objectFit: "contain", ...style }}
  />
);
export const Micro = ({
  children,
  style = {},
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
}) => (
  <div
    style={{
      fontFamily: "Arial,sans-serif",
      fontSize: 20,
      letterSpacing: 5,
      color: C.gold,
      ...style,
    }}
  >
    {children}
  </div>
);
export const Backdrop = ({
  light = false,
  grid = false,
}: {
  light?: boolean;
  grid?: boolean;
}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: light ? "#EDE8DC" : C.ink,
        overflow: "hidden",
        color: light ? C.ink : C.white,
        fontFamily: "Plex",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: -200,
          background: `radial-gradient(ellipse at ${54 + Math.sin(f / 170) * 12}% 50%, ${light ? "#fff8e7" : "#4b37141c"} 0%, transparent 55%)`,
        }}
      />
      {grid && (
        <div
          style={{
            position: "absolute",
            left: -500,
            right: -500,
            top: 570,
            height: 1100,
            transform: "perspective(650px) rotateX(63deg)",
            transformOrigin: "center top",
            backgroundImage:
              "linear-gradient(#b69b5420 1px,transparent 1px),linear-gradient(90deg,#b69b5420 1px,transparent 1px)",
            backgroundSize: "110px 110px",
            maskImage: "radial-gradient(ellipse,black,transparent 67%)",
          }}
        />
      )}
      <div className="grain" />
      {Array.from({ length: 28 }, (_, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: (i * 337 + 73) % 1920,
            top: (i * 137 + f * (0.16 + (i % 3) * 0.09)) % 1000,
            width: i % 4 === 0 ? 3 : 2,
            height: i % 4 === 0 ? 3 : 2,
            borderRadius: "50%",
            background: C.gold,
            opacity: light ? 0.05 : 0.07 + (i % 4) * 0.025,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};
export const SceneFrame = ({
  children,
  light = false,
  grid = false,
}: {
  children: React.ReactNode;
  light?: boolean;
  grid?: boolean;
}) => (
  <AbsoluteFill
    style={{
      fontFamily: "Plex",
      color: light ? C.ink : C.white,
      overflow: "hidden",
    }}
  >
    <style>{fontFaces}</style>
    <Backdrop light={light} grid={grid} />
    {children}
  </AbsoluteFill>
);
export const Header = ({
  number,
  label,
}: {
  number: string;
  label: string;
}) => (
  <div
    style={{
      position: "absolute",
      left: 100,
      right: 100,
      top: 62,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    }}
  >
    <Micro>
      CENTRIX{" "}
      <span style={{ color: "#777", letterSpacing: 3 }}> / AI AGENT</span>
    </Micro>
    <Micro style={{ color: "#8d8980", fontSize: 17, letterSpacing: 3 }}>
      {number} — {label}
    </Micro>
  </div>
);
export const Rail = ({
  progress = 0,
  y = 880,
}: {
  progress?: number;
  y?: number;
}) => (
  <svg
    style={{ position: "absolute", top: y, left: 160 }}
    width="1600"
    height="100"
    viewBox="0 0 1600 100"
  >
    <path d="M0 50H1600" stroke="#e8ba5525" />
    <path
      d="M0 50H1600"
      stroke={C.gold}
      strokeWidth="2"
      strokeDasharray="1600"
      strokeDashoffset={1600 * (1 - progress)}
    />
    {[0, 1, 2, 3].map((i) => (
      <g key={i} transform={`translate(${200 + i * 400},50)`}>
        <circle
          r="7"
          fill={progress > (200 + i * 400) / 1600 ? C.gold : "#26231d"}
        />
      </g>
    ))}
  </svg>
);
export const TaskLabel = () => (
  <div
    style={{
      position: "absolute",
      bottom: 46,
      right: 100,
      color: "#77766f",
      fontSize: 20,
    }}
  >
    تصوّر توضيحي • بيانات تجريبية
  </div>
);
export const Caption = ({
  children,
  style = {},
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
}) => (
  <div
    dir="rtl"
    style={{ fontSize: 38, color: C.muted, lineHeight: 1.7, ...style }}
  >
    {children}
  </div>
);
export const Check = ({ size = 72 }: { size?: number }) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: "50%",
      border: "1px solid #e8ba5566",
      background: "#e8ba5514",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    <Icon name="check" size={size * 0.58} />
  </div>
);
export const Beam = ({
  f,
  duration = 36,
}: {
  f: number;
  duration?: number;
}) => (
  <svg
    width="1920"
    height="1080"
    style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
  >
    <defs>
      <linearGradient id="beam">
        <stop stopColor="#e8ba55" stopOpacity="0" />
        <stop offset=".75" stopColor="#e8ba55" />
        <stop offset="1" stopColor="#fff7dc" />
      </linearGradient>
    </defs>
    <path
      d="M-300 730C330 730 350 540 900 540S1390 350 2220 350"
      stroke="url(#beam)"
      strokeWidth={
        3 + 10 * Math.sin(Math.PI * Math.min(1, Math.max(0, f / duration)))
      }
      fill="none"
      strokeDasharray="700 2600"
      strokeDashoffset={700 - (f / duration) * 3600}
      opacity={Math.max(0, Math.sin((Math.PI * f) / duration))}
    />
  </svg>
);
