import React from "react";
import { useCurrentFrame } from "remotion";
import { SceneFrame, C, Micro, p, Logo } from "../design";
export const Brand = () => {
  const f = useCurrentFrame();
  return (
    <SceneFrame>
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse at 50% 42%,#674b1814,transparent 60%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 48,
          left: 628,
          opacity: p(f, 0, 35),
          scale: 0.93 + 0.07 * p(f, 0, 70),
        }}
      >
        <Logo size={665} style={{ mixBlendMode: "screen" }} />
      </div>
      <div
        dir="rtl"
        style={{
          position: "absolute",
          top: 715,
          left: 150,
          right: 150,
          textAlign: "center",
          fontSize: 75,
          fontWeight: 500,
          color: C.white,
          opacity: p(f, 23, 50),
        }}
      >
        سنتركس… سستم السنتر.
      </div>
      <div
        style={{
          position: "absolute",
          top: 862,
          left: 0,
          right: 0,
          textAlign: "center",
          opacity: p(f, 60, 90),
        }}
      >
        <div
          dir="rtl"
          style={{ fontSize: 31, color: C.gold, marginBottom: 24 }}
        >
          شوفه بينفّذ. جرّبه بنفسك.
        </div>
        <div
          style={{
            fontFamily: "Arial",
            fontSize: 32,
            letterSpacing: 4,
            color: "#d3d0c8",
          }}
        >
          centrix.company
        </div>
      </div>
    </SceneFrame>
  );
};
