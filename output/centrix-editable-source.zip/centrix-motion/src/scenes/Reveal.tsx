import { AbsoluteFill } from "remotion";
import { C, ease, mix, pop, useMotion, SceneProps } from "../design";
import { BrandMark, Wordmark, Words } from "../components";

export const Reveal: React.FC<SceneProps> = ({ standalone = false }) => {
  const f = useMotion(); // Sequence begins at 4.5s; shared circle matches the problem.
  const collect = pop(f, 30, 35);
  const exit = ease(f, 112, 147);
  const ring = ease(f, 14, 51);
  return (
    <AbsoluteFill style={{ background: standalone ? C.blue : undefined }}>
      <svg width="1080" height="1920" style={{ position: "absolute" }}>
        <circle
          cx="540"
          cy="1040"
          r={mix(0, 252, ring)}
          fill="none"
          stroke={C.cyan}
          strokeWidth={mix(48, 5, ease(f, 45, 67))}
          opacity={1 - exit}
        />
      </svg>
      <div
        style={{
          position: "absolute",
          left: 540 - 187,
          top: 1040 - 187,
          width: 374,
          height: 374,
          borderRadius: "50%",
          background: C.cyan,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          scale: collect * (1 - exit * 0.88),
          rotate: `${mix(-15, 0, collect)}deg`,
          opacity: 1 - ease(f, 126, 144),
        }}
      >
        <BrandMark
          size={268}
          color={C.blue}
          progress={ease(f, 42, 65)}
          id="reveal"
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: 90,
          top: 493,
          width: 900,
          translate: `0 ${-110 * exit}px`,
          opacity: 1 - ease(f, 117, 138),
        }}
      >
        <Words text="خليها أبسط" start={47} size={118} />
        <Words text="مع" start={62} size={68} color={C.cyan} />
      </div>
      <div
        style={{
          position: "absolute",
          left: 90,
          top: 1325,
          width: 900,
          textAlign: "center",
          scale: pop(f, 66),
          opacity: 1 - ease(f, 115, 137),
          translate: `0 ${110 * exit}px`,
        }}
      >
        <Wordmark size={138} />
      </div>
    </AbsoluteFill>
  );
};
