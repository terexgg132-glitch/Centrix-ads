import React from "react";
import { useCurrentFrame } from "remotion";
import { SceneFrame, C, Micro, p, Header, Icon } from "../design";
export const Reply = () => {
  const f = useCurrentFrame();
  const exit = p(f, 125, 150);
  return (
    <SceneFrame>
      <Header number="01" label="THE ANSWER" />
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 1 - exit,
          translate: `${-exit * 180}px 0`,
        }}
      >
        <div
          dir="rtl"
          style={{
            position: "absolute",
            right: 150,
            top: 260,
            width: 740,
            fontSize: 98,
            lineHeight: 1.5,
            fontWeight: 500,
            opacity: p(f, 0, 24),
          }}
        >
          فيه AI يقولّك
          <br />
          <span style={{ color: C.gold }}>تعمل إيه.</span>
        </div>
        <div
          style={{
            position: "absolute",
            left: 150,
            top: 260,
            width: 660,
            height: 500,
            border: "1px solid #62656a",
            borderRadius: 32,
            background: "linear-gradient(130deg,#202226,#101216)",
            padding: 48,
            opacity: p(f, 12, 36),
            transform: `perspective(1600px) rotateY(8deg) translateY(${(1 - p(f, 12, 36)) * 60}px)`,
          }}
        >
          <Micro
            style={{
              fontSize: 18,
              color: "#90959a",
              letterSpacing: 3,
              marginBottom: 32,
            }}
          >
            CHAT ASSISTANT
          </Micro>
          <div
            dir="rtl"
            style={{
              fontSize: 37,
              color: "#ddd",
              borderBottom: "1px solid #ffffff14",
              paddingBottom: 25,
            }}
          >
            إزاي أسجّل حضور طالب؟
          </div>
          <div
            dir="rtl"
            style={{
              fontSize: 31,
              color: "#8b9098",
              lineHeight: 1.9,
              marginTop: 25,
              opacity: p(f, 30, 60),
            }}
          >
            افتح قائمة الطلاب.
            <br />
            ابحث عن الطالب.
            <br />
            اختار تسجيل الحضور…
          </div>
          <div
            style={{
              position: "absolute",
              bottom: 36,
              right: 46,
              left: 46,
              height: 1,
              background: "#ffffff1c",
            }}
          />
        </div>
        <div
          dir="rtl"
          style={{
            position: "absolute",
            top: 830,
            left: 150,
            fontSize: 28,
            color: "#82858b",
            opacity: p(f, 68, 90),
          }}
        >
          إجابة وصلت. المهمة لسه مستنيّاك.
        </div>
      </div>
    </SceneFrame>
  );
};
