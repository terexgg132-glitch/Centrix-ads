# 8-Second Quality Gate — Centrix «ورا الحصة»

## Render the proof FIRST

Build a real animated sample from full timeline **05:50–13:50** (8 seconds): it must include the 3 operation morphs, the dramatic world shift at the word «Centrix», and the first two dashboard feature transformations, using the original audio segment and actual music/SFX.

## Approval standard

- The visual idea is immediately distinctive, not generic SaaS cards.
- The three original sound cues (scan/payment/follow-up) create the beginning of the music groove.
- The 08.88 visual change feels sophisticated without an obnoxious flash.
- Animated Arabic words are correctly joined and fully readable.
- Same object causally transforms, no random slide-to-slide transition.
- Narrative sound always wins against musical bed; no distortion.

If this 8-second sequence is not special, redesign rather than continue producing a generic complete video.

## Important brand/product guardrails

Use actual supplied black/gold logo. No redesign or new vector approximation. Core features may be shown based on official site: students/groups, attendance, collection/payments, accounts, reports and AI Agent for supported operations. Avoid claiming automatic WhatsApp parent notifications without capability verification. Avoid fake growth percentages and real-looking student names/counts. Use generic/anonymized examples.
