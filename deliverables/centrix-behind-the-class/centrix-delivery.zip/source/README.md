# Centrix — Behind the Class

Editable React / TypeScript / Remotion film. 1080 × 1920, 30 fps, 810 frames, 27 seconds.

## Run and edit

Requires Node 22+, FFmpeg, Python 3.10+, and Chromium (or Chrome).

```sh
npm ci
npm run check
npm run studio
```

Open `http://localhost:3000/Centrix`. The main composition is `Centrix`; `MotionProof` is an 8-second window beginning at 5.5 seconds. The Scenes folder provides the same continuous world at scene-specific offsets. Animations are driven entirely by timeline frame values, never CSS timers.

`src/Classroom.tsx` contains the classroom and optical flight through the shaped Arabic word. `src/Student.tsx` holds the same QR modules and their tick, receipt-rule, and follow-up destinations. `src/Dashboard.tsx`, `src/Intelligence.tsx`, `src/IdentityAxis.tsx`, and `src/Outro.tsx` carry the connected world into the authentic supplied logo. `src/shared.tsx` controls type, palette, and easing. `src/Root.tsx` controls the global timeline and the three-frame freeze. All components use authored SVG/React layers; no generated scene images are used.

Cairo is bundled locally under its SIL Open Font License. The hero word is shaped with HarfBuzz from the same Cairo file and stored as actual outlines in `src/lesson-path.json`. Normal UI and kinetic titles remain native joined RTL text in Chromium. To regenerate the outline:

```sh
python -m pip install -r requirements.txt
python scripts/generate_lesson_path.py
```

## Rebuild audio and video

The existing mixed WAV is included, so rendering does not require Python. To regenerate the original procedural sound design and stems:

```sh
python -m pip install -r requirements.txt
CENTRIX_OUTPUT=.. python scripts/compose_audio.py
```

To render into the package's parent directory:

```sh
CENTRIX_OUTPUT=.. CHROME_PATH=/usr/bin/chromium node scripts/render.mjs proof
CENTRIX_OUTPUT=.. CHROME_PATH=/usr/bin/chromium node scripts/render.mjs final
```

On another platform set `CHROME_PATH` to the local Chrome executable. Output is rendered as H.264 and then converted to limited-range BT.709 `yuv420p` with FFmpeg; AAC audio is encoded directly from the lossless mixed WAV during this delivery conversion, with exact 27-second (or 8-second proof) duration. Set `CENTRIX_OUTPUT` to any preferred folder. Omit it to use this project's `renders/` folder.

## Audio

The original MP3 is included byte-for-byte. The voice stem is a direct 48 kHz stereo PCM resample, 23.712 seconds long, with no trimming, rewriting, time stretching, pitch changes, or compression. The 27-second mix pads the voice with silence. Music and SFX stems are 27-second stereo PCM. Stem sums receive the documented common static master gain in `audio-report.json`; the mixed WAV includes that gain. Voice-driven smoothing ducks the original score by up to roughly 8 dB. Music/SFX stop for the pre-activation contrast; the narration continues unchanged.

The original score is deterministic synthesis, not library audio: a 108 BPM paper/click/scanner motif, D-minor bass and airy tones, an AI drum reduction, and a D5–A4–F5 three-note closing signature. All generated sound assets can be regenerated from `scripts/compose_audio.py`; no third-party sound library is used.

## Asset and product integrity

The original logo SVG is displayed directly by Remotion's image component. It contains an embedded original RGB image; no part of that artwork was redrawn. Its original black/gold artwork, corner brackets, English wordmark, and internal lettering remain intact. The external tagline is «سستم السنتر» and the website is `centrix.company`.

The UI is illustrative and labeled in Arabic. The morph is a narrative link among distinct student operations, not a claim that one scan automatically performs all operations. Product evidence is documented in `FEATURE-VERIFICATION.md`. No student names, performance metrics, autonomous outbound communications, or testimonials are depicted.

## Review limits

Rendered stills and an encoded 8-second filmstrip were visually inspected; the receipt layout and glyph-camera target were corrected before the full master render. FFmpeg verifies frame count, audio format, complete decoding, loudness and true peak. The supplied voice is checked numerically against the generated stems. This execution environment has no supported audio audition input or playback device, so no listening review is claimed. An auditory check on headphones/speakers remains advisable before publishing. The given voice cue map was retained after waveform inspection; phoneme alignment was not independently auditioned.

The project creation CLI could not clone its template through the session proxy. The working project was scaffolded directly with the same React/Remotion dependencies and a lockfile. System Chromium was used, so no browser download is required.
