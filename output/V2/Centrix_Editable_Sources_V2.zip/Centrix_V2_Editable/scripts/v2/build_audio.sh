#!/usr/bin/env bash
set -euo pipefail
mkdir -p work/v2/audio output/V2/audio public/assets/v2
python3 scripts/v2/compose_audio.py
ffmpeg -y -hide_banner -i work/v2/audio/pre_master.wav \
 -af loudnorm=I=-14:TP=-1.5:LRA=9:print_format=json \
 -c:a pcm_s24le -ar 48000 -ac 2 output/V2/audio/Centrix_Final_Mix.wav \
 2> work/v2/audio/mastering.log
cp output/V2/audio/Centrix_Final_Mix.wav public/assets/v2/
cp assets/centrix_voice_original.mp3 output/V2/audio/Centrix_Voice_Original.mp3
