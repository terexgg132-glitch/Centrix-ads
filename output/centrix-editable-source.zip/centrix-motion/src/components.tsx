import React from "react";
import { staticFile } from "remotion";
import { C, ease, mix, pop, useMotion } from "./design";

/** Exact supplied emblem, isolated in an SVG viewport. No substitute mark. */
export const BrandMark: React.FC<{
  size?: number;
  color?: string;
  progress?: number;
  id?: string;
}> = ({ size = 260, color = C.blue, progress = 1, id = "centrix" }) => (
  <svg
    width={size}
    height={size}
    viewBox="458 330 325 340"
    style={{ overflow: "visible" }}
  >
    <defs>
      <filter id={`${id}-key`} colorInterpolationFilters="sRGB">
        <feColorMatrix
          type="matrix"
          values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  2 0 -2 0 -0.12"
        />
        <feComponentTransfer>
          <feFuncA type="linear" slope="10" intercept="-6" />
        </feComponentTransfer>
      </filter>
      <clipPath id={`${id}-isolate`}>
        <ellipse cx="627" cy="501" rx="174" ry="165" />
      </clipPath>
      <mask
        id={`${id}-mask`}
        maskUnits="userSpaceOnUse"
        x="458"
        y="330"
        width="325"
        height="340"
      >
        <image
          href={staticFile("brand/centrix-original.png")}
          x="0"
          y="0"
          width="1254"
          height="1254"
          filter={`url(#${id}-key)`}
          clipPath={`url(#${id}-isolate)`}
        />
      </mask>
      <clipPath id={`${id}-reveal`}>
        <rect x="458" y={mix(674, 328, progress)} width="325" height="346" />
      </clipPath>
    </defs>
    <rect
      x="458"
      y="330"
      width="325"
      height="340"
      fill={color}
      mask={`url(#${id}-mask)`}
      clipPath={`url(#${id}-reveal)`}
    />
  </svg>
);

export const Words: React.FC<{
  text: string;
  start?: number;
  stagger?: number;
  size?: number;
  color?: string;
  align?: "center" | "right";
  style?: React.CSSProperties;
}> = ({
  text,
  start = 0,
  stagger = 5,
  size = 110,
  color = C.white,
  align = "center",
  style,
}) => {
  const f = useMotion();
  return (
    <div
      dir="rtl"
      data-headline
      style={{
        display: "flex",
        flexDirection: "row",
        justifyContent: align === "center" ? "center" : "flex-start",
        alignItems: "baseline",
        gap: size * 0.22,
        fontFamily: "Cairo",
        fontSize: size,
        fontWeight: 900,
        lineHeight: 1.5,
        color,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {text.split(" ").map((word, i) => {
        const p = pop(f, start + i * stagger, 26);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              padding: "12px 3px 20px",
              margin: "-12px -3px -20px",
              overflow: "hidden",
            }}
          >
            <span
              data-word
              style={{
                display: "inline-block",
                opacity: ease(f, start + i * stagger, start + i * stagger + 6),
                translate: `0 ${mix(100, 0, p)}px`,
                rotate: `${mix(-5, 0, p)}deg`,
                scale: mix(0.86, 1, p),
              }}
              dir={/[A-Za-z]/.test(word) ? "ltr" : "rtl"}
            >
              {word}
            </span>
          </span>
        );
      })}
    </div>
  );
};

export const Check: React.FC<{
  size?: number;
  color?: string;
  progress?: number;
  stroke?: number;
}> = ({ size = 64, color = C.blue, progress = 1, stroke = 8 }) => (
  <svg width={size} height={size} viewBox="0 0 80 80">
    <path
      d="M18 41 L33 56 L63 25"
      fill="none"
      stroke={color}
      strokeWidth={stroke}
      strokeLinecap="round"
      strokeLinejoin="round"
      pathLength="1"
      strokeDasharray="1"
      strokeDashoffset={1 - progress}
    />
  </svg>
);

export const Icon: React.FC<{
  kind: "calendar" | "note" | "bell" | "students" | "book";
  size?: number;
  color?: string;
}> = ({ kind, size = 64, color = C.blue }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 80 80"
    fill="none"
    stroke={color}
    strokeWidth="5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {kind === "calendar" && (
      <>
        <rect x="14" y="20" width="52" height="46" rx="10" />
        <path d="M14 34H66 M28 14V26 M52 14V26" />
        <path d="M29 47H33 M46 47H50 M29 57H33" />
      </>
    )}
    {kind === "note" && (
      <>
        <rect x="18" y="11" width="44" height="58" rx="9" />
        <path d="M29 28H51 M29 40H51 M29 52H43" />
      </>
    )}
    {kind === "bell" && (
      <>
        <path d="M18 57C24 51 24 46 24 34A16 16 0 0 1 56 34C56 46 56 51 62 57Z" />
        <path d="M33 66A8 8 0 0 0 47 66 M37 14H43" />
      </>
    )}
    {kind === "students" && (
      <>
        <circle cx="32" cy="27" r="12" />
        <path d="M10 63V57A22 22 0 0 1 54 57V63 M54 18A12 12 0 0 1 54 41 M60 46A17 17 0 0 1 72 63" />
      </>
    )}
    {kind === "book" && (
      <>
        <path d="M40 22C30 14 17 15 10 20V61C19 56 30 57 40 65C50 57 61 56 70 61V20C60 15 50 14 40 22Z M40 22V65" />
      </>
    )}
  </svg>
);

export const Avatar: React.FC<{
  size?: number;
  variant?: number;
  blink?: boolean;
}> = ({ size = 96, variant = 0, blink = false }) => {
  const colors = [C.cyan, C.pale, "#B6EDFC"];
  return (
    <svg width={size} height={size} viewBox="0 0 120 120">
      <defs>
        <clipPath id={`av-${variant}-${size}`}>
          <circle cx="60" cy="60" r="59" />
        </clipPath>
      </defs>
      <g clipPath={`url(#av-${variant}-${size})`}>
        <circle cx="60" cy="60" r="60" fill={colors[variant % 3]} />
        <path
          d="M17 125C18 92 35 84 60 84C85 84 102 92 103 125"
          fill={variant % 2 ? C.blue : C.ink}
        />
        <ellipse cx="60" cy="58" rx="27" ry="31" fill="#FFFFFF" />
        <path
          d={
            variant % 2
              ? "M31 56C30 21 57 17 78 28C88 35 89 47 88 60L77 41L38 48Z"
              : "M31 50C30 25 47 20 60 22C82 20 91 34 88 51C79 38 71 43 67 33C58 45 43 39 31 50Z"
          }
          fill={C.ink}
        />
        <path d="M38 89C47 99 73 99 82 89" fill={C.white} />
        {blink ? (
          <path
            d="M46 60H51 M69 60H74"
            stroke={C.ink}
            strokeWidth="3"
            strokeLinecap="round"
          />
        ) : (
          <>
            <circle cx="49" cy="59" r="2.5" fill={C.ink} />
            <circle cx="71" cy="59" r="2.5" fill={C.ink} />
          </>
        )}
        <path
          d="M53 71Q60 77 67 71"
          fill="none"
          stroke={C.ink}
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
};

export const StudentCard: React.FC<{
  name: string;
  variant: number;
  checked?: number;
  compact?: boolean;
}> = ({ name, variant, checked = 0, compact = false }) => (
  <div
    style={{
      width: "100%",
      height: "100%",
      background: C.white,
      border: `3px solid ${C.pale}`,
      borderRadius: 36,
      display: "flex",
      alignItems: "center",
      padding: "25px 32px",
      boxSizing: "border-box",
      gap: 24,
      direction: "rtl",
    }}
  >
    <Avatar size={compact ? 78 : 96} variant={variant} />
    <div
      style={{ flex: 1, textAlign: "right", fontFamily: "Cairo", color: C.ink }}
    >
      <div
        style={{
          fontSize: compact ? 35 : 46,
          fontWeight: 800,
          lineHeight: 1.55,
        }}
      >
        {name}
      </div>
      <div
        style={{ fontSize: compact ? 25 : 29, fontWeight: 600, color: C.blue }}
      >
        {checked > 0.8 ? "حاضر" : "طالب"}
      </div>
    </div>
    <div
      style={{
        width: compact ? 58 : 74,
        height: compact ? 58 : 74,
        borderRadius: "50%",
        background: checked > 0 ? C.cyan : C.pale,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Check size={compact ? 45 : 60} progress={checked} />
    </div>
  </div>
);

export const Wordmark: React.FC<{ size?: number; color?: string }> = ({
  size = 120,
  color = C.white,
}) => (
  <div
    dir="ltr"
    style={{
      fontFamily: "Cairo",
      fontSize: size,
      fontWeight: 900,
      lineHeight: 1.25,
      letterSpacing: -size * 0.04,
      color,
    }}
  >
    Centrix
  </div>
);
