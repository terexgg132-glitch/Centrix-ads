import { AbsoluteFill } from "remotion";
import { C, ease, mix, pop, useMotion } from "../design";
import { Avatar, StudentCard, Words } from "../components";

export const Attendance: React.FC<{
  parentNotifications?: boolean;
  standalone?: boolean;
}> = ({ parentNotifications = true, standalone = false }) => {
  const f = useMotion();
  const morph = ease(f, 123, 158);
  const handoff = ease(f, 192, 225);
  return (
    <AbsoluteFill style={{ background: standalone ? C.pale : undefined }}>
      <div
        style={{
          position: "absolute",
          left: 85,
          top: 398,
          width: 910,
          opacity: 1 - ease(f, 190, 220),
          translate: `0 ${-90 * ease(f, 191, 220)}px`,
        }}
      >
        <Words text="سجّل الحضور..." start={22} size={102} color={C.ink} />
        <Words text="وتابع بسهولة" start={39} size={103} color={C.blue} />
      </div>
      {[0, 1, 2].map((i) => {
        const enter = pop(f, 20 + i * 9, 34);
        const reorganize = ease(f, 51, 91);
        const y = mix(1070 + (i - 1) * 64, 945 + i * 204, reorganize);
        const rot = mix((i - 1) * 13, 0, reorganize);
        const done = ease(f, 82 + i * 15, 91 + i * 15);
        const merge = i === 2 ? morph : ease(f, 132 + i * 3, 161 + i * 3);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: mix(177, 338, merge),
              top: mix(y, 1114, merge),
              width: mix(726, 404, merge),
              height: mix(174, 140, merge),
              rotate: `${rot + (1 - enter) * 22}deg`,
              translate: `${(1 - enter) * (i - 1) * 360}px ${(1 - enter) * -170}px`,
              scale: mix(0.28, 1, enter),
              opacity: 1 - merge,
            }}
          >
            <StudentCard
              name={["أحمد", "مريم", "يوسف"][i]}
              variant={i}
              checked={done}
            />
          </div>
        );
      })}
      {/* One circle changes width, corner radius, and path to become the notification. */}
      <div
        style={{
          position: "absolute",
          left: mix(174, 145, morph),
          top: mix(1368, 1075, morph) - 332 * handoff,
          width: mix(144, 790, morph),
          height: mix(144, 246, morph),
          borderRadius: mix(72, 42, morph),
          background: mix(0, 1, morph) < 0.01 ? C.cyan : C.white,
          border: `${mix(0, 3, morph)}px solid ${C.pale}`,
          boxSizing: "border-box",
          scale: pop(f, 115, 22),
          opacity: 1 - ease(f, 228, 244),
        }}
      >
        <div
          style={{
            position: "absolute",
            left: mix(33, 637, morph),
            top: mix(32, 39, morph),
            width: mix(78, 100, morph),
            height: mix(78, 100, morph),
            borderRadius: "50%",
            background: C.cyan,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg width="80" height="80" viewBox="0 0 80 80">
            <path
              d={`M${mix(18, 17, morph)} ${mix(41, 28, morph)} L${mix(33, 40, morph)} ${mix(56, 46, morph)} L${mix(63, 63, morph)} ${mix(25, 28, morph)}`}
              fill="none"
              stroke={C.blue}
              strokeWidth={mix(8, 5, morph)}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="13"
              y="20"
              width="54"
              height="41"
              rx="9"
              fill="none"
              stroke={C.blue}
              strokeWidth="5"
              opacity={morph}
            />
          </svg>
        </div>
        <div
          dir="rtl"
          style={{
            position: "absolute",
            right: 170,
            top: 35,
            left: 32,
            opacity: ease(f, 150, 171),
            fontFamily: "Cairo",
            color: C.ink,
            textAlign: "right",
          }}
        >
          <div style={{ fontWeight: 800, fontSize: 42 }}>
            {parentNotifications ? "إشعار لولي الأمر" : "الحضور اتسجّل"}
          </div>
          <div
            style={{
              fontSize: 32,
              fontWeight: 600,
              color: C.blue,
              marginTop: 5,
            }}
          >
            {parentNotifications ? "يوسف سجّل حضوره" : "يوسف حاضر"}
          </div>
          <div
            style={{
              marginTop: 22,
              height: 7,
              borderRadius: 5,
              width: "72%",
              background: C.pale,
            }}
          />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 459,
          top: 1384,
          scale: pop(f, 163, 30),
          opacity: 1 - ease(f, 211, 232),
          rotate: `${Math.sin(f * 0.035) * 3}deg`,
        }}
      >
        <Avatar size={162} variant={3} />
      </div>
      <svg width="1080" height="1920" style={{ position: "absolute" }}>
        <path
          d="M540 1310V1359"
          stroke={C.blue}
          strokeWidth="5"
          strokeLinecap="round"
          pathLength="1"
          strokeDasharray="1"
          strokeDashoffset={1 - ease(f, 160, 182)}
          opacity={1 - ease(f, 207, 232)}
        />
      </svg>
      <div
        style={{
          position: "absolute",
          left: 425,
          top: 1581,
          opacity: ease(f, 178, 192) * (1 - ease(f, 207, 230)),
          color: C.blue,
          fontFamily: "Cairo",
          fontSize: 35,
          fontWeight: 700,
          whiteSpace: "nowrap",
        }}
      >
        {parentNotifications ? "متابعة تطمّن" : "متابعة بسهولة"}
      </div>
    </AbsoluteFill>
  );
};
