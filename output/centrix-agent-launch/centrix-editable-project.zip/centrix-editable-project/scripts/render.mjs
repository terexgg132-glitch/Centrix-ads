import { spawnSync } from "node:child_process";
import { mkdirSync } from "node:fs";
const out = process.env.CENTRIX_OUTPUT || "exports";
mkdirSync(out, { recursive: true });
const args = [
  "remotion",
  "render",
  "src/index.ts",
  "CentrixLaunch",
  `${out}/centrix-launch-1080p.mp4`,
  "--codec=h264",
  "--crf=16",
  "--pixel-format=yuv420p",
  "--audio-bitrate=320k",
];
if (process.env.CHROME_PATH)
  args.push(`--browser-executable=${process.env.CHROME_PATH}`);
const r = spawnSync("npx", args, { stdio: "inherit" });
process.exit(r.status ?? 1);
