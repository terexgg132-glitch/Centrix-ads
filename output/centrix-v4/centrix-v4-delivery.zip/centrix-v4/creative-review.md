# CENTRIX V4 — The Domino Effect

**Creative idea:** one golden dot drives a machine whose components change function without losing their visual ancestry. A circle splits into people; people become a rhythm of schedule marks; the marks merge into attendance. That check becomes communication, communication unspools into a ribbon, and the ribbon turns into a chart and progress arc. The arc expands into one connected system before folding toward the Centrix emblem.

## Art direction review

Eight full-resolution representative keyframes were generated and inspected before the full-resolution render: frames **45, 179, 254, 315, 375, 481, 680 and 850**. The contact sheet is `review-frames/eight-keyframes.jpg`. Additional frame sequences were inspected around every major change, followed by a complete 900-frame draft and decoded-frame filmstrip.

The distinction from an animated presentation comes from the changing geometry, shared anchors and persistent protagonist. There are no scene fades, product screenshots, interface cards or dashboard demonstrations. The largest visual change at the end is a growing black iris, followed by a matching circular mask that reveals the exact original artwork.

| Review finding | Refinement made |
| --- | --- |
| The large system headline touched the attendance and communication symbols. | Reduced the second line width and moved the side symbols to preserve a readable gap. |
| Returning student bodies overlapped into one scalloped block. | Rebuilt the small bodies with separate arches and clean spacing. |
| Returning elements began away from the progress arc. | Their actual starting paths now come from fragments of that arc; their SVG coordinates unfold into the returning symbols. |
| The chart's grey axis disappeared at the system handoff. | It now curls into the progress track and is reeled into the perimeter. |
| The schedule merge ended with flat checkmark caps. | Matched the merge outline to the next rounded ribbon, reducing the visible handoff. |
| Connecting lines had hard gaps near the typography. | Replaced them with Bézier routes that pass around the lettering. |
| The black reveal covered the emblem-inspired fold early. | Put the iris behind the fold and reveal the authentic artwork through the same anchor. |
| Small student fragments crowded the final emblem-inspired forms. | Their contours merge into two clean diagonal ribbons. |
| Small gold status dots competed with the main protagonist. | Replaced them with black communication marks and slim gold line joints. |
| The final type could load late in a fresh renderer. | Explicitly preload the local Cairo face before acknowledging a frame. |

## Timing and sound

- **0–4 seconds:** Arabic hook, physical glyph response, elastic rails and a drawn ring.
- **4–11 seconds:** circle subdivision, student reorganization, schedule rhythm and a multi-path merge into attendance.
- **11–18 seconds:** continuously changing communication outline, looping ribbon, chart and progress arc.
- **18–25 seconds:** previous graphic vocabulary returns on one larger connected rail; “كله في سستم واحد” is threaded through the centre.
- **25–30 seconds:** the system folds into emblem-inspired geometry, the background turns black, and the unmodified uploaded logo is revealed. “Centrix... سستم السنتر” is fully visible from frame 820 through 899, a hold of approximately 2.67 seconds.

The electronic music and sound effects were composed and synthesized specifically for this timeline. The score is 120 BPM. Dry impacts, elastic pulls, brief zips and geometric alignment sounds follow the authored frame map. Three original tuned gestures at **26.9, 27.2 and 27.6 seconds** form the sonic signature. There are no voices, dialogue, borrowed music or third-party sound samples. The source includes the synthesis script, separate music and effects stems, a mastered WAV, and the frame cue list.

## Brand and Arabic

The supplied SVG is used verbatim and its file hash is recorded in `verification.json`. It contains a complete embedded raster brand artwork, including its existing lighting, border and background; these are preserved. The flat motion gold **#E8B844** was sampled from an actual light-gold pixel in the emblem. Warm off-white, bold ink, white and a small amount of grey form the rest of the palette.

The Arabic motion words are Cairo outlines generated using native HarfBuzz RTL shaping and contextual forms. The final Arabic tagline uses the explicitly preloaded local Cairo variable font and RTL layout. Both the review frames and the completed draft were inspected for connected lettering and readable composition.

## Assessment and limits

The strongest parts are the multi-object split and merge, the communication ribbon, and the coordinated system-to-brand handoff. The design intentionally remains spare; some intermediate path shapes are abstract, and the circle subdivision briefly shows faceted seams as it separates. Those are visible geometric transformations rather than exchanged pictures.

V1, V2 and V3 videos were not present in the available workspace, so a direct side-by-side comparison could not be performed. The new implementation follows the requested chain-reaction concept rather than the slideshow behavior described in the brief. No earlier advertisement files were modified.

The export checks confirm duration, frame count, codec, decoding, asset preservation and audio alignment. They do **not** prove creative perfection or audience response. This review records actual inspection and revisions, not a technical pass presented as an artistic guarantee.

## Delivery

- `centrix-v4-final.mp4`: 1080 × 1920 H.264, 30 fps, 900 frames, stereo AAC.
- `centrix-v4-preview.mp4`: 540 × 960 H.264, same 900-frame timeline and AAC sound.
- `centrix-v4-silent.mp4`: full-resolution H.264 picture master, no audio stream.
- `centrix-v4-source.zip`: React / TypeScript / SVG Remotion project, original assets and audio source.
- `review-frames/`: eight representative keyframes, transition images and contact sheets.
- `verification.json`: machine-readable decode, frame-count and sound synchronization checks.
- `centrix-v4-delivery.zip`: complete delivery folder, excluding itself.
