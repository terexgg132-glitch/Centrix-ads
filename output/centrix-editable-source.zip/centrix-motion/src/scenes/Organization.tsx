import { AbsoluteFill } from "remotion";
import { C, ease, mix, pop, useMotion, SceneProps } from "../design";
import { Avatar, BrandMark, Check, Icon, Words } from "../components";

export const Organization: React.FC<SceneProps> = ({ standalone = false }) => {
  const f = useMotion();
  const unfold = ease(f, 20, 58);
  const gather = ease(f, 233, 267);
  const reflow = ease(f, 90, 121);
  const tidy = ease(f, 180, 212);
  const nodes = [
    { x: 287, y: 892, icon: "students", label: "الطلاب" },
    { x: 793, y: 902, icon: "calendar", label: "الحضور" },
    { x: 300, y: 1372, icon: "note", label: "البيانات" },
    { x: 790, y: 1372, icon: "bell", label: "المتابعة" },
  ] as const;
  return (
    <AbsoluteFill style={{ background: standalone ? C.pale : undefined }}>
      <div
        style={{
          position: "absolute",
          left: 90,
          top: 392,
          width: 900,
          opacity: 1 - ease(f, 223, 248),
          translate: `0 ${-110 * gather}px`,
        }}
      >
        <Words text="كل شغلك..." start={48} size={118} color={C.ink} />
        <Words text="في مكان واحد" start={65} size={108} color={C.blue} />
      </div>
      <svg
        width="1080"
        height="1920"
        style={{ position: "absolute", opacity: unfold * (1 - gather) }}
      >
        {nodes.map((o, i) => (
          <path
            key={i}
            d={`M540 1135 Q${i % 2 ? 790 : 290} 1135 ${mix(o.x, i % 2 ? 775 : 305, tidy)} ${mix(o.y, i < 2 ? 935 : 1335, tidy)}`}
            fill="none"
            stroke={C.muted}
            strokeWidth="5"
            pathLength="1"
            strokeDasharray="1"
            strokeDashoffset={1 - ease(f, 39 + i * 5, 78 + i * 5)}
          />
        ))}
      </svg>
      {nodes.map((o, i) => {
        const p = pop(f, 27 + i * 7, 34);
        const x = mix(540, mix(o.x, i % 2 ? 775 : 305, tidy), unfold);
        const y = mix(866, mix(o.y, i < 2 ? 935 : 1335, tidy), unfold);
        const w = mix(790, 350, unfold);
        const h = mix(246, 213, unfold);
        const dx = i % 2 === 0 ? -18 : 18;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: mix(x, 540, gather) - w / 2,
              top: mix(y, 1135, gather) - h / 2,
              width: w,
              height: h,
              borderRadius: mix(42, 32, unfold),
              background: i === 1 ? C.cyan : C.white,
              border: `3px solid ${i === 1 ? C.cyan : C.pale}`,
              boxSizing: "border-box",
              scale:
                (i === 0 ? mix(1, 1, p) : mix(0.68, 1, p)) *
                (1 - gather * 0.85),
              rotate: `${mix((i - 1.5) * 7, 0, reflow) * unfold * (1 - gather)}deg`,
              translate: `${dx * Math.sin(f * 0.04 + i) * unfold * (1 - reflow)}px 0`,
              opacity:
                (i === 0 ? 1 : ease(f, 23 + i * 7, 35 + i * 7)) *
                (1 - ease(f, 252, 270)),
            }}
          >
            {i === 0 && (
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  opacity: 1 - ease(f, 20, 39),
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    right: 170,
                    top: 35,
                    left: 32,
                    fontFamily: "Cairo",
                    color: C.ink,
                    textAlign: "right",
                    direction: "rtl",
                  }}
                >
                  <div style={{ fontWeight: 800, fontSize: 42 }}>
                    إشعار لولي الأمر
                  </div>
                  <div
                    style={{
                      fontSize: 32,
                      fontWeight: 600,
                      color: C.blue,
                      marginTop: 5,
                    }}
                  >
                    يوسف سجّل حضوره
                  </div>
                  <div
                    style={{
                      marginTop: 22,
                      height: 7,
                      borderRadius: 5,
                      width: "72%",
                      background: C.pale,
                    }}
                  />
                </div>
                <div
                  style={{
                    position: "absolute",
                    right: 50,
                    top: 39,
                    width: 100,
                    height: 100,
                    borderRadius: "50%",
                    background: C.cyan,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <svg
                    width="80"
                    height="80"
                    viewBox="0 0 80 80"
                    fill="none"
                    stroke={C.blue}
                    strokeWidth="5"
                    strokeLinejoin="round"
                  >
                    <rect x="13" y="20" width="54" height="41" rx="9" />
                    <path d="M17 28L40 46L63 28" />
                  </svg>
                </div>
              </div>
            )}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "100%",
                gap: 22,
                opacity: ease(f, 38, 61),
              }}
            >
              <Icon kind={o.icon} size={68} />
              <div
                style={{
                  fontFamily: "Cairo",
                  fontWeight: 800,
                  fontSize: 43,
                  color: C.ink,
                  direction: "rtl",
                }}
              >
                {o.label}
              </div>
            </div>
          </div>
        );
      })}
      <div
        style={{
          position: "absolute",
          left: 540 - 113,
          top: 1135 - 113,
          width: 226,
          height: 226,
          borderRadius: 70,
          background: C.blue,
          scale: pop(f, 58, 35) * mix(1, 1.32, gather),
          rotate: `${90 * gather}deg`,
          opacity: 1 - ease(f, 230, 246),
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ rotate: `${-90 * gather}deg` }}>
          <BrandMark size={144} color={C.white} id="hub" />
        </div>
      </div>
      {/* Authored student strips split from the information node, then fold back. */}
      {[0, 1].map((i) => {
        const p = pop(f, 133 + i * 15, 32);
        const out = ease(f, 216 + i * 5, 253 + i * 5);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: mix(185 + i * 360, 540 - 150, out),
              top: mix(1569, 1135, out),
              width: 330,
              height: 116,
              borderRadius: 58,
              background: C.pale,
              display: "flex",
              alignItems: "center",
              padding: "14px 22px",
              boxSizing: "border-box",
              gap: 16,
              scale: p * (1 - out),
              rotate: `${mix(i ? 5 : -5, 0, ease(f, 169, 194))}deg`,
            }}
          >
            <Avatar size={72} variant={i + 4} />
            <div
              dir="rtl"
              style={{
                fontFamily: "Cairo",
                fontSize: 32,
                fontWeight: 800,
                color: C.ink,
                flex: 1,
              }}
            >
              {i ? "مريم" : "أحمد"}
            </div>
            <Check size={45} progress={ease(f, 165 + i * 15, 177 + i * 15)} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
