import React from 'react';
import {AbsoluteFill,Composition,Folder,Sequence,useVideoConfig,staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {Operations} from './scenes/Operations';
import {Organize,UnifiedSystem} from './scenes/System';
import {Opening} from './scenes/Opening';
import {Details} from './scenes/Details';
import {Assistant} from './scenes/Assistant';
import {Network} from './scenes/Network';
import {Brand} from './scenes/Brand';
type FilmProps={tagline:string;website:string;audioEnabled:boolean};
export const CentrixFilm:React.FC<FilmProps>=({tagline,website,audioEnabled})=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#020204'}}>
<Sequence name="S01 — Before the class" durationInFrames={81} premountFor={fps}><Opening/></Sequence>
<Sequence name="S02 — Disconnected details" from={81} durationInFrames={98} premountFor={fps}><Details/></Sequence>
<Sequence name="S03 — Attendance, collection, follow-up" from={179} durationInFrames={87} premountFor={fps}><Operations/></Sequence>
<Sequence name="S04 — Golden thread organizes" from={266} durationInFrames={34} premountFor={fps}><Organize/></Sequence>
<Sequence name="S05 — One unified system" from={300} durationInFrames={140} premountFor={fps}><UnifiedSystem/></Sequence>
<Sequence name="S06 — Ask the AI Agent" from={440} durationInFrames={96} premountFor={fps}><Assistant/></Sequence>
<Sequence name="S07 — Connected operations" from={536} durationInFrames={114} premountFor={fps}><Network/></Sequence>
<Sequence name="S08 — Authentic brand payoff" from={650} durationInFrames={160} premountFor={fps}><Brand tagline={tagline} website={website}/></Sequence>
{audioEnabled&&<Audio src={staticFile('assets/Centrix_Final_Mix.wav')} premountFor={fps}/>}
</AbsoluteFill>};
export const StyleTest:React.FC=()=>{const {fps}=useVideoConfig();return <AbsoluteFill>
<Sequence name="Three operations" durationInFrames={87} premountFor={fps}><Operations/></Sequence>
<Sequence name="Golden thread activation" from={87} durationInFrames={33} premountFor={fps}><Organize/></Sequence>
<Sequence name="Unified dashboard" from={120} durationInFrames={120} premountFor={fps}><UnifiedSystem/></Sequence>
<Audio src={staticFile('assets/Centrix_Final_Mix.wav')} trimBefore={6*fps} premountFor={fps}/>
</AbsoluteFill>};
export const RemotionRoot:React.FC=()=> <>
<Composition id="Centrix-Final-27s" component={CentrixFilm} width={1080} height={1920} fps={30} durationInFrames={810} defaultProps={{tagline:'سستم السنتر',website:'centrix.company',audioEnabled:true}}/>
<Composition id="Centrix-Style-Test" component={StyleTest} width={1080} height={1920} fps={30} durationInFrames={240}/>
<Folder name="Scenes">
<Composition id="S01-Opening" component={Opening} width={1080} height={1920} fps={30} durationInFrames={81}/>
<Composition id="S02-Details" component={Details} width={1080} height={1920} fps={30} durationInFrames={98}/>
<Composition id="S03-Operations" component={Operations} width={1080} height={1920} fps={30} durationInFrames={87}/>
<Composition id="S04-Organize" component={Organize} width={1080} height={1920} fps={30} durationInFrames={34}/>
<Composition id="S05-Unified-System" component={UnifiedSystem} width={1080} height={1920} fps={30} durationInFrames={140}/>
<Composition id="S06-Assistant" component={Assistant} width={1080} height={1920} fps={30} durationInFrames={96}/>
<Composition id="S07-Network" component={Network} width={1080} height={1920} fps={30} durationInFrames={114}/>
<Composition id="S08-Brand" component={Brand} width={1080} height={1920} fps={30} durationInFrames={160} defaultProps={{tagline:'سستم السنتر',website:'centrix.company'}}/>
</Folder></>;
