import React from "react";
import { Audio } from "@remotion/media";
import { staticFile } from "remotion";
import { AbsoluteFill, Sequence, useVideoConfig } from "remotion";
import { Pressure } from "./scenes/Pressure";
import { Reply } from "./scenes/Reply";
import { Agent } from "./scenes/Agent";
import { FindStudent } from "./scenes/FindStudent";
import { Attendance } from "./scenes/Attendance";
import { Finance } from "./scenes/Finance";
import { Network } from "./scenes/Network";
import { Promise } from "./scenes/Promise";
import { Brand } from "./scenes/Brand";
export const Film = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Sequence
        name="01 — Every detail"
        from={0}
        durationInFrames={6 * fps}
        premountFor={fps}
      >
        <Pressure />
      </Sequence>
      <Sequence
        name="02 — An answer"
        from={6 * fps}
        durationInFrames={5 * fps}
        premountFor={fps}
      >
        <Reply />
      </Sequence>
      <Sequence
        name="03 — Into action"
        from={11 * fps}
        durationInFrames={5 * fps}
        premountFor={fps}
      >
        <Agent />
      </Sequence>
      <Sequence
        name="04 — Find the student"
        from={16 * fps}
        durationInFrames={6 * fps}
        premountFor={fps}
      >
        <FindStudent />
      </Sequence>
      <Sequence
        name="05 — Attendance executed"
        from={22 * fps}
        durationInFrames={6 * fps}
        premountFor={fps}
      >
        <Attendance />
      </Sequence>
      <Sequence
        name="06 — Payments retrieved"
        from={28 * fps}
        durationInFrames={6 * fps}
        premountFor={fps}
      >
        <Finance />
      </Sequence>
      <Sequence
        name="07 — The connected system"
        from={34 * fps}
        durationInFrames={8 * fps}
        premountFor={fps}
      >
        <Network />
      </Sequence>
      <Sequence
        name="08 — Your intent in motion"
        from={42 * fps}
        durationInFrames={6 * fps}
        premountFor={fps}
      >
        <Promise />
      </Sequence>
      <Sequence
        name="09 — Centrix"
        from={48 * fps}
        durationInFrames={7 * fps}
        premountFor={fps}
      >
        <Brand />
      </Sequence>
      <Audio
        name="Original score"
        src={staticFile("audio/music.wav")}
        volume={0.65}
        premountFor={fps}
      />
      <Audio
        name="Sound design"
        src={staticFile("audio/sfx.wav")}
        volume={0.75}
        premountFor={fps}
      />
    </AbsoluteFill>
  );
};
