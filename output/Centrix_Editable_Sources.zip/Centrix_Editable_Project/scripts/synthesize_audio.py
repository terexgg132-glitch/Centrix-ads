"""CENTRIX original score and sound design. All waveforms are generated mathematically.
No samples, stock loops, external melodies or voice generation. Deterministic seed 230712.
"""
from pathlib import Path
import json, subprocess
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'output/audio'; OUT.mkdir(parents=True,exist_ok=True)
SR=48000; DUR=27.; N=int(SR*DUR); rng=np.random.default_rng(230712)
music=np.zeros((N,2)); sfx=np.zeros((N,2)); cues=[]
def hz(n): return 440*2**((n-69)/12)
def filt(x,cut,kind='lowpass',order=2): return sosfilt(butter(order,cut,fs=SR,btype=kind,output='sos'),x)
def times(d): return np.arange(int(d*SR))/SR
def env(t,a=.012,dec=.3): return (1-np.exp(-t/a))*np.exp(-t/dec)
def put(dst,x,start,amp=1,pan=0,echo=False):
    x=np.asarray(x); pos=int(start*SR)
    if x.ndim==1: x=np.stack([x*np.sqrt((1-pan)/2),x*np.sqrt((1+pan)/2)],1)
    if pos<0: x=x[-pos:]; pos=0
    size=min(len(x),N-pos)
    if size<=0:return
    dst[pos:pos+size]+=x[:size]*amp
    if echo:
        for delay,gain,p in [(.113,.20,-pan),(.231,.13,pan),(.367,.08,-pan),(.541,.055,pan)]:
            put(dst,x[:,::-1] if p!=pan else x,start+delay,amp*gain,echo=False)
def pad(notes,start,dur,amp):
    t=times(dur); e=np.minimum(t/1.0,1)*np.minimum((dur-t)/1.4,1); e=np.clip(e,0,1)
    x=np.zeros((len(t),2))
    for i,n in enumerate(notes):
        f=hz(n); drift=.14*np.sin(2*np.pi*.11*t+i)
        for ch,d in enumerate([-.0022,.0022]):
            phase=2*np.pi*f*(1+d)*t+drift
            x[:,ch]+=(np.sin(phase)+.13*np.sin(2*phase)+.06*np.sin(3*phase+i))*e/len(notes)
    put(music,x,start,amp)
def pluck(note,start,amp=.06,pan=0,dec=.44):
    t=times(1.9); f=hz(note)
    x=(np.sin(2*np.pi*f*t+1.3*np.sin(2*np.pi*2*f*t)*np.exp(-t/.07))+.1*np.sin(2*np.pi*3*f*t))*env(t,.004,dec)
    put(music,x,start,amp,pan,True)
def bass(note,start,amp=.08):
    t=times(.52); f=hz(note)
    x=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*2*f*t)+.12*np.sin(2*np.pi*3*f*t))*env(t,.014,.21)
    put(music,x,start,amp)
def kick(start,amp=.06):
    t=times(.3); f=48+62*np.exp(-t/.022); ph=2*np.pi*np.cumsum(f)/SR
    x=np.sin(ph)*env(t,.002,.075)+filt(rng.normal(size=len(t)),1600)*np.exp(-t/.006)*.08
    put(music,x,start,amp)
def hat(start,amp=.008,pan=0):
    t=times(.09); x=filt(rng.normal(size=len(t)),[4400,8500],'bandpass')*env(t,.0005,.012)
    put(music,x,start,amp,pan)
def rim(start,amp=.02):
    t=times(.15); x=(np.sin(2*np.pi*710*t)+.5*np.sin(2*np.pi*1103*t))*env(t,.0007,.016)
    put(music,x,start,amp,.12,True)
# A composed, non-looped harmonic journey. Pads breathe through the questions.
pad([50,57,60,64],0,6.4,.038); pad([46,53,57,60],5.5,4.5,.04)
pad([50,57,62,65],8.8,4.8,.05); pad([48,55,60,64],12.3,3.6,.036)
pad([46,53,57,62],15.1,3.8,.028); pad([45,52,57,62],18,4.1,.050)
pad([50,57,62,65,69],21.66,5.34,.069)
beat=60/108
for j,start in enumerate(np.arange(.0,21.5,beat)):
    if start<5.98:
        if j%4==0: bass(38,start,.04); kick(start,.035)
        if j%8==5: pluck(74,start,.018,-.3,1.0)
    else:
        duck=.6 if 14.68<start<17.88 else 1.
        gain=(.85+.18*(start-18)/3.6) if start>18 else .9
        kick(start,.07*duck*gain)
        if j%2==0: bass([38,38,34,36][(j//8)%4],start,.062*duck)
        if j%4==2: rim(start,.018*duck)
        hat(start+beat/2,.010*duck,(-1)**j*.25)
        if start>9:
            # Sparse, original motif with deliberate rests and varied note lengths.
            note=[74,81,77,76,69,77,74,81][j%8]
            if j%8 not in [3,7]: pluck(note,start+beat/4,.028*duck,(-1)**j*.32,.22+(.12 if j%3==0 else 0))
# Timed three-note brand signature: D5-F5-A5; decaying FM / warm bell.
for note,start in [(74,21.661),(77,21.98),(81,22.31)]: pluck(note,start,.094,.0,1.25)
# Sound effects are individually authored, spectrally distinct and synchronized.
def tick(start,f=1700,amp=.022,dec=.023,name='UI tick'):
    t=times(.2); x=(np.sin(2*np.pi*f*t)+.24*np.sin(2*np.pi*f*1.49*t))*env(t,.0007,dec)
    put(sfx,x,start,amp,0,True); cues.append({'time':start,'cue':name})
def impact(start,amp=.09,f=62,name='impact'):
    t=times(.8); x=(np.sin(2*np.pi*(f*t+1.8*(1-np.exp(-t/.03))))+.22*np.sin(2*np.pi*2*f*t))*env(t,.002,.15)
    x+=filt(rng.normal(size=len(t)),[350,2400],'bandpass')*np.exp(-t/.025)*.12
    put(sfx,x,start,amp); cues.append({'time':start,'cue':name})
def whoosh(start,dur=.7,amp=.018,reverse=False,name='sweep'):
    t=times(dur); noise=filt(rng.normal(size=len(t)),[350,3400],'bandpass'); e=np.sin(np.pi*t/dur)**2
    tone=np.sin(2*np.pi*(480*t+620*t*t/dur))*.13
    x=(noise+tone)*e
    if reverse:x=x[::-1]
    put(sfx,x,start,amp,-.3,True); cues.append({'time':start,'cue':name})
impact(0,.16,48,'Opening heartbeat'); tick(.306,2150,.033,.032,'Student scanner confirmation')
whoosh(2.70,.57,.025,name='Layered information sweep'); impact(4.596,.072,88,'Details punctuation')
tick(5.983,950,.049,.053,'Attendance: rounded confirmation'); tick(6.766,1650,.038,.046,'Collection: glass receipt')
impact(7.742,.076,110,'Follow-up: soft report stamp')
whoosh(8.70,.176,.015,True,'Pre-activation vacuum'); whoosh(8.876,.95,.040,name='Golden thread activation')
impact(9.31,.085,57,'System lock')
for t,f in [(10.005,1450),(10.44,1750),(10.84,1150),(11.37,1560)]:tick(t,f,.014,.022,'Dashboard reveal')
impact(12.715,.081,80,'Single-system snap to grid')
tick(14.685,640,.016,.11,'AI question focus')
for t,f in [(16.236,1740),(16.34,2320),(16.49,2900)]:tick(t,f,.017,.20,'AI response shimmer')
whoosh(18.526,3.135,.025,name='Restrained network riser'); impact(21.661,.23,48,'Hero brand impact')
tick(22.513,3200,.012,.29,'Tagline glint')
# Voice-led dynamic ducking, with an additional dip over the AI question.
scratch=ROOT/'work/audio'; scratch.mkdir(parents=True,exist_ok=True)
voice_wav=scratch/'voice_decode.wav'
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(ROOT/'assets/centrix_voice_original.mp3'),'-ar',str(SR),'-ac','2',str(voice_wav)],check=True)
_,v=wavfile.read(voice_wav); v=v.astype(float)/32768
voice=np.zeros((N,2)); voice[:min(N,len(v))]=v[:N]
power=np.mean(voice**2,axis=1); rms=np.sqrt(np.convolve(power,np.ones(1920)/1920,'same'))
# Absolute music starts around 20dB under voice during narration.
duck=1-.40*np.clip((rms-.008)/.05,0,1)
t=np.arange(N)/SR
ai=1-.26*np.clip((t-14.5)/.18,0,1)*np.clip((18.0-t)/.22,0,1)
fade=np.clip((27-t)/.35,0,1)
music*=duck[:,None]*ai[:,None]*fade[:,None]
sfx*= (1-.15*np.clip((rms-.01)/.07,0,1))[:,None]*fade[:,None]
# A light peak safety stage before the measured FFmpeg mastering pass.
raw=voice+music+sfx
for name,a in [('Centrix_Music_Original.wav',music),('Centrix_SFX_Stem.wav',sfx),('Centrix_Voice_Decoded_Padded.wav',voice),('pre_master.wav',raw)]:
    destination=(scratch/name) if name in ['pre_master.wav','Centrix_Voice_Decoded_Padded.wav'] else (OUT/name)
    wavfile.write(destination,SR,np.round(np.clip(a,-1,1)*8388607).astype(np.int32)<<8)
(OUT/'audio_cues.json').write_text(json.dumps(cues,indent=2),encoding='utf8')
print(json.dumps({'voice_samples_decoded':len(v),'voice_seconds_decoded':len(v)/SR,'raw_peak':float(np.max(abs(raw))),'music_rms':float(np.sqrt(np.mean(music**2))),'sfx_peak':float(np.max(abs(sfx))),'cues':len(cues)},indent=2))
