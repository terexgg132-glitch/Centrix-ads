# CENTRIX V2 — editable cinematic film

27 seconds, 1080×1920, 30fps. Hybrid Three.js CGI and SVG/HTML typography.
The client granted full creative freedom after reviewing V1. V2 introduces
physical paper objects, extruded gold symbols, a spatial data conductor,
larger word-synchronized typography, and a newly composed soundtrack.

Run npm ci, then npm run dev. Open Centrix-V2-Final in the Studio.
Six scene compositions and the 8-second central style test are registered.
World.tsx defines the CGI objects, studio environment, textures and camera;
Scenes.tsx contains the hook, record layers, AI, connected system and brand;
ControlMachine.tsx owns the continuous feature-to-system transformation.
primitives.tsx controls palette, Arabic typography and vector strokes.
RootV2.tsx contains editable scene timing nodes.

On Linux use /usr/bin/chromium. Else set CENTRIX_CHROME to Chrome/Chromium.
Install Python dependencies with pip install -r requirements-audio.txt.
FFmpeg and ffprobe are required. Run npm run audio:build to rebuild audio,
npm run render:style or npm run render:final to export, and npm run validate
to inspect the actual encoded master.

The browser renders deterministic frames without collecting audio; FFmpeg
muxes the original-voice mix and enforces exact duration, H.264 yuv420p,
limited-range BT.709 and AAC 48kHz stereo. Studio audio remains enabled.

The original 23.712s voice MP3 and full SVG brand asset are preserved exactly.
Voice is never cut, retimed or regenerated. The complete raster-backed SVG
is displayed intact. UI and graphs are clearly illustrative; no real student
identities, financial metrics or automated message sending are depicted.

All music, effects, studio reflections and paper textures are original
procedural work. No external music, stock sounds, image assets, 3D models or
copyrighted samples are used. Cairo is legally redistributed unchanged with
its SIL Open Font License, in public/fonts/OFL.txt.

Physical phone-speaker listening is unavailable in this cloud environment.
The validation generates a mono phone-band proxy for technical review;
actual handset listening and subjective creative approval remain manual.
