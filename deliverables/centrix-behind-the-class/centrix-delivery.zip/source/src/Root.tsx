import React from 'react';
import {AbsoluteFill,Composition,Folder,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import {Classroom} from './Classroom';
import {Backstage} from './Backstage';
import {Student,OperationWords} from './Student';
import {Dashboard} from './Dashboard';
import {Intelligence} from './Intelligence';
import {Outro} from './Outro';
import {IdentityAxis} from './IdentityAxis';
import {C,p,lerp} from './shared';
loadFont({family:'Cairo',url:staticFile('fonts/Cairo.ttf'),weight:'100 1000',format:'truetype'});
type FilmProps={offset?:number;audio?:boolean};
export const Film=({offset=0,audio=true}:FilmProps)=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 let t=frame/fps+offset;
 // Three held frames: identity and folded paper retain position on the takeover.
 if(t>=8.88&&t<8.98)t=8.88;
 const dark=t>=9.08;const background=t>=21.66?'#030304':dark?C.black:C.paper;
 return <AbsoluteFill style={{backgroundColor:background,fontFamily:'Cairo'}}>
  <svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute',overflow:'hidden'}}>
   <defs><pattern id="paper" width="19" height="23" patternUnits="userSpaceOnUse"><circle cx="3" cy="3" r=".7" fill="#756B59" opacity=".055"/><circle cx="15" cy="18" r=".6" fill="#756B59" opacity=".035"/></pattern></defs>
   {!dark&&<rect width="1080" height="1920" fill="url(#paper)"/>}
   <Backstage t={t}/>
   <g opacity={p(t,8.99,9.08)*(1-p(t,9.18,9.65))}>
    <rect x={lerp(1010,540,p(t,8.99,9.18))} y="180" width="3" height="1480" fill={C.gold}/>
    <path d="M170 710H920 M170 1038H920 M170 1256H920" stroke={C.gold} strokeWidth="1" opacity={.25}/>
   </g>
   <Dashboard t={t}/>
   <Student t={t}/>
   <OperationWords t={t}/>
   <Intelligence t={t}/>
   <IdentityAxis t={t}/>
   <Classroom t={t}/>
   <Outro t={t}/>
  </svg>
  {audio&&<Audio src={staticFile('assets/centrix-full-mix.wav')} trimBefore={offset*fps} premountFor={fps}/>}
 </AbsoluteFill>;
};
export const Root=()=> <>
 <Composition id="Centrix" component={Film} width={1080} height={1920} fps={30} durationInFrames={810} defaultProps={{offset:0,audio:true}}/>
 <Composition id="MotionProof" component={Film} width={1080} height={1920} fps={30} durationInFrames={240} defaultProps={{offset:5.5,audio:true}}/>
 <Folder name="Scenes">
  <Composition id="Hook" component={Film} width={1080} height={1920} fps={30} durationInFrames={99} defaultProps={{offset:0,audio:false}}/>
  <Composition id="Operations" component={Film} width={1080} height={1920} fps={30} durationInFrames={108} defaultProps={{offset:5.5,audio:false}}/>
  <Composition id="OneSystem" component={Film} width={1080} height={1920} fps={30} durationInFrames={171} defaultProps={{offset:8.99,audio:false}}/>
  <Composition id="Intelligence" component={Film} width={1080} height={1920} fps={30} durationInFrames={96} defaultProps={{offset:14.68,audio:false}}/>
  <Composition id="WholeWorld" component={Film} width={1080} height={1920} fps={30} durationInFrames={114} defaultProps={{offset:17.88,audio:false}}/>
  <Composition id="HeroLogo" component={Film} width={1080} height={1920} fps={30} durationInFrames={160} defaultProps={{offset:21.66,audio:false}}/>
 </Folder>
</>;
