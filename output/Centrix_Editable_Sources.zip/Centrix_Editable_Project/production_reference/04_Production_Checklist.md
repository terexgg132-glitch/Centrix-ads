# CENTRIX Production Checklist

- [ ] Confirm supplied original MP3 audio is 23.712 seconds and remains unmodified
- [ ] Inspect user logo and retain original design, color and text
- [ ] Use Centrix-approved interface recordings/screenshots if available; otherwise conceptual UI only
- [ ] Storyboard visually connected by ONE continuous golden line
- [ ] Test animation for voice-synced three words: حضور / تحصيل / متابعة
- [ ] Ensure AI interaction reflects a supported illustrative question; no automated WhatsApp claims
- [ ] Compose or license original tech-hybrid music; no copyrighted samples
- [ ] Design cue-by-cue SFX; preserve VO intelligibility
- [ ] End frame reads 'سستم السنتر' with logo and centrix.company
- [ ] Leave branding static for at least 3 seconds after final spoken word
- [ ] Validate full duration 27sec, 1080x1920, 30FPS, audio peaks and loudness
- [ ] Deliver style-test preview, final MP4, review MP4, audio stems, editable sources ZIP, contact sheet

## What the producer still needs if exact real UI is desired
Screen recording or anonymized screenshots of the real student page, attendance view, collection/accounts and reports, and a sanitized AI Agent exchange. These are optional for the conceptual first style test but needed before describing UI shots as footage of the actual app.

## Brand/source links
https://centrix.company/

Assets included in this package are the original user-provided voice recording and logo.
