import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
p=str(ROOT/'public/fonts/Cairo.ttf');data=open(p,'rb').read();face=hb.Face(data);f=hb.Font(face);f.set_variations({'wght':850});buf=hb.Buffer();buf.add_str('الحصة');buf.guess_segment_properties();hb.shape(f,buf);ft=TTFont(p);gs=ft.getGlyphSet(location={'wght':850});out=SVGPathPen(gs);x=0
for i,ps in zip(buf.glyph_infos,buf.glyph_positions):
 n=ft.getGlyphName(i.codepoint);glyph=gs[n];pen=TransformPen(out,(1,0,0,-1,x+ps.x_offset,-ps.y_offset));glyph.draw(pen);b=BoundsPen(gs);glyph.draw(b);print(n,x,b.bounds);x+=ps.x_advance
obj={'d':out.getCommands(),'width':x,'height':1500}
open(str(ROOT/'src/lesson-path.json'),'w').write(json.dumps(obj))
open(str(ROOT/'lesson-outline.svg'),'w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-50 -1700 {x+100} 2100"><rect x="-50" y="-1700" width="{x+100}" height="2100" fill="#F4F0E7"/><path d="{obj["d"]}" fill="#24221F"/></svg>')
