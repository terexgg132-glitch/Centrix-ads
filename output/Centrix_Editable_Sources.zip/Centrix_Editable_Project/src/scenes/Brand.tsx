import React from 'react';
import {AbsoluteFill,Img,staticFile} from 'remotion';
import {Text,C,prog,mix,useScene,clamp} from '../design';
export const Brand:React.FC<{tagline?:string;website?:string}>=({tagline='سستم السنتر',website='centrix.company'})=>{
const {f,fps}=useScene();const reveal=prog(f,0,16),text=prog(f,.846*fps,13);const fade=1-clamp((f-149.5)/10.5);
return <AbsoluteFill style={{background:'#020204',opacity:fade}}>
<Img src={staticFile('assets/centrix_logo_original.svg')} style={{position:'absolute',left:mix(402,110,reveal),top:mix(906,292,reveal),width:mix(276,860,reveal),height:mix(276,860,reveal),objectFit:'contain',opacity:1}}/>
<Text x={110} w={860} y={1214} size={104} weight={900} style={{opacity:text,translate:'0 '+mix(22,0,text)+'px'}}>{tagline}</Text>
<div style={{position:'absolute',left:389,top:1370,width:302,height:1,background:'linear-gradient(90deg,transparent,#DDB34B99,transparent)',opacity:prog(f,1.4*fps,12)}}/>
<div style={{position:'absolute',left:100,top:1435,width:880,fontFamily:'Arial, sans-serif',fontSize:39,fontWeight:400,letterSpacing:3,color:C.gray,textAlign:'center',opacity:prog(f,1.4*fps,12)}}>{website}</div>
</AbsoluteFill>};
